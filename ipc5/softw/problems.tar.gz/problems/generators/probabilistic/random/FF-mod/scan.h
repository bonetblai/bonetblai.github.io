
void fcterr( int errno, char *par ); 
