
#include "preprocess.h"
#include <assert.h>
#include <list>

int Preprocessor::default_trace_level = 0;

Preprocessor::Preprocessor(Instance& ins) : instance(ins), trace_level(default_trace_level)
{
  for (size_t k = 0; k < instance.n_atoms(); k++) atom_map.push_back( k );
  for (size_t k = 0; k < instance.n_actions(); k++) action_map.push_back( k );
}

Preprocessor::~Preprocessor()
{
}

void Preprocessor::compute_reachability(bool_vec& reachable_atoms, bool_vec& reachable_actions)
{
  reachable_atoms.clear();
  for (size_t k = 0; k < instance.atoms.size(); k++) {
    reachable_atoms.push_back( true );
  }

  reachable_actions.clear();
  for (size_t k = 0; k < instance.actions.size(); k++) {
    reachable_actions.push_back( true );
  }
}

void Preprocessor::compute_static_atoms(const bool_vec& reachable_actions, bool_vec& static_atoms)
{
  static_atoms.clear();
  for (size_t k = 0; k < instance.atoms.size(); k++)
    static_atoms.push_back( instance.atoms[k]->init );

  for (size_t k = 0; k < instance.actions.size(); k++)
    if (reachable_actions[k]) {
      for( index_set::const_iterator di = instance.actions[k]->del.begin(); di != instance.actions[k]->del.end(); ++di ) {
        assert( *di < static_atoms.size() );
        static_atoms[*di] = false;
      }
    }
}

void Preprocessor::compute_relevance(const index_set& check, bool_vec& rel)
{
  for( index_set::const_iterator ci = check.begin(); ci != check.end(); ++ci ) {
    if (!rel[*ci]) {
      rel[*ci] = true;
    }
  }
}

void Preprocessor::compute_irrelevant_atoms()
{
  bool_vec relevant;
  compute_relevance(instance.goal_atoms, relevant);
  for (size_t k = 0; k < instance.n_atoms(); k++) {
    assert( k < relevant.size() );
    //if (!relevant[k]) instance.atoms[k]->irrelevant = true;
  }
}

void Preprocessor::remove_useless_actions()
{
#if 0
  bool_vec u_act( instance.n_actions(), false );
  for (size_t k = 0; k < instance.n_actions(); k++) {
    if (instance.actions[k]->pre.contains(instance.actions[k]->add)) {
      if (trace_level > 1)
	std::cerr << "action " << instance.actions[k]->name << " is useless" << std::endl;
      u_act[k] = true;
    }
  }
  instance.remove_actions(u_act, action_map);
#endif
}

void Preprocessor::preprocess()
{
  //instance.clear_cross_reference();
  //if (trace_level > 0) std::cerr << "removing inconsistent & useless actions..." << std::endl;

  bool_vec inc(instance.n_actions(), false);
  bool_vec useless(instance.n_actions(), true);

  for (size_t k = 0; k < instance.n_actions(); k++) {
#if 0
    // check for inconsistency...
    for( index_set::const_iterator ai = instance.actions[k]->add.begin(); (ai != instance.actions[k]->add.end()) && !inc[k]; ++ai )
      if (instance.actions[k]->del.contains(*ai)) inc[k] = true;
    if (inc[k] && (trace_level > 1)) {
      std::cerr << "action " << instance.actions[k]->name << " is inconsistent" << std::endl;
    }
#endif

#if 0
    // check for uselessness...
    for( index_set::const_iterator ai = instance.actions[k]->add.begin(); (ai != instance.actions[k]->add.end()) && useless[k]; ++ai )
      if (!instance.actions[k]->pre.contains(*ai)) useless[k] = false;
    if (useless[k] && (trace_level > 1)) {
      std::cerr << "action " << instance.actions[k]->name << " is useless" << std::endl;
    }
#endif
  }
  //inc.bitwise_or( useless );
  //instance.remove_actions(inc, action_map);

  if (trace_level > 0) std::cerr << "cross referencing..." << std::endl;
  instance.cross_reference();

  if (trace_level > 0) std::cerr << "computing reachability..." << std::endl;
  bool_vec reachable_atoms(instance.n_atoms(), false);
  bool_vec reachable_actions(instance.n_actions(), false);
  //compute_reachability(reachable_atoms, reachable_actions);

  if (trace_level > 0) std::cerr << "computing static atoms..." << std::endl;
  bool_vec atoms_to_remove(instance.n_atoms(),false);
  compute_static_atoms(reachable_actions, atoms_to_remove);

  reachable_actions.bitwise_complement();
  if (trace_level > 0) {
    std::cerr << "removing unreachable actions..." << std::endl;
    if (trace_level > 1) {
      instance.write_action_set(std::cerr, reachable_actions);
      std::cerr << std::endl;
    }
  }
  //instance.remove_actions(reachable_actions, action_map);

  reachable_atoms.bitwise_complement();
  atoms_to_remove.bitwise_or( reachable_atoms );

  // make sure we don't remove unreachable goals!
  for (size_t k = 0; k < instance.atoms.size(); k++)
    if (instance.atoms[k]->goal) atoms_to_remove[k] = false;

  if (trace_level > 0) {
    std::cerr << "removing unreachable and static atoms..." << std::endl;
    if (trace_level > 1) {
      instance.write_atom_set(std::cerr, atoms_to_remove);
      std::cerr << std::endl;
    }
  }

  if (!atoms_to_remove.empty()) {
    //instance.remove_atoms(atoms_to_remove, atom_map);
    //remove_useless_actions();
  }

  if (trace_level > 0) std::cerr << "re-cross referencing..." << std::endl;
}

void Preprocessor::remove_irrelevant_atoms()
{
  bool_vec atoms_to_remove(false, instance.n_atoms());
  for (size_t k = 0; k < instance.atoms.size(); k++)
    ;//if (instance.atoms[k]->irrelevant) atoms_to_remove[k] = true;

  if (trace_level > 0) {
    std::cerr << "removing irrelevant atoms..." << std::endl;
    if (trace_level > 1) {
      instance.write_atom_set(std::cerr, atoms_to_remove);
      std::cerr << std::endl;
    }
  }

  if (!atoms_to_remove.empty()) {
    instance.remove_atoms(atoms_to_remove, atom_map);
    remove_useless_actions();

    if (trace_level > 0) std::cerr << "re-cross referencing..." << std::endl;
    instance.clear_cross_reference();
    instance.cross_reference();
  }
}

