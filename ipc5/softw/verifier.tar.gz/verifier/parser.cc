
void Parser::read(char *name, bool trace) {
  yydebug = trace;
  scanner.open_file(name, trace);
  error_flag = false;
  int res = yyparse();
  scanner.close_file();
  if (error_flag || (res > 0)) {
    std::cerr << "res = " << res << std::endl;
    exit(255);
  }
}


