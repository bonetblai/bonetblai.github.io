
#include "plan.h"
#include <algorithm>
#include <sstream>

std::vector<const FADD*> FADD::fadd_;

inline char space_to_uline( char c ) { return( c==' ' ? '_' : c ); }
template<typename T> inline T min( const T &x, const T &y ) { return( x <= y ? x : y ); }

void Plan_Reader::cross_reference() const
{
  action_cref_.reserve( 1+actions_.size() );
  for( size_t j = 0; j < actions_.size(); ++j ) {
    action_cref_[j] = UINT_MAX;
    for( size_t k = 0; k < i_.n_actions(); ++k ) {
      if( actions_[j] == i_.actions[k]->name->to_string() ) {
        action_cref_[j] = k;
        break;
      }
    }
    if( action_cref_[j] == UINT_MAX )
      std::cerr << "Warning: no cross-reference for action '(" << actions_[j] << ")'" << std::endl;
  }
  atom_cref_.reserve( 1+atoms_.size() );
  for( size_t j = 0; j < atoms_.size(); ++j ) {
    atom_cref_[j] = UINT_MAX;
    for( size_t k = 0; k < i_.n_atoms(); ++k ) {
      if( atoms_[j] == i_.atoms[k]->name->to_string() ) {
        atom_cref_[j] = k;
        break;
      }
    }
    if( atom_cref_[j] == UINT_MAX )
      std::cerr << "Warning: no cross-reference for atom '(" << atoms_[j] << ")'" << std::endl;
  }
}

size_t Plan_Reader::action_lookup( size_t a )
{
  if( a >= actions_.size() ) {
    error_ = true;
    std::cerr << "Error: action " << a << " doesn't appear in index" << std::endl;
    return( UINT_MAX );
  }
  size_t act = action_cref_[a];
  if( act == UINT_MAX ) {
    error_ = true;
    std::cerr << "Error: invalid cross-reference for action '(" << actions_[a] << ")'" << std::endl;
    return( UINT_MAX );
  }
  return( act );
}

size_t Plan_Reader::atom_lookup( size_t p )
{
  if( p >= atoms_.size() ) {
    error_ = true;
    std::cerr << "Error: atom " << p << " doesn't appear in index" << std::endl;
    return( UINT_MAX );
  }
  size_t q = atom_cref_[p];
  if( q == UINT_MAX ) {
    error_ = true;
    std::cerr << "Error: invalid cross-reference for atom '(" << atoms_[p] << ")'" << std::endl;
    return( UINT_MAX );
  }
  return( q );
}

std::string Plan_Reader::read_token( std::istream &is )
{
  char c;
  is >> c;
  assert( c == '(' );
  std::string token;
  getline( is, token, ')' );
  std::transform( token.begin(), token.end(), token.begin(), tolower );
  std::transform( token.begin(), token.end(), token.begin(), space_to_uline );
  return( token );
}
 
const Plan* Plan_Reader::read_linear( std::istream &is )
{
  Linear *p = new Linear(i_);
  size_t n;
  is >> n;
  for( size_t k = 0; k < n; ++k ) {
    size_t a;
    is >> a;
    p->push_back( action_lookup(a) );
  }
  return( p );
}

const Plan* Plan_Reader::read_policy( std::istream &is )
{
  State state;
  Policy *p = new Policy(i_);
  size_t n;
  is >> n;
  for( size_t k = 0; k < n; ++k ) {
    size_t m;
    is >> m;
    for( size_t j = 0; j < m; ++j ) {
      size_t p;
      is >> p;
      state.add( atom_lookup(p) );
    }
    size_t a;
    is >> a;
    p->hash_.set_action( new State(state), action_lookup(a) );
    state.clear();
  }
  return( p );
}

const Plan* Plan_Reader::read_factored( std::istream &is )
{
  Factored *p = new Factored(i_);
  size_t n;
  is >> n;
  FADD::fadd_.reserve( n );
  for( size_t k = 0; k < n; ++k ) {
    char type;
    is >> type;
    type = tolower(type);
    if( (type != 'l') && (type != 'i') ) {
      error_ = true;
      std::cerr << "Error: invalid type for node " << k << std::endl;
      continue;
    }
    FADD *f = 0;
    if( type == 'l' ) {
      size_t a;
      is >> a;
      if( a == actions_.size() )
        f = new FADD_Leaf( UINT_MAX );
      else
        f = new FADD_Leaf( action_lookup(a) );
    }
    else {
      size_t p, left, right;
      is >> p >> left >> right;
      f = new FADD_Internal( atom_lookup(p), FADD::fadd_[left], FADD::fadd_[right] );
    }
    assert( f != 0 );
    FADD::fadd_[k] = f;
  }
  p->set_root( FADD::fadd_[n-1] );
  return( p );
}

bool Linear::valid() const
{
  StateSet bel, bel_a, *b = &bel, *b_a = &bel_a, *tmp;

  State s;
  s.apply( *i_.actions[0], *b );

  for( size_t k = 0; k < size(); ++k ) {
#if 0
    std::cout << "bel = " << b->size() << ":{";
    for( StateSet::const_iterator si = b->begin(); si != b->end(); ++si ) {
      std::cout << " "; (*si)->print( std::cout, i_ ); std::cout << ",";
    }
    std::cout << " }" << std::endl;
#endif
    size_t a = (*this)[k];
    for( StateSet::const_iterator si = b->begin(); si != b->end(); ++si ) {
      if( !(*si)->applicable(i_,a) ) {
        std::cerr << "Error: action '" << i_.actions[a]->name << "' isn't applicable in '";
        (*si)->print( std::cerr,i_ );
        std::cerr << "'" << std::endl;
        return( false );
      }
    }
    for( StateSet::const_iterator si = b->begin(); si != b->end(); ) {
      (*si)->apply( *i_.actions[a], *b_a );
      const State *s = *si++;
      delete s;
    }
    b->clear();
    tmp = b;
    b = b_a;
    b_a = tmp;
  }
#if 0
  std::cout << "bel = " << b->size() << ":{";
  for( StateSet::const_iterator si = b->begin(); si != b->end(); ++si ) {
    std::cout << " "; (*si)->print( std::cout, i_ ); std::cout << ",";
  }
  std::cout << " }" << std::endl;
#endif

  for( StateSet::const_iterator si = b->begin(); si != b->end(); ++si ) {
    if( !(*si)->goal(i_) )  {
      std::cerr << "Error: state '";
      (*si)->print( std::cerr, i_ );
      std::cerr << "' isn't goal" << std::endl;
      return( false );
    }
  }
  return( true );
}

void Linear::print( std::ostream &os ) const
{
  os << "(";
  for( size_t k = 0; k < size(); ++k )
    os << i_.actions[(*this)[k]]->name;
  os << ")";
}

bool Policy::valid() const
{
  std::list<Hash::Data*> stack;
  size_t index;
  bool flag = true;

  State s;
  StateSet next;
  s.apply( *i_.actions[0], next );
  for( StateSet::const_iterator si = next.begin(); flag && (si != next.end()); ) {
    try {
      flag = flag && valid( *si, index, stack );
    } catch( std::string e ) {
      std::cerr << e << std::endl;
      flag = false;
      break;
    }
    const State *t = *si++;
    delete t;
  }
  return( flag );
}

bool Policy::valid( const State *s, size_t &index, std::list<Hash::Data*> &stack ) const
{
  if( s->goal(i_) ) return( true );

  StateHash::iterator hi = hash_.find(s);
  if( hi == hash_.end() ) {
    std::ostringstream err;
    err << "Error: policy isn't defined for state '";
    s->print(err,i_);
    err << "'.";
    throw( err.str() );
  }

  Hash::Data *dptr = (*hi).second;
  if( dptr->solved() ) return( true );

  size_t a = dptr->action();
  if( !s->applicable(i_,a) ) {
    std::cerr << "Error: action '" << i_.actions[a]->name << "' isn't applicable in '";
    s->print( std::cerr,i_ );
    std::cerr << "'." << std::endl;
    return( false );
  }

  // Tarjan's
  stack.push_front( dptr );
  size_t idx = index++;
  dptr->set_scc_low( idx );
  dptr->set_scc_idx( idx );

  bool flag = false;
  StateSet next;
  s->apply( *i_.actions[a], next );
  for( StateSet::const_iterator si = next.begin(); si != next.end(); ) {
    if( (*si)->goal(i_) )
      flag = true;
    else {
      StateHash::iterator hi = hash_.find(*si);
      if( hi == hash_.end() ) {
        std::ostringstream err;
        err << "Error: policy isn't defined for state '";
        (*si)->print(err,i_);
        err << "'.";
        throw( err.str() );
      }
      Hash::Data *ptr = (*hi).second;
      if( ptr->scc_idx() == UINT_MAX ) {
        bool rv = valid( *si, index, stack );
        flag = flag || rv;
        dptr->set_scc_low( min( dptr->scc_low(), ptr->scc_low() ) );
      }
      else {
        dptr->set_scc_low( min( dptr->scc_low(), ptr->scc_idx() ) );
        flag = flag || ptr->solved();
      }
    }
    const State *t = *si++;
    delete t;
  }
  if( flag ) dptr->solve();

  if( dptr->scc_low() == idx ) {
    flag = false;
    assert( stack.front()->scc_idx() >= idx );
    for( std::list<Hash::Data*>::iterator si = stack.begin(); (si != stack.end()) && ((*si)->scc_idx() >= idx); ++si )
      flag = flag || (*si)->solved();
    while( !stack.empty() && (stack.front()->scc_idx() >= idx) ) {
      if( flag ) stack.front()->solve();
      stack.pop_front();
    }
  }
  return( flag );
}

void Policy::print( std::ostream &os ) const
{
  hash_.dump( os );
}

bool Factored::valid() const
{
  std::list<Hash::Data*> stack;
  size_t index;
  bool flag = true;

  State s;
  StateSet next;
  s.apply( *i_.actions[0], next );
  for( StateSet::const_iterator si = next.begin(); flag && (si != next.end()); ) {
    try {
      flag = flag && valid( *si, index, stack );
    } catch( std::string e ) {
      std::cerr << e << std::endl;
      flag = false;
      break;
    }
    const State *t = *si++;
    delete t;
  }
  return( flag );
}

bool Factored::valid( const State *s, size_t &index, std::list<Hash::Data*> &stack ) const
{
  if( s->goal(i_) ) return( true );

  size_t a = root_->lookup( *s );
  if( a == UINT_MAX ) {
    std::cerr << "Error: policy isn't defined for state '";
    s->print( std::cerr, i_ );
    std::cerr << "'" << std::endl;
    return( false );
  }

  Hash::Data *dptr = hash_.data_ptr( s );
  if( dptr->solved() ) return( true );

  if( !s->applicable(i_,a) ) {
    std::cerr << "Error: action '" << i_.actions[a]->name << "' isn't applicable in '";
    s->print( std::cerr,i_ );
    std::cerr << "'." << std::endl;
    return( false );
  }

  // Tarjan's
  stack.push_front( dptr );
  size_t idx = index++;
  dptr->set_scc_low( idx );
  dptr->set_scc_idx( idx );

  bool flag = false;
  StateSet next;
  s->apply( *i_.actions[a], next );
  for( StateSet::const_iterator si = next.begin(); si != next.end(); ) {
    if( (*si)->goal(i_) )
      flag = true;
    else {
      if( root_->lookup(**si) == UINT_MAX ) {
        std::ostringstream err;
        err << "Error: policy isn't defined for state '";
        (*si)->print(err,i_);
        err << "'." << std::endl << **si;
        throw( err.str() );
      }
      Hash::Data *ptr = hash_.data_ptr(*si);
      if( ptr->scc_idx() == UINT_MAX ) {
        bool rv = valid( *si, index, stack );
        flag = flag || rv;
        dptr->set_scc_low( min( dptr->scc_low(), ptr->scc_low() ) );
      }
      else {
        dptr->set_scc_low( min( dptr->scc_low(), ptr->scc_idx() ) );
        flag = flag || ptr->solved();
      }
    }
    const State *t = *si++;
    delete t;
  }
  if( flag ) dptr->solve();

  if( dptr->scc_low() == idx ) {
    flag = false;
    assert( stack.front()->scc_idx() >= idx );
    for( std::list<Hash::Data*>::iterator si = stack.begin(); (si != stack.end()) && ((*si)->scc_idx() >= idx); ++si )
      flag = flag || (*si)->solved();
    while( !stack.empty() && (stack.front()->scc_idx() >= idx) ) {
      if( flag ) stack.front()->solve();
      stack.pop_front();
    }
  }
  return( flag );
}

