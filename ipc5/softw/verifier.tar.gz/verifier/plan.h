#ifndef PLAN_H
#define PLAN_H

#include "problem.h"
#include "state.h"
#include <iostream>
#include <fstream>
#include <list>
#include <map>
#include <assert.h>

class Plan;
class FADD;

class Plan_Reader {
  bool error_;
  const Instance &i_;
  std::vector<std::string> atoms_;
  std::vector<std::string> actions_;;
  mutable std::vector<size_t> atom_cref_;
  mutable std::vector<size_t> action_cref_;
  void cross_reference() const;
  size_t action_lookup( size_t a );
  size_t atom_lookup( size_t a );

public:
  Plan_Reader( const Instance  &i ) : error_(false), i_(i) { }
  bool error() const { return( error_ ); }
  const Plan* read( const char *name )
  {
    std::ifstream is( name );
    read_index( is, atoms_ );
    read_index( is, actions_ );
    cross_reference();
    const Plan *plan = read_plan( is );
    is.close();
    return( plan );
  }
  void read_index( std::istream &is, std::vector<std::string> &index )
  {
    size_t n;
    is >> n;
    for( size_t k = 0; k < n; ++k ) read_object( is, index );
    read_separator( is );
  }
  void read_object( std::istream &is, std::vector<std::string> &index ) { index.push_back( read_token(is) ); }
  const Plan* read_linear( std::istream &is );
  const Plan* read_policy( std::istream &is );
  const Plan* read_factored( std::istream &is );
  const Plan* read_plan( std::istream &is )
  {
    std::string type;
    is >> type;
    if( type == "linear" )
      return( read_linear(is) );
    else if( type == "policy" )
      return( read_policy(is) );
    else if( type == "factored" )
      return( read_factored(is) );
    else {
      std::cerr << "Error: invalid plan type" << std::endl;
      error_ = true;
      return( 0 );
    }
  }
  std::string read_token( std::istream &is );
  void read_separator( std::istream &is )
  {
    for( size_t k = 0; k < 2; ++k ) {
      char c;
      is >> c;
      if( c != '%' ) {
        std::cerr << "Error: invalid separator" << std::endl;
        error_ = true;
      }
    }
  }
};

class Plan {
protected:
  const Instance &i_;
public:
  Plan ( const Instance &i ) : i_(i) { }
  virtual bool valid() const = 0;
  virtual float cost() const = 0;
  virtual void print( std::ostream &os ) const = 0;
  virtual void write( std::ostream &os ) const = 0;
};

inline std::ostream& operator<<( std::ostream& os, const Plan &p )
{
  p.print( os );
  return( os );
}

class Linear : public Plan, public std::vector<size_t> {
public:
  Linear( const Instance &i ) : Plan(i) { }
  virtual bool valid() const;
  virtual float cost() const { return( size() ); }
  virtual void print( std::ostream &os ) const;
  virtual void write( std::ostream &os ) const { }
};

class Policy : public Plan {
protected:
  mutable StateHash hash_;
public:
  Policy( const Instance &i ) : Plan(i) { }
  bool valid( const State *s, size_t &index, std::list<Hash::Data*> &stack ) const;
  virtual bool valid() const;
  virtual float cost() const { return( hash_.size() ); }
  virtual void print( std::ostream &os ) const;
  virtual void write( std::ostream &os ) const { }
  friend const Plan* Plan_Reader::read_policy( std::istream& );
};

class FADD {
protected:
  static std::vector<const FADD*> fadd_;
public:
  FADD() { }
  virtual size_t lookup( const State &s ) const = 0;
  virtual void write( std::ostream &os ) const = 0;
  friend const Plan* Plan_Reader::read_factored( std::istream& );
  friend class Factored;
};

class Factored : public Plan {
protected:
  const FADD *root_;
  mutable StateHash hash_;
public:
  Factored( const Instance &i ) : Plan(i), root_(0) { }
  bool valid( const State *s, size_t &index, std::list<Hash::Data*> &stack ) const;
  void set_root( const FADD *f ) { root_ = f; }
  virtual bool valid() const;
  virtual float cost() const { return( 1 ); }
  virtual void print( std::ostream &os ) const { write(os); }
  virtual void write( std::ostream &os ) const { root_->write(os); }
};

class FADD_Leaf : public FADD {
  size_t a_;
public:
  FADD_Leaf( size_t a ) : a_(a) { }
  size_t a() const { return( a_ ); }
  virtual size_t lookup( const State &s ) const { return( a_ ); }
  virtual void write( std::ostream &os ) const { os << this << ": L " << a_ << std::endl; }
};

class FADD_Internal : public FADD {
  size_t p_;
  const FADD *left_, *right_;
public:
  FADD_Internal( size_t p, const FADD *left, const FADD *right ) : p_(p), left_(left), right_(right) { }
  size_t p() const { return( p_ ); }
  const FADD* left() const { return( left_ ); }
  const FADD* right() const { return( right_ ); }
  virtual size_t lookup( const State &s ) const { return( s.satisfy(p_) ? left_->lookup(s) : right_->lookup(s) ); }
  virtual void write( std::ostream &os ) const { left_->write(os); right_->write(os); os << this << ": I " << p_ << " " << (void*)left_ << " " << (void*)right_ << std::endl; }
};

#endif
