#ifndef PARSER_H
#define INPUT_H

#include "scanner.h"
#include "grammar.h"
#include <stdlib.h>
#include <stdio.h>

class Parser : public PDDL_Parser {
  PDDL_Scanner scanner;
 public:
  Parser(StringTable& t) : PDDL_Parser(t), scanner(t) { };

  void read(char *name, bool trace)
  {
    yydebug = trace;
    scanner.open_file(name, trace);
    error_flag = false;
    int res = yyparse();
    scanner.close_file();
    if (error_flag || (res > 0)) {
      std::cerr << "res = " << res << std::endl;
      exit(255);
    }
  }
  virtual int next_token() { return scanner.next_token(yylval); }
  virtual void log_error(char* msg) { syntax_errors() << msg << std::endl; error_flag = true; }
  std::ostream& syntax_errors()
  {
    if (scanner.current_file())
      return std::cerr << "syntax error at " << scanner.current_file() << ":" << scanner.current_line() << ": ";
    else
      return std::cerr << "syntax error at " << scanner.current_line() << ": ";
  }
};

#endif
