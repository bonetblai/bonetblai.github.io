#ifndef YY_PDDL_Parser_h_included
#define YY_PDDL_Parser_h_included
#define YY_USE_CLASS

#line 1 "/opt/sfw/share/bison++/bison.h"
/* before anything */
#ifdef c_plusplus
 #ifndef __cplusplus
  #define __cplusplus
 #endif
#endif


 #line 8 "/opt/sfw/share/bison++/bison.h"
#define YY_PDDL_Parser_ERROR  log_error
#define YY_PDDL_Parser_ERROR_BODY  = 0
#define YY_PDDL_Parser_ERROR_VERBOSE  1
#define YY_PDDL_Parser_LEX  next_token
#define YY_PDDL_Parser_LEX_BODY  = 0
#define YY_PDDL_Parser_DEBUG  1
#define YY_PDDL_Parser_INHERIT  : public PDDL_Base
#define YY_PDDL_Parser_CONSTRUCTOR_PARAM  StringTable& t
#define YY_PDDL_Parser_CONSTRUCTOR_INIT  : PDDL_Base(t), error_flag(false), \
  stored_n_param(0), current_atom(0)
#define YY_PDDL_Parser_MEMBERS  \
public: \
virtual std::ostream& syntax_errors() = 0; \
bool    error_flag; \
private: \
variable_vec        current_param; \
size_t              stored_n_param; \
AtomBase*           current_atom; \
std::list<Effect *> context; \

#line 23 "ppddl.y"

#include <stdlib.h>
#include <string.h>
#include <list>
#include "base.h"

#line 30 "ppddl.y"
typedef union {
  StringTable::Cell*     sym;
  PDDL_Base::Clause*     clause;
  PDDL_Base::OneOf*      oneof;
  int                    ival;
} yy_PDDL_Parser_stype;
#define YY_PDDL_Parser_STYPE yy_PDDL_Parser_stype

#line 21 "/opt/sfw/share/bison++/bison.h"
 /* %{ and %header{ and %union, during decl */
#ifndef YY_PDDL_Parser_COMPATIBILITY
 #ifndef YY_USE_CLASS
  #define  YY_PDDL_Parser_COMPATIBILITY 1
 #else
  #define  YY_PDDL_Parser_COMPATIBILITY 0
 #endif
#endif

#if YY_PDDL_Parser_COMPATIBILITY != 0
/* backward compatibility */
 #ifdef YYLTYPE
  #ifndef YY_PDDL_Parser_LTYPE
   #define YY_PDDL_Parser_LTYPE YYLTYPE
/* WARNING obsolete !!! user defined YYLTYPE not reported into generated header */
/* use %define LTYPE */
  #endif
 #endif
/*#ifdef YYSTYPE*/
  #ifndef YY_PDDL_Parser_STYPE
   #define YY_PDDL_Parser_STYPE YYSTYPE
  /* WARNING obsolete !!! user defined YYSTYPE not reported into generated header */
   /* use %define STYPE */
  #endif
/*#endif*/
 #ifdef YYDEBUG
  #ifndef YY_PDDL_Parser_DEBUG
   #define  YY_PDDL_Parser_DEBUG YYDEBUG
   /* WARNING obsolete !!! user defined YYDEBUG not reported into generated header */
   /* use %define DEBUG */
  #endif
 #endif 
 /* use goto to be compatible */
 #ifndef YY_PDDL_Parser_USE_GOTO
  #define YY_PDDL_Parser_USE_GOTO 1
 #endif
#endif

/* use no goto to be clean in C++ */
#ifndef YY_PDDL_Parser_USE_GOTO
 #define YY_PDDL_Parser_USE_GOTO 0
#endif

#ifndef YY_PDDL_Parser_PURE

 #line 65 "/opt/sfw/share/bison++/bison.h"

#line 65 "/opt/sfw/share/bison++/bison.h"
/* YY_PDDL_Parser_PURE */
#endif


 #line 68 "/opt/sfw/share/bison++/bison.h"

#line 68 "/opt/sfw/share/bison++/bison.h"
/* prefix */

#ifndef YY_PDDL_Parser_DEBUG

 #line 71 "/opt/sfw/share/bison++/bison.h"

#line 71 "/opt/sfw/share/bison++/bison.h"
/* YY_PDDL_Parser_DEBUG */
#endif

#ifndef YY_PDDL_Parser_LSP_NEEDED

 #line 75 "/opt/sfw/share/bison++/bison.h"

#line 75 "/opt/sfw/share/bison++/bison.h"
 /* YY_PDDL_Parser_LSP_NEEDED*/
#endif

/* DEFAULT LTYPE*/
#ifdef YY_PDDL_Parser_LSP_NEEDED
 #ifndef YY_PDDL_Parser_LTYPE
  #ifndef BISON_YYLTYPE_ISDECLARED
   #define BISON_YYLTYPE_ISDECLARED
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;
  #endif

  #define YY_PDDL_Parser_LTYPE yyltype
 #endif
#endif

/* DEFAULT STYPE*/
#ifndef YY_PDDL_Parser_STYPE
 #define YY_PDDL_Parser_STYPE int
#endif

/* DEFAULT MISCELANEOUS */
#ifndef YY_PDDL_Parser_PARSE
 #define YY_PDDL_Parser_PARSE yyparse
#endif

#ifndef YY_PDDL_Parser_LEX
 #define YY_PDDL_Parser_LEX yylex
#endif

#ifndef YY_PDDL_Parser_LVAL
 #define YY_PDDL_Parser_LVAL yylval
#endif

#ifndef YY_PDDL_Parser_LLOC
 #define YY_PDDL_Parser_LLOC yylloc
#endif

#ifndef YY_PDDL_Parser_CHAR
 #define YY_PDDL_Parser_CHAR yychar
#endif

#ifndef YY_PDDL_Parser_NERRS
 #define YY_PDDL_Parser_NERRS yynerrs
#endif

#ifndef YY_PDDL_Parser_DEBUG_FLAG
 #define YY_PDDL_Parser_DEBUG_FLAG yydebug
#endif

#ifndef YY_PDDL_Parser_ERROR
 #define YY_PDDL_Parser_ERROR yyerror
#endif

#ifndef YY_PDDL_Parser_PARSE_PARAM
 #ifndef __STDC__
  #ifndef __cplusplus
   #ifndef YY_USE_CLASS
    #define YY_PDDL_Parser_PARSE_PARAM
    #ifndef YY_PDDL_Parser_PARSE_PARAM_DEF
     #define YY_PDDL_Parser_PARSE_PARAM_DEF
    #endif
   #endif
  #endif
 #endif
 #ifndef YY_PDDL_Parser_PARSE_PARAM
  #define YY_PDDL_Parser_PARSE_PARAM void
 #endif
#endif

/* TOKEN C */
#ifndef YY_USE_CLASS

 #ifndef YY_PDDL_Parser_PURE
  #ifndef yylval
   extern YY_PDDL_Parser_STYPE YY_PDDL_Parser_LVAL;
  #else
   #if yylval != YY_PDDL_Parser_LVAL
    extern YY_PDDL_Parser_STYPE YY_PDDL_Parser_LVAL;
   #else
    #warning "Namespace conflict, disabling some functionality (bison++ only)"
   #endif
  #endif
 #endif


 #line 169 "/opt/sfw/share/bison++/bison.h"
#define	TK_OPEN	258
#define	TK_CLOSE	259
#define	TK_OPEN_SQ	260
#define	TK_CLOSE_SQ	261
#define	TK_EQ	262
#define	TK_HYPHEN	263
#define	TK_NEW_SYMBOL	264
#define	TK_OBJ_SYMBOL	265
#define	TK_TYPE_SYMBOL	266
#define	TK_PRED_SYMBOL	267
#define	TK_FUN_SYMBOL	268
#define	TK_VAR_SYMBOL	269
#define	TK_ACTION_SYMBOL	270
#define	TK_MISC_SYMBOL	271
#define	TK_KEYWORD	272
#define	TK_NEW_VAR_SYMBOL	273
#define	TK_INT	274
#define	KW_REQS	275
#define	KW_CONSTANTS	276
#define	KW_PREDS	277
#define	KW_TYPES	278
#define	KW_DEFINE	279
#define	KW_DOMAIN	280
#define	KW_ACTION	281
#define	KW_ARGS	282
#define	KW_PRE	283
#define	KW_COND	284
#define	KW_EFFECT	285
#define	KW_AND	286
#define	KW_OR	287
#define	KW_EXISTS	288
#define	KW_FORALL	289
#define	KW_IMPLY	290
#define	KW_NOT	291
#define	KW_WHEN	292
#define	KW_ONEOF	293
#define	KW_PROBLEM	294
#define	KW_FORDOMAIN	295
#define	KW_OBJECTS	296
#define	KW_INIT	297
#define	KW_GOAL	298
#define	KW_NAME	299


#line 169 "/opt/sfw/share/bison++/bison.h"
 /* #defines token */
/* after #define tokens, before const tokens S5*/
#else
 #ifndef YY_PDDL_Parser_CLASS
  #define YY_PDDL_Parser_CLASS PDDL_Parser
 #endif

 #ifndef YY_PDDL_Parser_INHERIT
  #define YY_PDDL_Parser_INHERIT
 #endif

 #ifndef YY_PDDL_Parser_MEMBERS
  #define YY_PDDL_Parser_MEMBERS 
 #endif

 #ifndef YY_PDDL_Parser_LEX_BODY
  #define YY_PDDL_Parser_LEX_BODY  
 #endif

 #ifndef YY_PDDL_Parser_ERROR_BODY
  #define YY_PDDL_Parser_ERROR_BODY  
 #endif

 #ifndef YY_PDDL_Parser_CONSTRUCTOR_PARAM
  #define YY_PDDL_Parser_CONSTRUCTOR_PARAM
 #endif
 /* choose between enum and const */
 #ifndef YY_PDDL_Parser_USE_CONST_TOKEN
  #define YY_PDDL_Parser_USE_CONST_TOKEN 0
  /* yes enum is more compatible with flex,  */
  /* so by default we use it */ 
 #endif
 #if YY_PDDL_Parser_USE_CONST_TOKEN != 0
  #ifndef YY_PDDL_Parser_ENUM_TOKEN
   #define YY_PDDL_Parser_ENUM_TOKEN yy_PDDL_Parser_enum_token
  #endif
 #endif

class YY_PDDL_Parser_CLASS YY_PDDL_Parser_INHERIT
{
public: 
 #if YY_PDDL_Parser_USE_CONST_TOKEN != 0
  /* static const int token ... */
  
 #line 212 "/opt/sfw/share/bison++/bison.h"
static const int TK_OPEN;
static const int TK_CLOSE;
static const int TK_OPEN_SQ;
static const int TK_CLOSE_SQ;
static const int TK_EQ;
static const int TK_HYPHEN;
static const int TK_NEW_SYMBOL;
static const int TK_OBJ_SYMBOL;
static const int TK_TYPE_SYMBOL;
static const int TK_PRED_SYMBOL;
static const int TK_FUN_SYMBOL;
static const int TK_VAR_SYMBOL;
static const int TK_ACTION_SYMBOL;
static const int TK_MISC_SYMBOL;
static const int TK_KEYWORD;
static const int TK_NEW_VAR_SYMBOL;
static const int TK_INT;
static const int KW_REQS;
static const int KW_CONSTANTS;
static const int KW_PREDS;
static const int KW_TYPES;
static const int KW_DEFINE;
static const int KW_DOMAIN;
static const int KW_ACTION;
static const int KW_ARGS;
static const int KW_PRE;
static const int KW_COND;
static const int KW_EFFECT;
static const int KW_AND;
static const int KW_OR;
static const int KW_EXISTS;
static const int KW_FORALL;
static const int KW_IMPLY;
static const int KW_NOT;
static const int KW_WHEN;
static const int KW_ONEOF;
static const int KW_PROBLEM;
static const int KW_FORDOMAIN;
static const int KW_OBJECTS;
static const int KW_INIT;
static const int KW_GOAL;
static const int KW_NAME;


#line 212 "/opt/sfw/share/bison++/bison.h"
 /* decl const */
 #else
  enum YY_PDDL_Parser_ENUM_TOKEN { YY_PDDL_Parser_NULL_TOKEN=0
  
 #line 215 "/opt/sfw/share/bison++/bison.h"
	,TK_OPEN=258
	,TK_CLOSE=259
	,TK_OPEN_SQ=260
	,TK_CLOSE_SQ=261
	,TK_EQ=262
	,TK_HYPHEN=263
	,TK_NEW_SYMBOL=264
	,TK_OBJ_SYMBOL=265
	,TK_TYPE_SYMBOL=266
	,TK_PRED_SYMBOL=267
	,TK_FUN_SYMBOL=268
	,TK_VAR_SYMBOL=269
	,TK_ACTION_SYMBOL=270
	,TK_MISC_SYMBOL=271
	,TK_KEYWORD=272
	,TK_NEW_VAR_SYMBOL=273
	,TK_INT=274
	,KW_REQS=275
	,KW_CONSTANTS=276
	,KW_PREDS=277
	,KW_TYPES=278
	,KW_DEFINE=279
	,KW_DOMAIN=280
	,KW_ACTION=281
	,KW_ARGS=282
	,KW_PRE=283
	,KW_COND=284
	,KW_EFFECT=285
	,KW_AND=286
	,KW_OR=287
	,KW_EXISTS=288
	,KW_FORALL=289
	,KW_IMPLY=290
	,KW_NOT=291
	,KW_WHEN=292
	,KW_ONEOF=293
	,KW_PROBLEM=294
	,KW_FORDOMAIN=295
	,KW_OBJECTS=296
	,KW_INIT=297
	,KW_GOAL=298
	,KW_NAME=299


#line 215 "/opt/sfw/share/bison++/bison.h"
 /* enum token */
     }; /* end of enum declaration */
 #endif
public:
 int YY_PDDL_Parser_PARSE(YY_PDDL_Parser_PARSE_PARAM);
 virtual void YY_PDDL_Parser_ERROR(char *msg) YY_PDDL_Parser_ERROR_BODY;
 #ifdef YY_PDDL_Parser_PURE
  #ifdef YY_PDDL_Parser_LSP_NEEDED
   virtual int  YY_PDDL_Parser_LEX(YY_PDDL_Parser_STYPE *YY_PDDL_Parser_LVAL,YY_PDDL_Parser_LTYPE *YY_PDDL_Parser_LLOC) YY_PDDL_Parser_LEX_BODY;
  #else
   virtual int  YY_PDDL_Parser_LEX(YY_PDDL_Parser_STYPE *YY_PDDL_Parser_LVAL) YY_PDDL_Parser_LEX_BODY;
  #endif
 #else
  virtual int YY_PDDL_Parser_LEX() YY_PDDL_Parser_LEX_BODY;
  YY_PDDL_Parser_STYPE YY_PDDL_Parser_LVAL;
  #ifdef YY_PDDL_Parser_LSP_NEEDED
   YY_PDDL_Parser_LTYPE YY_PDDL_Parser_LLOC;
  #endif
  int YY_PDDL_Parser_NERRS;
  int YY_PDDL_Parser_CHAR;
 #endif
 #if YY_PDDL_Parser_DEBUG != 0
  public:
   int YY_PDDL_Parser_DEBUG_FLAG;	/*  nonzero means print parse trace	*/
 #endif
public:
 YY_PDDL_Parser_CLASS(YY_PDDL_Parser_CONSTRUCTOR_PARAM);
public:
 YY_PDDL_Parser_MEMBERS 
};
/* other declare folow */
#endif


#if YY_PDDL_Parser_COMPATIBILITY != 0
 /* backward compatibility */
 /* Removed due to bison problems
 /#ifndef YYSTYPE
 / #define YYSTYPE YY_PDDL_Parser_STYPE
 /#endif*/

 #ifndef YYLTYPE
  #define YYLTYPE YY_PDDL_Parser_LTYPE
 #endif
 #ifndef YYDEBUG
  #ifdef YY_PDDL_Parser_DEBUG 
   #define YYDEBUG YY_PDDL_Parser_DEBUG
  #endif
 #endif

#endif
/* END */

 #line 267 "/opt/sfw/share/bison++/bison.h"
#endif
