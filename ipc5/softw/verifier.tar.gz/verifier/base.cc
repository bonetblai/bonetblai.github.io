
#include "base.h"
#include <stdlib.h>
#include <iomanip>

bool PDDL_Base::write_warnings = true;
bool PDDL_Base::write_info = true;

PDDL_Base::PDDL_Base(StringTable& t)
  : domain_name(0), problem_name(0),
    ready_to_instantiate(false), tab(t), dom_top_type(0)
{
  StringTable::Cell* sc = tab.inserta("object");
  dom_top_type = new TypeSymbol(sc->text);
  sc->val = dom_top_type;
  sc = tab.inserta("=");
  dom_eq_pred = new PredicateSymbol(sc->text);
  sc->val = dom_eq_pred;
  //dom_eq_pred->n_param = 2;
}

PDDL_Base::~PDDL_Base() {
}

void PDDL_Base::set_variable_type(variable_vec& vec, size_t n, TypeSymbol* t)
{
  for (size_t k = n; k > 0; k--) {
    if (vec[k-1]->sym_type != 0) return;
    vec[k-1]->sym_type = t;
  }
}

void PDDL_Base::set_type_type(type_vec& vec, size_t n, TypeSymbol* t)
{
  for (size_t k = vec.size(); k > 0; k--) {
    if (vec[k-1]->sym_type != 0) return;
    vec[k-1]->sym_type = t;
  }
}

void PDDL_Base::set_constant_type(symbol_vec& vec, size_t n, TypeSymbol* t)
{
  for (size_t k = n; k > 0; k--) {
    if (vec[k-1]->sym_type != 0) return;
    vec[k-1]->sym_type = t;
    t->add_element(vec[k-1]);
  }
}

void PDDL_Base::clear_param( variable_vec& vec, size_t start )
{
  for( size_t k = start; k < vec.size(); ++k )
    tab.set( vec[k]->print_name, (void*)0 );
}

void PDDL_Base::TypeSymbol::add_element(Symbol* e)
{
  elements.push_back( e );
  if (sym_type != 0) ((TypeSymbol*)sym_type)->add_element(e);
}

bool PDDL_Base::AtomBase::equals(AtomBase& b)
{
  if (param.size() != b.param.size()) return false;
  for (size_t k = 0; k < param.size(); k++)
    if (param[k] != b.param[k]) return false;
  return true;
}

bool PDDL_Base::Atom::equals(Atom& a)
{
  if (pred != a.pred) return false;
  return AtomBase::equals(a);
}

Instance::Atom*
PDDL_Base::Atom::find_prop(Instance& ins, bool neg, bool create)
{
  ptr_table* r = (neg ? &(pred->neg_prop) : &(pred->pos_prop));
  for (size_t k = 0; k < param.size(); k++) {
    if (param[k]->sym_class == sym_variable)
      r = r->insert_next(((VariableSymbol*)param[k])->value);
    else
      r = r->insert_next(param[k]);
  }
  if (!r->val) {
    if (!create) return 0;
    PDDL_Name* a_name = new PDDL_Name(pred, neg);
    for (size_t k = 0; k < param.size(); k++) {
      if (param[k]->sym_class == sym_variable)
	a_name->add(((VariableSymbol*)param[k])->value);
      else
	a_name->add(param[k]);
    }

    Instance::Atom& p = ins.new_atom(a_name);
    bool init_val = false;
    p.init = (init_val != neg);
    r->val = &p;
  }
  Instance::Atom *pp = (Instance::Atom*)r->val;
  return (Instance::Atom*)r->val;
}

void PDDL_Base::insert_atom(ptr_table& t, AtomBase* a)
{
  ptr_table* r = &t;
  for (size_t k = 0; k < a->param.size(); k++)
    r = r->insert_next(a->param[k]);
  r->val = a;
}

void PDDL_Base::ActionSymbol::post_process()
{
}

void PDDL_Base::post_process()
{
  for( size_t k = 0; k < dom_actions.size(); ++k )
    dom_actions[k]->post_process();
  ready_to_instantiate = true;
}

size_t PDDL_Base::ActionSymbol::param_index(VariableSymbol* p)
{
  for( size_t k = 0; k < param.size(); ++k )
    if( param[k] == p ) return k;
  return no_such_index;
}

void PDDL_Base::ActionSymbol::build( Instance& ins, size_t p )
{
  if( p < param.size() ) {
    TypeSymbol* t = (TypeSymbol*)param[p]->sym_type;
    for( size_t k = 0; k < t->elements.size(); ++k ) {
      param[p]->value = t->elements[k];
      build( ins, p+1 );
    }
    param[p]->value = 0;
  }
  else {
    Instance::Action& act = ins.new_action( new PDDL_Name(this,param,param.size()) );
    for( size_t k = 0; k < pos_atm.size(); ++k ) {
      Instance::Atom* pp = pos_atm[k]->find_prop( ins, false, true );
      act.pre.insert( 1+pp->index );
    }
    for( size_t k = 0; k < neg_atm.size(); ++k ) {
      Instance::Atom* np = neg_atm[k]->find_prop( ins, false, true );
      act.pre.insert( -(1+np->index) );
    }
    Complex::build_effects( ins, act, true );

    for( size_t k = 0; k < oneof.size(); ++k )
      oneof[k]->build_effects( ins, act );

    for( size_t k = 0; k < complex.size(); ++k ) {
      for( size_t j = 0; j < p; ++j )
        complex[k]->param[j]->value = param[j]->value;
      complex[k]->build( ins, p, act );
    }

    act.cost = 1;
  }
}

void PDDL_Base::ActionSymbol::instantiate( Instance& ins )
{
  for( size_t k = 0; k < param.size(); ++k ) param[k]->value = 0;
  build( ins, 0 );
}

void PDDL_Base::Complex::build( Instance& ins, size_t p, Instance::Action &act  )
{
  if( p < param.size() ) {
    TypeSymbol* t = (TypeSymbol*)param[p]->sym_type;
    for( size_t k = 0; k < t->elements.size(); ++k ) {
      param[p]->value = t->elements[k];
      build( ins, p+1, act );
    }
    param[p]->value = 0;
  }
  else {
    build_effects( ins, act, false );
  }
}

void PDDL_Base::Complex::build_effects( Instance& ins, Instance::Action& act, bool topl )
{
  for( size_t k = 0; k < clauses.size(); ++k )
    clauses[k]->build_clauses( ins, act.cls );

  if( topl || (neg_atm.empty() && pos_atm.empty()) ) {
    for (size_t k = 0; k < adds.size(); k++)  {
      Instance::Atom* pp = adds[k]->find_prop(ins, false, true);
      act.add.insert(pp->index);
    }
    for (size_t k = 0; k < dels.size(); k++)  {
      Instance::Atom* pp = dels[k]->find_prop(ins, false, true);
      act.del.insert(pp->index);
    }
  }
  else {
    Instance::When w;
    for( size_t k = 0; k < pos_atm.size(); ++k ) {
      Instance::Atom* pp = pos_atm[k]->find_prop( ins, false, true );
      w.pre.insert( 1+pp->index );
    }
    for( size_t k = 0; k < neg_atm.size(); ++k ) {
      Instance::Atom* np = neg_atm[k]->find_prop( ins, false, true );
      w.pre.insert( -(1+np->index) );
    }
    for (size_t k = 0; k < adds.size(); k++)  {
      Instance::Atom* pp = adds[k]->find_prop(ins, false, true);
      w.add.insert(pp->index);
    }
    for (size_t k = 0; k < dels.size(); k++)  {
      Instance::Atom* pp = dels[k]->find_prop(ins, false, true);
      w.del.insert(pp->index);
    }
    act.when.push_back( w );
  }
}

void PDDL_Base::Clause::build_clauses( Instance &ins, index_vec_vec &cls )
{
  index_vec cl;
  for (size_t k = 0; k < pos_atm.size(); k++)  {
    Instance::Atom* pp = pos_atm[k]->find_prop(ins, false, true);
    cl.push_back(1+pp->index);
  }
  for (size_t k = 0; k < neg_atm.size(); k++)  {
    Instance::Atom* pp = neg_atm[k]->find_prop(ins, false, true);
    cl.push_back(-(1+pp->index));
  }
  cls.push_back( cl );
}

void PDDL_Base::OneOf::build_effects( Instance &ins, Instance::Action &act )
{
  index_vec oneof;
  for (size_t k = 0; k < adds.size(); k++)  {
    Instance::Atom* pp = adds[k]->find_prop(ins, false, true);
    oneof.push_back(1+pp->index);
  }
  for (size_t k = 0; k < dels.size(); k++)  {
    Instance::Atom* pp = dels[k]->find_prop(ins, false, true);
    oneof.push_back(-(1+pp->index));
  }
  act.oneof.push_back( oneof );
}

void PDDL_Base::instantiate( Instance& ins )
{
  if( !ready_to_instantiate ) post_process();

  for (size_t k = 0; k < dom_constants.size(); k++) {
    Atom* a = new Atom(dom_eq_pred);
    a->param.push_back( dom_constants[k] );
    a->param.push_back( dom_constants[k] );
  }

  ins.name =
    new InstanceName(domain_name ? tab.table_char_map().strdup(domain_name) :
		     tab.table_char_map().strdup("??"),
		     problem_name ? tab.table_char_map().strdup(problem_name) :
		     tab.table_char_map().strdup("??"));

  ActionSymbol *init = new ActionSymbol( ":init-action" );
  for( size_t k = 0; k < dom_init_atoms.size(); ++k ) {
    if( !dom_init_atoms[k]->neg )
      init->adds.push_back( dom_init_atoms[k] );
    else
      init->dels.push_back( dom_init_atoms[k] );
  }
  init->clauses = dom_init_cls;
  init->oneof = dom_init_oneof;
  init->build( ins, 0 );

  for (size_t k = 0; k < dom_actions.size(); k++)
    dom_actions[k]->instantiate(ins);

  for (size_t k = 0; k < dom_goal_pos.size(); k++) {
    Instance::Atom* p = dom_goal_pos[k]->find_prop(ins, false, true);
    p->goal = true;
  }
  for (size_t k = 0; k < dom_goal_neg.size(); k++) {
    Instance::Atom* p = dom_goal_neg[k]->find_prop(ins, true, true);
    p->goal = true;
  }
  for( size_t k = 0; k < dom_goal_cls.size(); ++k )
    dom_goal_cls[k]->build_clauses( ins, ins.goal_cls );
}

PDDL_Base::PredicateSymbol*
PDDL_Base::find_type_predicate(Symbol* type_sym)
{
  for (size_t k = 0; k < dom_predicates.size(); k++)
    if (dom_predicates[k]->print_name == type_sym->print_name)
      return dom_predicates[k];
  std::cerr << "error: no type predicate found for type "
	    << type_sym->print_name << std::endl;
  exit(255);
}

void PDDL_Base::TypeSymbol::print(std::ostream& s)
{
  s << "(:type " << print_name;
  if (sym_type) s << " - " << sym_type->print_name;
  s << "): {";
  for (size_t k = 0; k < elements.size(); k++) {
    elements[k]->print(s);
    if (k < elements.size() - 1) s << ", ";
  }
  s << "}" << std::endl;
}

void PDDL_Base::PredicateSymbol::print(std::ostream& s)
{
  s << "(:predicate " << print_name;
  for (size_t k = 0; k < param.size(); k++) {
    s << " ";
    param[k]->print(s);
  }
  s << ")" << std::endl;
}

void PDDL_Base::OneOf::print( std::ostream &os, size_t i ) const
{
  os << "(oneof";
  for( size_t k = 0; k < adds.size(); ++k ) {
    os << " ";
    adds[k]->print(os);
  }
  for( size_t k = 0; k < dels.size(); ++k ) {
    os << " (not ";
    dels[k]->print(os);
    os << ")";
  }
  os << ")" << std::endl;
}

void PDDL_Base::Clause::print( std::ostream &os, size_t i ) const
{
  os << "(or";
  for( size_t k = 0; k < neg_atm.size(); ++k ) {
    os << " (not ";
    neg_atm[k]->print(os);
    os << ")";
  }
  for( size_t k = 0; k < pos_atm.size(); ++k ) {
    os << " ";
    pos_atm[k]->print(os);
  }
  os << ")" << std::endl;;
}

void PDDL_Base::Complex::print( std::ostream &os, size_t i ) const
{
  os << std::setw(i) << "" << "(:complex" << std::endl;
  os << std::setw(i) << "" << "  :parameters (";
  for (size_t k = 0; k < param.size(); k++) {
    if (k > 0) os << ' ';
    param[k]->print(os);
  }
  os << ")" << std::endl;
  os << std::setw(i) << "" << "  :pos_prec (";
  for (size_t k = 0; k < pos_atm.size(); k++) {
    pos_atm[k]->print(os);
    if (k < pos_atm.size() - 1) os << " ";
  }
  os << ")" << std::endl;
  os << std::setw(i) << "" << "  :neg_prec (";
  for (size_t k = 0; k < neg_atm.size(); k++) {
    neg_atm[k]->print(os);
    if (k < neg_atm.size() - 1) os << " ";
  }
  os << ")" << std::endl;
  os << std::setw(i) << "" << "  :add (";
  for (size_t k = 0; k < adds.size(); k++) {
    adds[k]->print(os);
    if (k < adds.size() - 1) os << " ";
  }
  os << ")" << std::endl;
  os << std::setw(i) << "" << "  :del (";
  for (size_t k = 0; k < dels.size(); k++) {
    dels[k]->print(os);
    if (k < dels.size() - 1) os << " ";
  }
  os << ")" << std::endl;
  os << std::setw(i) << "" << "  :clauses (";
  for (size_t k = 0; k < clauses.size(); k++) {
    clauses[k]->print(os);
    if (k < clauses.size() - 1) os << " ";
  }
  os << ")" << std::endl;
  os << std::setw(i) << "" << ")" << std::endl;
}
 
void PDDL_Base::ActionSymbol::print( std::ostream& os ) const
{
  os << "(:action " << print_name << std::endl;
  os << "  :parameters (";
  for (size_t k = 0; k < param.size(); k++) {
    if (k > 0) os << ' ';
    param[k]->print(os);
  }
  os << ")" << std::endl;
  os << "  :pos_prec (";
  for (size_t k = 0; k < pos_atm.size(); k++) {
    pos_atm[k]->print(os);
    if (k < pos_atm.size() - 1) os << " ";
  }
  os << ")" << std::endl;
  os << "  :neg_prec (";
  for (size_t k = 0; k < neg_atm.size(); k++) {
    neg_atm[k]->print(os);
    if (k < neg_atm.size() - 1) os << " ";
  }
  os << ")" << std::endl;
  os << "  :add (";
  for (size_t k = 0; k < adds.size(); k++) {
    adds[k]->print(os);
    if (k < adds.size() - 1) os << " ";
  }
  os << ")" << std::endl;
  os << "  :del (";
  for (size_t k = 0; k < dels.size(); k++) {
    dels[k]->print(os);
    if (k < dels.size() - 1) os << " ";
  }
  os << ")" << std::endl;
  os << "  :clauses (";
  for (size_t k = 0; k < clauses.size(); k++) {
    clauses[k]->print(os);
    if (k < clauses.size() - 1) os << " ";
  }
  os << ")" << std::endl;
  os << "  :oneof (";
  for (size_t k = 0; k < oneof.size(); k++) {
    oneof[k]->print(os);
    if (k < oneof.size() - 1) os << " ";
  }
  os << ")" << std::endl;
  for( size_t k = 0; k < complex.size(); ++k )
    complex[k]->print( os, 2 );
  os << ")" << std::endl;
}

void PDDL_Base::AtomBase::print(std::ostream& s)
{
  for (size_t k = 0; k < param.size(); k++)
    param[k]->print(s << ' ');
}

void PDDL_Base::Atom::print(std::ostream& s, bool neg)
{
  if (neg) s << "(not ";
  s << "(" << pred->print_name;
  PDDL_Base::AtomBase::print(s);
  s << ")";
  if (neg) s << ")";
}

void PDDL_Base::print(std::ostream& s)
{
  s << "domain: " << (domain_name ? domain_name : "<not defined>") << std::endl;
  s << "problem: " << (problem_name ? problem_name : "<not defined>") << std::endl;

  s << "<" << dom_predicates.size() << "," << dom_actions.size() << ">" << std::endl;

  dom_top_type->print(s);
  for (size_t k = 0; k < dom_types.size(); k++) dom_types[k]->print(s);
  for (size_t k = 0; k < dom_predicates.size(); k++) dom_predicates[k]->print(s);
  for (size_t k = 0; k < dom_actions.size(); k++) dom_actions[k]->print(s);
  for (size_t k = 0; k < dom_init_oneof.size(); k++) dom_init_oneof[k]->print(s);
  for (size_t k = 0; k < dom_init_cls.size(); k++) dom_init_cls[k]->print(s);

  s << "(:pos_goals";
  for (size_t k = 0; k < dom_goal_pos.size(); k++) {
    s << " ";
    dom_goal_pos[k]->print(s);
  }
  s << ")" << std::endl;
  s << "(:neg_goals";
  for (size_t k = 0; k < dom_goal_neg.size(); k++) {
    s << " ";
    dom_goal_neg[k]->print(s);
  }
  s << ")" << std::endl;
}

void InstanceName::write(std::ostream& s, bool cat) const
{
  if (domain_name_only) s << domain_name;
  else if (problem_name_only) s << problem_name;
  else s << domain_name << "::" << problem_name;
}

PDDL_Name::PDDL_Name(PDDL_Base::Symbol* sym, PDDL_Base::symbol_vec arg, size_t n)
  : _neg(false), _sym(sym)
{
  _arg = arg;
}

PDDL_Name::PDDL_Name(PDDL_Base::Symbol* sym, PDDL_Base::variable_vec arg, size_t n)
  : _neg(false), _sym(sym)
{
  for (size_t k = 0; k < n; k++) _arg.push_back( arg[k]->value );
}

void PDDL_Name::add(PDDL_Base::Symbol* s)
{
  _arg.push_back( s );
}

void PDDL_Name::write(std::ostream& s, bool cat) const
{
  if (cat) {
    if (_neg) s << "not_" << _sym->print_name;
    else s << _sym->print_name;
    for (size_t k = 0; k < _arg.size(); k++)
      s << '_' << _arg[k]->print_name;
  }
  else {
    if (_neg) s << "(not ";
    s << '(' << _sym->print_name;
    for (size_t k = 0; k < _arg.size(); k++)
      s << ' ' << _arg[k]->print_name;
    s << ')';
    if (_neg) s << ')';
  }
}

