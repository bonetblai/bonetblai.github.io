
#include "problem.h"
#include "preprocess.h"
#include "parser.h"

#include "state.h"
#include "plan.h"

int main(int argc, char *argv[])
{
  StringTable symbols(50, lowercase_map);
  bool        opt_print_plan = false;
  bool        opt_print_instance = false;
  int         verbose_level = 0;
  char *      opt_plan_file = 0;

  if( argc == 1 ) {
    std::cerr << "Usage: verify [-print-plan] [-print-instance] [-plan <plan>] <pddl-files>"
              << std::endl << std::endl
              << "Example: verify -plan examples/s3.linear examples/sortn.pddl examples/s3.pddl"
              << std::endl;
    exit(0);
  }

  Parser* reader = new Parser(symbols);

  for( int k = 1; k < argc; ++k ) {
    if ((strcmp(argv[k],"-v") == 0) && (k < argc - 1)) {
      verbose_level = atoi(argv[++k]);
    }
    else if (strcmp(argv[k],"-plan") == 0) {
      opt_plan_file = argv[++k];
    }

    // output/formatting options
    else if (strcmp(argv[k],"-print-plan") == 0) {
      opt_print_plan = true;
    }
    else if (strcmp(argv[k],"-print-instance") == 0) {
      opt_print_instance = true;
    }

    // input file
    else if (*argv[k] != '-') {
      reader->read(argv[k], false);
    }
  }

  //reader->print( std::cout );
  Instance::default_trace_level = verbose_level - 1;
  Preprocessor::default_trace_level = verbose_level - 1;
  Instance instance;

  std::cerr << "instantiating..." << std::endl;
  reader->instantiate(instance);
  Preprocessor prep(instance);
  std::cerr << "preprocessing..." << std::endl;
  prep.preprocess();

  if( opt_print_instance ) instance.print( std::cout );

  if( opt_plan_file ) {
    std::cerr << "reading plan..." << std::endl;
    Plan_Reader preader(instance);
    const Plan* plan = preader.read( opt_plan_file );
    if( preader.error() ) { std::cout << "error" << std::endl; exit(255); }

    if( opt_print_plan ) {
      std::cout << "plan = " << *plan << std::endl;
      std::cout << "cost = " << plan->cost() << std::endl;
    }

    std::cout << "verifying..." << std::endl;
    bool valid = plan->valid();
    float cost = plan->cost();
    std::cout << (valid?"valid":"invalid") << " plan cost " << cost << std::endl;
  }

  return 0;
}

