#ifndef PREPROCESS_H
#define PREPROCESS_H

#include "problem.h"
//#include "cost_table.h"
//#include "stats.h"
//#include "heuristic.h"
//#include "graph.h"
#include "index.h"

class Preprocessor {
 public:
  Instance&   instance;
  index_vec   atom_map;
  index_vec   action_map;
  index_vec   inv_map;

 protected:
  void remove_useless_actions();

 public:
  static int   default_trace_level;
  int          trace_level;

  //Preprocessor(Instance& ins, Statistics& s);
  Preprocessor(Instance& ins);
  ~Preprocessor();

  // Methods that do NOT change the instance:

  void compute_reachability(bool_vec& reachable_atoms, bool_vec& reachable_actions);
  void compute_static_atoms(const bool_vec& reachable_actions, bool_vec& static_atoms);

  // adds atoms recursively relevant to set 'check' to set 'rel'
  void compute_relevance(const index_set& check, bool_vec& rel);

  // Methods that ADD (information) TO the instance:

  // marks atoms not relevant to goals in instance
  void compute_irrelevant_atoms();

  // Methods that REMOVE things from, or otherwise CHANGE the instance:

  // perform standard preprocessing: remove static atoms and unreachable actions, re-cross-ref
  void preprocess();

  // remove atoms marked irrelevant from instance (re-cross-ref)
  void remove_irrelevant_atoms();
};

#endif
