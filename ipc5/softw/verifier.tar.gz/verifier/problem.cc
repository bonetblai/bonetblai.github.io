
#include "problem.h"
#include <assert.h>

bool Instance::always_write_parameters_declaration = false;
bool Instance::always_write_requirements_declaration = false;
bool Instance::always_write_precondition = false;
bool Instance::always_write_conjunction = false;
int  Instance::default_trace_level = 0;

Instance::Instance(const Instance& ins)
  : cross_referenced(false),
    name(ins.name),
    atoms(ins.atoms),
    actions(ins.actions),
    init_atoms(ins.init_atoms),
    goal_atoms(ins.goal_atoms),
    trace_level(ins.trace_level)
{
}

Instance::Atom& Instance::new_atom(Name* name)
{
  Atom *a = new Atom( name, atoms.size() );
  atoms.push_back( a );
  if (trace_level > 2)
    std::cerr << "atom " << a->index << "." << a->name << " created" << std::endl;
  return *a;
}

Instance::Action& Instance::new_action(Name* name)
{
  Action *a = new Action( name, actions.size() );
  actions.push_back( a );
  if (trace_level > 2)
    std::cerr << "action " << a->index << "." << a->name << " created" << std::endl;
  return *a;
}

void Instance::cross_reference()
{
  if (cross_referenced) return;
  init_atoms.clear();
  goal_atoms.clear();
  for (size_t k = 0; k < atoms.size(); k++) {
    Atom& prop = *atoms[k];
    if (prop.init) init_atoms.insert(k);
    if (prop.goal) goal_atoms.insert(k);
  }
  cross_referenced = true;
}

void Instance::remap_atom_set(index_set& set, const index_vec& atom_map)
{
  index_set nset;
  for( index_set::iterator si = set.begin(); si != set.end(); ++si ) {
    if( atom_map[*si] != no_such_index ) {
      nset.insert( atom_map[*si] );
    }
  }
  set = nset;
}

void Instance::remove_actions(const bool_vec& set, index_vec& map)
{
  index_vec rm_map( actions.size() );
  size_t j = 0;
  for( size_t k = 0; k < actions.size(); ++k ) {
    if( !set[k] ) {
      if( j < k ) {
        actions[j] = actions[k];
        actions[j]->index = j;
      }
      rm_map[k] = j;
      ++j;
    }
    else
      rm_map[k] = no_such_index;
  }
  while( actions.size() > j ) actions.pop_back();

  for( size_t k = 0; k < map.size(); ++k ) {
    if( map[k] != no_such_index )
      map[k] = rm_map[map[k]];
  }
}

void Instance::remove_atoms(const bool_vec& set, index_vec& map)
{
  index_vec rm_map( atoms.size() );
  size_t j = 0;
  for( size_t k = 0; k < atoms.size(); ++k ) {
    if( !set[k] ) {
      if( j < k ) {
	atoms[j] = atoms[k];
	atoms[j]->index = j;
      }
      rm_map[k] = j;
      ++j;
    }
    else
      rm_map[k] = no_such_index;
  }
  while( atoms.size() > j ) atoms.pop_back();

  for( size_t k = 0; k < actions.size(); ++k ) {
    remap_atom_set( actions[k]->pre, rm_map );
    remap_atom_set( actions[k]->add, rm_map );
    remap_atom_set( actions[k]->del, rm_map );
  }

  for( size_t k = 0; k < map.size(); ++k ) {
    if( map[k] != no_such_index )
      map[k] = rm_map[map[k]];
  }
}

void Instance::set_initial(const index_set& init)
{
  for (size_t k = 0; k < n_atoms(); k++) atoms[k]->init = false;
  for ( index_set::const_iterator it = init.begin(); it != init.end(); ++it )
    atoms[*it]->init = true;
  init_atoms = init;
}

void Instance::set_goal(const index_set& goal)
{
  for (size_t k = 0; k < n_atoms(); k++) {
    atoms[k]->goal = false;
  }
  for( index_set::const_iterator gi = goal.begin(); gi != goal.end(); ++gi )
    atoms[*gi]->goal = true;
  goal_atoms = goal;
}

void Instance::clear_cross_reference()
{
  init_atoms.clear();
  goal_atoms.clear();
  cross_referenced = false;
}

void Instance::write_atom_set(std::ostream& s, const index_set& set) const
{
  s << '{';
  for( index_set::const_iterator si = set.begin(); si != set.end(); ++si ) {
    if( si != set.begin() ) s << ',';
    s << atoms[*si]->name;
  }
  s << '}';
}

void Instance::write_atom_set(std::ostream& s, const bool* set) const
{
  s << '{';
  bool need_comma = false;
  for (size_t k = 0; k < n_atoms(); k++) if (set[k]) {
    if (need_comma) s << ',';
    s << atoms[k]->name;
    need_comma = true;
  }
  s << '}';
}

void Instance::write_atom_set(std::ostream& s, const bool_vec& set) const
{
  s << '{';
  bool need_comma = false;
  for (size_t k = 0; k < n_atoms(); k++) if (set[k]) {
    if (need_comma) s << ',';
    s << atoms[k]->name;
    need_comma = true;
  }
  s << '}';
}

void Instance::write_atom_sets(std::ostream& s, const index_set_vec& sets) const
{
  s << '{';
  for (size_t k = 0; k < sets.size(); k++) {
    if (k > 0) s << ',';
    write_atom_set(s, sets[k]);
  }
  s << '}';
}

void Instance::write_action_set(std::ostream& s, const index_vec& set) const
{
  s << '{';
  for (size_t k = 0; k < set.size(); k++) {
    if (k > 0) s << ',';
    s << actions[set[k]]->name;
  }
  s << '}';
}

void Instance::write_action_set(std::ostream& s, const bool* set) const
{
  s << '{';
  bool need_comma = false;
  for (size_t k = 0; k < n_actions(); k++) if (set[k]) {
    if (need_comma) s << ',';
    s << actions[k]->name;
    need_comma = true;
  }
  s << '}';
}

void Instance::write_action_set(std::ostream& s, const bool_vec& set) const
{
  s << '{';
  bool need_comma = false;
  for (size_t k = 0; k < n_actions(); k++) if (set[k]) {
    if (need_comma) s << ',';
    s << actions[k]->name;
    need_comma = true;
  }
  s << '}';
}

void Instance::write_domain(std::ostream& s) const
{
  if (name) {
    Name::domain_name_only = true;
    s << "(define (domain " << name << ")" << std::endl;
    Name::domain_name_only = false;
  }
  else {
    s << "(define (domain NONAME)" << std::endl;
  }

  if (always_write_requirements_declaration) {
    s << " (:requirements :strips)" << std::endl;
  }

  if (n_atoms() > 0) {
    s << " (:predicates";
    for (size_t k = 0; k < n_atoms(); k++) {
      s << " (";
      atoms[k]->name->write(s, true);
      s << ")";
    }
    s << ")" << std::endl;
  }

  for (size_t k = 0; k < n_actions(); k++) {
    s << " (:action ";
    actions[k]->name->write(s, true);
    if (always_write_parameters_declaration) {
      s << std::endl << "  :parameters ()";
    }
    if (actions[k]->pre.size() > 0) {
      s << std::endl << "  :precondition";
      if ((actions[k]->pre.size() > 1) || always_write_conjunction)
        s << " (and";
      for( index_set::const_iterator pi = actions[k]->pre.begin(); pi != actions[k]->pre.end(); ++pi ) {
        s << " (";
        atoms[*pi<0?-(*pi)-1:(*pi)-1]->name->write(s, true);
        s << ")";
      }
      if ((actions[k]->pre.size() > 1) || always_write_conjunction)
        s << ")";
    }
    else if (always_write_precondition) {
      if (always_write_conjunction)
        s << std::endl << "  :precondition (and)";
      else
        s << std::endl << "  :precondition ()";
    }

    if ((actions[k]->add.size() + actions[k]->del.size()) > 0) {
      s << std::endl << "  :effect";
      if ((actions[k]->add.size() + actions[k]->del.size()) > 1)
        s << " (and";
      for( index_set::const_iterator ai = actions[k]->add.begin(); ai != actions[k]->add.end(); ++ai ) {
        s << " (";
        atoms[*ai]->name->write(s, true);
        s << ")";
      }
      for( index_set::const_iterator di = actions[k]->del.begin(); di != actions[k]->del.end(); ++di ) {
        s << " (not (";
        atoms[*di]->name->write(s, true);
        s << "))";
      }
      if ((actions[k]->add.size() + actions[k]->del.size()) > 1) s << ")";
    }
    s << ")" << std::endl;
  }
  s << ")" << std::endl;
}

void Instance::write_problem(std::ostream& s) const
{
  if (name) {
    Name::problem_name_only = true;
    s << "(define (problem " << name << ")" << std::endl;
    Name::problem_name_only = false;
    Name::domain_name_only = true;
    s << " (:domain " << name << ")" << std::endl;
    Name::domain_name_only = false;
  }
  else {
    s << "(define (problem NONAME)" << std::endl;
    s << " (:domain NONAME)" << std::endl;
  }

  bool write_init = false;
  for (size_t k = 0; (k < n_atoms()) && !write_init; k++)
    if (atoms[k]->init) write_init = true;
  if (write_init) {
    s << " (:init";
    for (size_t k = 0; k < n_atoms(); k++) if (atoms[k]->init) {
      s << " (";
      atoms[k]->name->write(s, true);
      s << ")";
    }
    s << ")" << std::endl;
  }

  size_t write_goal = 0;
  for (size_t k = 0; (k < n_atoms()) && (write_goal < 2); k++)
    if (atoms[k]->goal) write_goal += 1;
  if (write_goal > 0) {
    s << " (:goal";
    if (write_goal > 1) s << " (and";
    for (size_t k = 0; k < n_atoms(); k++) if (atoms[k]->goal) {
      s << " (";
      atoms[k]->name->write(s, true);
      s << ")";
    }
    if (write_goal > 1) s << ")";
    s << ")" << std::endl;
  }

  s << ")" << std::endl;
}

void Instance::print(std::ostream& s) const
{
  print_atoms(s);
  print_actions(s);
  s << "goals: ";
  write_atom_set(s, goal_atoms);
  s << std::endl;
}

void Instance::print_atoms(std::ostream& s) const
{
  for (size_t k = 0; k < n_atoms(); k++) {
    s << k << ". " << atoms[k]->name << std::endl;
    s << "  init: " << (atoms[k]->init ? 'T' : 'F')
      << ", goal: " << (atoms[k]->goal ? 'T' : 'F')
      << std::endl;
  }
}

void Instance::Action::print(std::ostream& s, const Instance &i ) const
{
  s << name << ":" << std::endl;
  if( pre.size() > 0 ) {
    s << "  pre:";
    for( index_set::const_iterator pi = pre.begin(); pi != pre.end(); ++pi )
      s << ' ' << (*pi<0?*pi+1:*pi-1) << '.' << i.atoms[*pi<0?-(*pi)-1:(*pi)-1]->name;
    s << std::endl;
  }
  if( add.size() > 0 ) {
    s << "  add:";
    for( index_set::const_iterator ai = add.begin(); ai != add.end(); ++ai )
      s << ' ' << (*ai) << '.' << i.atoms[*ai]->name;
    s << std::endl;
  }
  if( del.size() > 0 ) {
  s << "  del:";
    for( index_set::const_iterator di = del.begin(); di != del.end(); ++di )
      s << ' ' <<  (*di) << '.' << i.atoms[*di]->name;
    s << std::endl;
  }
  if( cls.size() > 0 ) {
    s << "  cls: ";
    for( index_vec_vec::const_iterator ci = cls.begin(); ci != cls.end(); ++ci ) {
      s << "(";
      for( index_vec::const_iterator li = (*ci).begin(); li != (*ci).end(); ++li ) {
        int l = (*li), p = (l<0?-l:l);
        s << ' ' << (l<0?-(p-1):p-1) << '.' << i.atoms[p-1]->name;
      }
      s << ") ";
    }
    s << std::endl;
  }
  if( oneof.size() > 0 ) {
    s << "  oneof: ";
    for( index_vec_vec::const_iterator oi = oneof.begin(); oi != oneof.end(); ++oi ) {
      s << "(";
      for( index_vec::const_iterator li = (*oi).begin(); li != (*oi).end(); ++li ) {
        int l = (*li), p = (l<0?-l:l);
        s << ' ' << (l<0?-(p-1):p-1) << '.' << i.atoms[p-1]->name;
      }
      s << ") ";
    }
    s << std::endl;
  }
  if( when.size() > 0 ) {
    s << "  when:";
    for( when_vec::const_iterator wi = when.begin(); wi != when.end(); ++wi ) {
      s << (wi==when.begin()?" ":"       ");
      for( index_set::const_iterator li = (*wi).pre.begin(); li != (*wi).pre.end(); ++li ) {
        int l = (*li), p = (l<0?-l:l);
        s << ' ' << (l<0?-p+1:p-1) << '.' << i.atoms[p-1]->name;
      }
      s << " ==> :add";
      for( index_set::const_iterator ai = (*wi).add.begin(); ai != (*wi).add.end(); ++ai )
        s << ' ' << (*ai) << '.' << i.atoms[*ai]->name;
      s << " :del";
      for( index_set::const_iterator di = (*wi).del.begin(); di != (*wi).del.end(); ++di )
        s << ' ' << (*di) << '.' << i.atoms[*di]->name;
      s << std::endl;
    }
  }
  if( cost != 1 ) s << "  cost: " << cost << std::endl;
}

void Instance::print_actions( std::ostream &os ) const
{
  for (size_t k = 0; k < n_actions(); k++) {
    os << k << ". ";
    actions[k]->print( os, *this );
  }
  if( goal_cls.size() > 0 ) {
    os << "  goal_cls: ";
    for( index_vec_vec::const_iterator ci = goal_cls.begin(); ci != goal_cls.end(); ++ci ) {
      os << "(";
      for( index_vec::const_iterator li = (*ci).begin(); li != (*ci).end(); ++li ) {
        int l = (*li), p = (l<0?-l:l);
        os << ' ' << (l<0?-(p-1):p-1) << '.' << atoms[p-1]->name;
      }
      os << ") ";
    }
    os << std::endl;
  }
}

