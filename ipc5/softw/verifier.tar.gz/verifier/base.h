#ifndef PDDL_BASE_H
#define PDDL_BASE_H

#include "ptr_table.h"
#include "string_table.h"
#include "problem.h"
#include <assert.h>
#include <vector>

class PDDL_Base {
 public:
  static bool     write_warnings;
  static bool     write_info;

  enum symbol_class { sym_object, sym_typename, sym_predicate, sym_action, sym_variable };

  struct Symbol {
    symbol_class sym_class;
    char*        print_name;
    Symbol*      sym_type;
    Symbol( char *n, symbol_class c = sym_object ) : sym_class(c), print_name(n), sym_type(0) { }
    void print( std::ostream& os ) const { os << print_name; }
  };
  struct symbol_vec : public std::vector<Symbol*> { };

  struct TypeSymbol : public Symbol {
    symbol_vec  elements;
    TypeSymbol(char* n) : Symbol(n,sym_typename) { }
    void add_element(Symbol* e);
    void print(std::ostream& s);
  };
  struct type_vec : public std::vector<TypeSymbol*> { };

  struct VariableSymbol : public Symbol {
    Symbol*  value;
    VariableSymbol(char* n) : Symbol(n,sym_variable), value(0) { }
    void print( std::ostream& os ) { os << print_name; if( sym_type ) os << " - " << sym_type->print_name; }
  };
  struct variable_vec : public std::vector<VariableSymbol*> { };

  struct PredicateSymbol : public Symbol {
    variable_vec param;
    ptr_table    pos_goal;
    ptr_table    neg_goal;
    ptr_table    pos_prop;
    ptr_table    neg_prop;
    PredicateSymbol(char* n) : Symbol(n,sym_predicate) { }
    void print(std::ostream& s);
  };
  struct predicate_vec : public std::vector<PredicateSymbol*> { };

  struct AtomBase {
    symbol_vec     param;
    bool           neg;
    AtomBase( bool n = false ) : neg(n) { }
    bool equals(AtomBase& b);
    void print(std::ostream& s);
  };

  struct Atom : AtomBase {
    PredicateSymbol* pred;
    Atom( PredicateSymbol* p, bool neg = false ) : AtomBase(neg), pred(p) { }
    bool equals(Atom& a);
    Instance::Atom* find_prop(Instance& ins, bool neg, bool create);
    void print(std::ostream& s, bool neg);
    void print(std::ostream& s) { print(s, false); }
  };
  struct atom_vec : public std::vector<Atom*> { };

  struct Effect {
    atom_vec adds;
    atom_vec dels;
    atom_vec pos_atm;
    atom_vec neg_atm;
  };

  struct OneOf : public Effect {
    OneOf() { }
    void print( std::ostream& os, size_t i = 0 ) const;
    void build_effects( Instance& ins, Instance::Action &act );
  };
  struct oneof_vec : public std::vector<OneOf*> { };

  struct Clause : public Effect {
    Clause() { }
    void print( std::ostream& os, size_t i = 0 ) const;
    void build_clauses( Instance& ins, index_vec_vec &cls );

  };
  struct clause_vec : public std::vector<Clause*> { };

  struct Complex : public Effect {
    variable_vec   param;
    clause_vec     clauses;
    Complex() { }
    void print( std::ostream& os, size_t i = 0 ) const;
    void build( Instance& ins, size_t p, Instance::Action &act );
    void build_effects( Instance& ins, Instance::Action &act, bool topl );
  };
  struct complex_vec : public std::vector<Complex*> { };

  struct ActionSymbol : public Symbol, public Complex {
    complex_vec complex;
    oneof_vec oneof;
    ActionSymbol(char* n) : Symbol(n,sym_action) { }
    void instantiate( Instance &ins );
    void print( std::ostream& os ) const;
    void build( Instance& ins, size_t p );
    void post_process();
    size_t param_index(VariableSymbol* p);
  };
  struct action_vec : public std::vector<ActionSymbol*> { };

  char* domain_name;
  char* problem_name;
  bool  ready_to_instantiate;

  StringTable&  tab;
  type_vec      dom_types;
  TypeSymbol*   dom_top_type;
  symbol_vec    dom_constants;

  PredicateSymbol* dom_eq_pred;
  predicate_vec dom_predicates;
  action_vec    dom_actions;

  atom_vec      dom_init_atoms;
  clause_vec    dom_init_cls;
  oneof_vec     dom_init_oneof;
  atom_vec      dom_goal_pos;
  atom_vec      dom_goal_neg;
  clause_vec    dom_goal_cls;

  PDDL_Base(StringTable& t);
  ~PDDL_Base();

  void set_variable_type( variable_vec& vec, size_t n, TypeSymbol* t );
  void set_type_type( type_vec& vec, size_t n, TypeSymbol* t );
  void set_constant_type( symbol_vec& vec, size_t n, TypeSymbol* t );
  void clear_param( variable_vec& vec, size_t start = 0 );
  void insert_atom( ptr_table& t, AtomBase* a );
  void post_process();
  void instantiate( Instance& ins );
  void print( std::ostream& s );
  PredicateSymbol* find_type_predicate( Symbol* type_sym );
};

class InstanceName : public Name {
  char* domain_name;
  char* problem_name;
 public:
  InstanceName( char* d, char* p ) : domain_name(d), problem_name(p) { }
  virtual ~InstanceName() { }
  virtual void write( std::ostream& s, bool cat ) const;
};

class PDDL_Name : public Name {
  bool _neg;
  PDDL_Base::Symbol* _sym;
  PDDL_Base::symbol_vec _arg;
 public:
  PDDL_Name( PDDL_Base::Symbol* sym, bool n = false ) : _neg(n), _sym(sym) { };
  PDDL_Name( PDDL_Base::Symbol* sym, PDDL_Base::symbol_vec arg, size_t n );
  PDDL_Name( PDDL_Base::Symbol* sym, PDDL_Base::variable_vec arg, size_t n );
  virtual ~PDDL_Name() { }
  void add( PDDL_Base::Symbol* s );
  virtual void write( std::ostream& s, bool cat ) const;
};

#endif
