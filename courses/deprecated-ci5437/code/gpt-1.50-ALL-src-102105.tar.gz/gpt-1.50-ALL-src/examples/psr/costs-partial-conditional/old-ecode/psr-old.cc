#include <iostream.h>
#include <string.h>
#include <theseus/theRtStandard.h>

// problem dependent definitions
#include "rs1_power_supply.h"
#define STATECLASSNAME        stateFor_rs1Class
#define FIRSTLINE             _l1
#define LASTLINE              _l11
#define FIRSTDEVICE           _cb1
#define LASTDEVICE            _sd11

// problem independent definitions
#define DEVINDEX(d)           ((d)-FIRSTDEVICE)
#define OPP(s)                ((s) == _side1 ? _side2 : _side1)
#define CODE(dev,lin)         ((lin) == _side1 ? (dev) : 128+(dev))
#define DISPLAYSZ             256

static bool display1[DISPLAYSZ];
static bool display2[DISPLAYSZ];
static bool display3[DISPLAYSZ];
static bool display4[DISPLAYSZ];
static bool visited[DISPLAYSZ];


static bool
path( const STATECLASSNAME* ptr, int x, int sx, int l )
{
  // set display
  display1[CODE(x,sx)] = true;

  // base cases
  if( (ptr->staticFunction1[_ac_mode][x] != _ok) || bitValue( &(ptr->predicate1[_faulty][0]), l ) )
    return( false );

  // if line is connected to x, we are done!
  if( bitValue(&(ptr->staticPredicate3[_ext][0]),(l*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
    return( true );

  // expand path
  for( int lin = FIRSTLINE; lin <= LASTLINE; ++lin )
    if( !bitValue( &(ptr->predicate1[_faulty][0]), lin ) &&
	bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
      for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
	{
	  if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side1) &&
	      !display1[CODE(dev,_side1)] && path( ptr, dev, _side1, l ) )
	    return( true );
	  if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side2) &&
	      !display1[CODE(dev,_side2)] && path( ptr, dev, _side2, l ) )
	    return( true );
	}
  return( false );
}

bool
_path( const stateClass& state, int x, int sx, int l )
{
  const STATECLASSNAME* ptr;
  memset( display1, 0, DISPLAYSZ * sizeof( bool ) );
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in predicate path." << endl;
      return( false );
    }
  //  cout << "path(x=" << x << ",sx=" << sx << ",l=" << l << ") = "; cout.flush();
  bool rv = path( ptr, x, sx, l );
  //  cout << rv << endl;
  return( rv );
}

static bool
closed_path_line( const STATECLASSNAME* ptr, int x, int sx, int l )
{
  // set display
  display2[CODE(x,sx)] = true;

  // x must be closed
  if( !bitValue( &(ptr->predicate1[_closed][0]), x ) || bitValue( &(ptr->predicate1[_faulty][0]), l ) )
    return( false );

  // if line is connected to x, we are done!
  if( bitValue(&(ptr->staticPredicate3[_ext][0]),(l*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
    return( true );

  // expand path
  for( int lin = FIRSTLINE; lin <= LASTLINE; ++lin )
    if( !bitValue( &(ptr->predicate1[_faulty][0]), lin ) &&
	bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
      {
	for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
	  {
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side1) &&
		!display2[CODE(dev,_side1)] && closed_path_line( ptr, dev, _side1, l ) )
	      return( true );
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side2) &&
		!display2[CODE(dev,_side2)] && closed_path_line( ptr, dev, _side2, l ) )
	      return( true );
	  }
      }
  return( false );
}

bool
_closed_path_line( const stateClass& state, int x, int sx, int l )
{
  const STATECLASSNAME* ptr;
  memset( display2, 0, DISPLAYSZ * sizeof( bool ) );
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in predicate closed_path_line." << endl;
      return( false );
    }
  //  cout << "closed_path_line(x=" << x << ",sx=" << sx << ",l=" << l << ") = "; cout.flush();
  bool rv = closed_path_line( ptr, x, sx, l );
  //  cout << rv << endl;
  return( rv );
}

#if 1
static bool
upstream( const STATECLASSNAME* ptr, int x, int sx, int l )
{
  // set display
  display3[CODE(x,sx)] = true;

  // x must be closed
  if( !bitValue( &(ptr->predicate1[_closed][0]), x ) )
    return( false );

  // if line is connected to x, we are done!
  if( bitValue(&(ptr->staticPredicate3[_ext][0]),(l*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
    return( true );

  // expand path
  for( int lin = FIRSTLINE; lin <= LASTLINE; ++lin )
    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
      {
	for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
	  {
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side1) &&
		!display3[CODE(dev,_side1)] && upstream( ptr, dev, _side1, l ) )
	      return( true );
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side2) &&
		!display3[CODE(dev,_side2)] && upstream( ptr, dev, _side2, l ) )
	      return( true );
	  }
      }
  return( false );
}

bool
_upstream( const stateClass& state, int x, int sx, int y, int sy )
{
  const STATECLASSNAME* ptr;
  memset( display3, 0, DISPLAYSZ * sizeof( bool ) );
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in predicate upstream." << endl;
      return( false );
    }

  // find line connected to y
  int line;
  for( line = FIRSTLINE; line <= LASTLINE; ++line )
    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(line*NUMOBJECTS+y)*NUMOBJECTS+sy) )
      break;
  if( line > LASTLINE ) return( false );

  if( upstream( ptr, x, sx, line ) )
    {
      if( bitValue( &(ptr->staticPredicate1[_breaker][0]), x ) &&
	  bitValue( &(ptr->predicate1[_closed][0]), x ) )
	return( true );

      // need to find a breaker feeding x
      for( line = FIRSTLINE; line <= LASTLINE; ++line )
	if( bitValue(&(ptr->staticPredicate3[_ext][0]),(line*NUMOBJECTS+x)*NUMOBJECTS+sx) )
	  break;
      if( line > LASTLINE ) return( false );

      for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
	if( bitValue( &(ptr->staticPredicate1[_breaker][0]), dev ) &&
	    (_closed_path_line(state,dev,_side1,line) || _closed_path_line(state,dev,_side2,line)) )
	  return( true );
    }
  return( false );
}
#else
static bool
connected( const STATECLASSNAME* ptr, int x, int sx, int y, int sy )
{
  if( (x == y) && (sx == sy) )
    return( false );
  else
    {
      for( int lin = FIRSTLINE; lin <= LASTLINE; ++lin )
	if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+x)*NUMOBJECTS+sx) &&
	    bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+y)*NUMOBJECTS+sy) )
	  return( true );
      return( false );
    }
}

static bool
upstream( const STATECLASSNAME* ptr, int x, int sx, int y, int sy )
{
  // base case
  if( !bitValue( &(ptr->predicate1[_closed][0]), x ) )
    return( false );

  // four cases -- the order is important
  if( bitValue( &(ptr->staticPredicate1[_breaker][0]), x ) )
    {
      // case (a)
      if( connected( ptr, x, OPP(sx), y, sy ) )
	return( true );

      // case (b)
      for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
	if( bitValue( &(ptr->predicate1[_closed][0]), dev ) )
	  {
	    if( connected( ptr, dev, OPP(_side1), y, sy ) &&
		upstream( ptr, x, sx, dev, _side1 ) )
	      return( true );
	    if( connected( ptr, dev, OPP(_side2), y, sy ) &&
		upstream( ptr, x, sx, dev, _side2 ) )
	      return( true );
	  }
    }
  else
    {
      // case (c)
      if( connected( ptr, x, OPP(sx), y, sy ) )
	for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
	  if( bitValue( &(ptr->staticPredicate1[_breaker][0]), dev ) )
	    {
	      if( upstream( ptr, dev, _side1, x, sx ) )
		return( true );
	      if( upstream( ptr, dev, _side2, x, sx ) )
		return( true );
	    }

      // case (d)
      for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
	if( bitValue( &(ptr->predicate1[_closed][0]), dev ) )
	  {
	    if( connected( ptr, dev, OPP(_side1), y, sy ) &&
		upstream( ptr, x, sx, dev, _side1 ) )
	      return( true );
	    if( connected( ptr, dev, OPP(_side2), y, sy ) &&
		upstream( ptr, x, sx, dev, _side2 ) )
	      return( true );
	  }
    }
  return( false );
}

bool
_upstream( const stateClass& state, int x, int sx, int y, int sy )
{
  const STATECLASSNAME* ptr;
  memset( display4, 0, DISPLAYSZ * sizeof( bool ) );
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in predicate upstream." << endl;
      return( false );
    }
  return( upstream( ptr, x, sx, y, sy ) );
}
#endif

#if 0
int
_compute_observation1( const stateClass& state, int x )
{
  // (:vector ?y - SWITCH (:if (pd_ok ?y) (:formula (closed ?y)) false))
  unsigned obs = 0;
  for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
    if( bitValue( &(ptr->staticPredicate1[_pd_ok][0]), dev ) &&
	bitValue( &(ptr->staticPredicate1[_closed][0]), dev ) )
      obs = obs | (1<<DEVINDEX(dev));
  return( (int)obs );
}
#endif

static void
compute_observation( const STATECLASSNAME* ptr, unsigned &obs, int x, int sx )
{
  if( display4[CODE(x,sx)] )
    return;
  else
    {
      // set display and observation
      display4[CODE(x,sx)] = true;
      visited[DEVINDEX(x)] = true;
      if( ptr->staticFunction1[_fd_mode][x] != _out )
	{
	  obs = obs & ~(1<<DEVINDEX(x));
	  if( ptr->staticFunction1[_fd_mode][x] == _ok )
	    obs = obs | (1<<DEVINDEX(x));
	}
    }

  // termination
  if( !bitValue( &(ptr->predicate1[_closed][0]), x ) )
    return;

  // expand path
  for( int lin = FIRSTLINE; lin <= LASTLINE; ++lin )
    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
      for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
	{
	  if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side1) )
	    compute_observation( ptr, obs, dev, _side1 );
	  if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side2) )
	    compute_observation( ptr, obs, dev, _side2 );
	}
}

int
_compute_observation( const stateClass& state, int x )
{ 
  const STATECLASSNAME* ptr;
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in function compute_observation." << endl;
      return( false );
    }

  // make a dfs starting in all closed breakers
  unsigned obs = 0;
  memset( visited, 0, DISPLAYSZ * sizeof( bool ) );
  for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
    if( bitValue( &(ptr->staticPredicate1[_breaker][0]), dev ) &&
	bitValue( &(ptr->predicate1[_closed][0]), dev ) )
      {
	// search in both sides
	memset( display4, 0, DISPLAYSZ * sizeof( bool ) );
	compute_observation( ptr, obs, dev, _side1 );
	memset( display4, 0, DISPLAYSZ * sizeof( bool ) );
	compute_observation( ptr, obs, dev, _side2 );
      }

  // post-processing for non-visited devices
  for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
    if( !visited[DEVINDEX(dev)] && (ptr->staticFunction1[_fd_mode][dev] == _liar) )
      obs = obs | (1<<DEVINDEX(dev));

  // return gathered info
  return( (int)obs );
}









































#if 0
bool
_closed_path( const stateClass& state, int x, int sx, int y, int sy )
{
  const STATECLASSNAME* ptr;
  memset( display2, 0, DISPLAYSZ * sizeof( bool ) );
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in predicate closed_path." << endl;
      return( false );
    }
  //  cout << "closed_path(x=" << x << ",sx=" << sx << ",y=" << y << ",sy=" << sy << ") = "; cout.flush();
  bool rv = closed_path( ptr, x, sx, y, sy );
  //  cout << rv << endl;
  return( rv );
}

static bool
closed_path( const STATECLASSNAME* ptr, int x, int sx, int y, int sy )
{
  // set display
  display2[CODE(x,sx)] = true;

  // x must be closed
  if( !bitValue( &(ptr->predicate1[_closed][0]), x ) )
    return( false );

  // expand path
  for( int lin = FIRSTLINE; lin <= LASTLINE; ++lin )
    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
      {
	// if x is directly connected to y, we are done!
	if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+y)*NUMOBJECTS+sy) )
	  return( true );

	// otherwise, need to continue ..
	for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
	  {
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side1) &&
		!display2[CODE(dev,_side1)] && closed_path( ptr, dev, _side1, y, sy ) )
	      return( true );
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side2) &&
		!display2[CODE(dev,_side2)] && closed_path( ptr, dev, _side2, y, sy ) )
	      return( true );
	  }
      }
  return( false );
}
#endif

#if 0
bool
_fault_downstream( const stateClass& state, int x, int sx )
{
  const STATECLASSNAME* ptr;
  memset( display4, 0, DISPLAYSZ * sizeof( bool ) );
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in predicate fault_downstream." << endl;
      return( false );
    }
  //  cout << "fault_downstrem(x=" << x << ",sx=" << sx << ") = "; cout.flush();
  bool rv = fault_downstream( ptr, x, sx );
  //  cout << rv << endl;
  return( rv );
}

static bool
fault_downstream( const STATECLASSNAME* ptr, int x, int sx )
{
  // set display
  display4[CODE(x,sx)] = true;

  // x must be closed
  if( !bitValue( &(ptr->predicate1[_closed][0]), x ) )
    return( false );

  // expand path
  for( int lin = FIRSTLINE; lin <= LASTLINE; ++lin )
    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
      {
	// if x is faulty, we are done!
	if( bitValue( &(ptr->predicate1[_faulty][0]), lin ) )
	  return( true );

	// otherwise, need to continue ..
	for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
	  {
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side1) &&
		!display4[CODE(dev,_side1)] && fault_downstream( ptr, dev, _side1 ) )
	      return( true );
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side2) &&
		!display4[CODE(dev,_side2)] && fault_downstream( ptr, dev, _side2 ) )
	      return( true );
	  }
      }
  return( false );
}
#endif

