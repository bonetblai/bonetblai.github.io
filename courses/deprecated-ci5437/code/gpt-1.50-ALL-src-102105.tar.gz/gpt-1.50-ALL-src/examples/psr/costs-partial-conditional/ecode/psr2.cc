#include <iostream.h>
#include <string.h>
#include <theseus/theRtStandard.h>


// problem dependent definitions
#include IFILE

#define NEED_WAIT             (ptr->object[_need_wait])
#define BREAKER(x)            (bitValue(&(ptr->staticPredicate1[_breaker][0]),(x)))
#define CLOSED(x)             (bitValue(&(ptr->predicate1[_closed][0]),(x)))
#define FAULTY(l)             (bitValue(&(ptr->predicate1[_faulty][0]),(l)))
#define PD_OK(x)              (bitValue(&(ptr->predicate1[_pd_ok][0]),(x)))
#define EXT(l,x,s)            (bitValue(&(ptr->staticPredicate3[_ext][0]),((l)*NUMOBJECTS+(x))*NUMOBJECTS+(s)))

#define SET_CLOSED(x,b)       setBit(&(ptr->predicate1[_closed][0]),(x),(b))

#define AC_MODE(x)            (ptr->staticFunction1[_ac_mode][(x)])
#define FD_MODE(x)            (ptr->staticFunction1[_fd_mode][(x)])


// the rest should work for any PSR problem ..
#define SIDE1                 _side1
#define SIDE2                 _side2
#define DEVINDEX(d)           ((d)-FIRSTDEVICE)
#define OPP(s)                ((s) == SIDE1 ? SIDE2 : SIDE1)
#define CODE(x,s)             ((s) == SIDE1 ? (x) : NUMOBJECTS+(x))
#define DISPLAYSZ             (2*NUMOBJECTS)


// static variables
static bool display1[DISPLAYSZ];
static bool display2[DISPLAYSZ];
static bool display3[DISPLAYSZ];
static bool display4[DISPLAYSZ];


inline bool
controllable( const STATECLASSNAME* ptr, int l )
{
  for( int x = FIRSTDEVICE; x <= LASTDEVICE; ++x )
    {
      if( EXT(l,x,SIDE1) && (AC_MODE(x) != _ok) )
	return( false );
      if( EXT(l,x,SIDE2) && (AC_MODE(x) != _ok) )
	return( false );
    }
  return( true );
}

static bool
safe_path( const STATECLASSNAME* ptr, int x, int sx, int l )
{
  // set display
  display1[CODE(x,sx)] = true;

  // base cases
  if( EXT(l,x,OPP(sx)) && controllable(ptr,l) )
    return( true );

  // expand path
  for( int l2 = FIRSTLINE; l2 <= LASTLINE; ++l2 )
    if( !FAULTY(l2) && EXT(l2,x,OPP(sx)) && controllable(ptr,l2) )
      for( int y = FIRSTDEVICE; y <= LASTDEVICE; ++y )
	if( x != y )
	  {
	    if( EXT(l2,y,SIDE1) && !display1[CODE(y,SIDE1)] && safe_path( ptr, y, SIDE1, l ) )
	      return( true );
	    if( EXT(l2,y,SIDE2) && !display1[CODE(y,SIDE2)] && safe_path( ptr, y, SIDE2, l ) )
	      return( true );
	  }
  return( false );
}

bool
_safe_path( const stateClass& state, int x, int sx, int l )
{
  const STATECLASSNAME* ptr;
  memset( display1, 0, DISPLAYSZ * sizeof( bool ) );
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in predicate safe_path." << endl;
      return( false );
    }
  bool rv = safe_path( ptr, x, sx, l );
  return( rv );
}

static bool
closed_path( const STATECLASSNAME* ptr, int x, int sx, int l )
{
  // set display
  display2[CODE(x,sx)] = true;

  // x must be closed
  if( !CLOSED(x) || FAULTY(l) )
    return( false );

  // if line is connected to x, we are done!
  if( EXT(l,x,OPP(sx)) )
    return( true );

  // expand path
  for( int l2 = FIRSTLINE; l2 <= LASTLINE; ++l2 )
    if( !FAULTY(l2) && EXT(l2,x,OPP(sx)) )
      for( int y = FIRSTDEVICE; y <= LASTDEVICE; ++y )
	if( x != y )
	  {
	    if( EXT(l2,y,SIDE1) && !display2[CODE(y,SIDE1)] && closed_path( ptr, y, SIDE1, l ) )
	      return( true );
	    if( EXT(l2,y,SIDE2) && !display2[CODE(y,SIDE2)] && closed_path( ptr, y, SIDE2, l ) )
	      return( true );
	  }
  return( false );
}

bool
_closed_path( const stateClass& state, int x, int sx, int l )
{
  const STATECLASSNAME* ptr;
  memset( display2, 0, DISPLAYSZ * sizeof( bool ) );
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in predicate closed_path." << endl;
      return( false );
    }
  bool rv = closed_path( ptr, x, sx, l );
  return( rv );
}

int
_collect_obs1( const stateClass& state, int x )
{ 
  const STATECLASSNAME* ptr;
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in function collect_obs1." << endl;
      return( false );
    }

  // compute and return observation
  unsigned obs = 0;
  for( int y = FIRSTDEVICE; y <= LASTDEVICE; ++y )
    if( PD_OK(y) && CLOSED(y) )
      obs |= (1<<DEVINDEX(y));
  return( (int)obs );
}

static bool
compute_fed_aff( const STATECLASSNAME* ptr, unsigned &fed, unsigned &aff, int x, int sx )
{
  // check if we have been here already
  if( display4[CODE(x,sx)] )
    return( false );
  else
    display4[CODE(x,sx)] = true;

  // set fed status
  fed |= (1<<DEVINDEX(x));

  // base case
  if( !CLOSED(x) )
    return( false );

  // expand path
  bool rv = false;
  for( int l = FIRSTLINE; l <= LASTLINE; ++l )
    if( EXT(l,x,OPP(sx)) )
      {
	for( int y = FIRSTDEVICE; y <= LASTDEVICE; ++y )
	  if( x != y )
	    {
	      if( EXT(l,y,SIDE1) )
		rv = compute_fed_aff( ptr, fed, aff, y, SIDE1 ) || rv;
	      if( EXT(l,y,SIDE2) )
		rv = compute_fed_aff( ptr, fed, aff, y, SIDE2 ) || rv;
	    }
	rv = rv || (FAULTY(l) && CLOSED(x));
      }

  // set affected and return
  if( rv )
    aff |= (1<<DEVINDEX(x));

  // return affected status
  return( rv );
}

int
_collect_obs2( const stateClass& state, int x )
{ 
  const STATECLASSNAME* ptr;
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in function collect_obs2." << endl;
      return( false );
    }

  // make a dfs starting in all closed breakers to detected fed and affected status
  unsigned fed = 0, aff = 0;
  for( int y = FIRSTDEVICE; y <= LASTDEVICE; ++y )
    if( BREAKER(y) && CLOSED(y) )
      {
	// search in both sides
	memset( display4, 0, DISPLAYSZ * sizeof( bool ) );
	compute_fed_aff( ptr, fed, aff, y, SIDE1 );
	memset( display4, 0, DISPLAYSZ * sizeof( bool ) );
	compute_fed_aff( ptr, fed, aff, y, SIDE2 );
      }

  // compute observation
  unsigned obs = 0;
  for( int y = FIRSTDEVICE; y <= LASTDEVICE; ++y )
    if( (fed & (1<<DEVINDEX(y))) && (FD_MODE(y) != _out) )
      if( ((FD_MODE(y) == _ok) && (aff & (1<<DEVINDEX(y)))) ||
	  ((FD_MODE(y) == _liar) && !(aff & (1<<DEVINDEX(y)))) )
	obs |= (1<<DEVINDEX(y));

  // return 
  return( (int)obs );
}

void
_ramif_effect( stateClass& state )
{
  STATECLASSNAME* ptr;
  if( (ptr = dynamic_cast<STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in function ramif_effect." << endl;
      return;
    }

  if( !NEED_WAIT )
    {
      // make a dfs starting in all closed breakers to detected fed and affected status
      unsigned fed = 0, aff = 0;
      for( int y = FIRSTDEVICE; y <= LASTDEVICE; ++y )
	if( BREAKER(y) && CLOSED(y) )
	  {
	    // search in both sides
	    memset( display4, 0, DISPLAYSZ * sizeof( bool ) );
	    compute_fed_aff( ptr, fed, aff, y, SIDE1 );
	    memset( display4, 0, DISPLAYSZ * sizeof( bool ) );
	    compute_fed_aff( ptr, fed, aff, y, SIDE2 );
	  }

      // effect
      for( int y = FIRSTDEVICE; y <= LASTDEVICE; ++y )
	if( BREAKER(y) && CLOSED(y) && (aff & (1<<DEVINDEX(y))) )
	  SET_CLOSED(y,false);
    }
}

bool
_fed( const stateClass& state, int x )
{
  const STATECLASSNAME* ptr;
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in function fed." << endl;
      return( false );
    }

  // make a dfs starting in all closed breakers to detected fed status
  unsigned fed = 0, aff = 0;
  for( int y = FIRSTDEVICE; y <= LASTDEVICE; ++y )
    if( BREAKER(y) && CLOSED(y) )
      {
	// search in both sides
	memset( display4, 0, DISPLAYSZ * sizeof( bool ) );
	compute_fed_aff( ptr, fed, aff, y, SIDE1 );
	memset( display4, 0, DISPLAYSZ * sizeof( bool ) );
	compute_fed_aff( ptr, fed, aff, y, SIDE2 );
      }
  return( fed & (1<<DEVINDEX(x)) );
}

bool
_bad( const stateClass& state, int x )
{
  const STATECLASSNAME* ptr;
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in function bad." << endl;
      return( false );
    }

  if( !BREAKER(x) )
    {
      // bad(x) iff exists[y,sy,z,sz].closed_path(y,sy,l1) & closed_path(z,sz,l2)
      // where l1 and l2 are the lines connected to x
      int l1, l2, y;
      for( l1 = FIRSTLINE; l1 <= LASTLINE; ++l1 )
	if( EXT(l1,x,SIDE1) ) break;
      for( l2 = FIRSTLINE; l2 <= LASTLINE; ++l2 )
	if( EXT(l2,x,SIDE2) ) break;

      if( !CLOSED(x) && (l1 <= LASTLINE) && (l2 <= LASTLINE) )
	{
	  // check closed_path(y,sy,l1)
	  for( y = FIRSTDEVICE; y <= LASTDEVICE; ++y )
	    if( BREAKER(y) && (_closed_path(state,y,SIDE1,l1) || _closed_path(state,y,SIDE2,l1)) )
	      break;

	  // check closed_path(z,sz,l2)
	  if( y <= LASTDEVICE )
	    {
	      for( y = FIRSTDEVICE; y <= LASTDEVICE; ++y )
		if( BREAKER(y) && (_closed_path(state,y,SIDE1,l2) || _closed_path(state,y,SIDE2,l2)) )
		  return( true );
	    }
	}
    }
  else
    {
      int l, y;
      for( l = FIRSTLINE; l <= LASTLINE; ++l )
	if( EXT(l,x,SIDE1) ) break;
      if( l <= LASTLINE )
	for( y = FIRSTDEVICE; y <= LASTDEVICE; ++y )
	  {
	    if( EXT(l,y,SIDE1) && _closed_path(state,y,SIDE1,l) )
	      return( true );
	    if( EXT(l,y,SIDE2) && _closed_path(state,y,SIDE2,l) )
	      return( true );
	  }

      for( l = FIRSTLINE; l <= LASTLINE; ++l )
	if( EXT(l,x,SIDE2) ) break;
      if( l <= LASTLINE )
	for( y = FIRSTDEVICE; y <= LASTDEVICE; ++y )
	  {
	    if( EXT(l,y,SIDE1) && _closed_path(state,y,SIDE1,l) )
	      return( true );
	    if( EXT(l,y,SIDE2) && _closed_path(state,y,SIDE2,l) )
	      return( true );
	  }
    }
  return( false );
}
