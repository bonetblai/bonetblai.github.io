#include <iostream.h>
#include <string.h>
#include <theseus/theRtStandard.h>
#include "s4_power_supply.h"

#define STATECLASSNAME        stateFor_s4Class
#define FIRSTLINE             _l1
#define LASTLINE              _l7
#define FIRSTDEVICE           _cb1
#define LASTDEVICE            _sd7
#define DISPLAYSZ             256
#define OPP(s)                ((s) == _side1 ? _side2 : _side1)
#define CODE(dev,lin)         ((lin) == _side1 ? (dev) : 128+(dev))

static bool display1[DISPLAYSZ];
static bool display2[DISPLAYSZ];
static bool display3[DISPLAYSZ];
static bool display4[DISPLAYSZ];

static bool path( const STATECLASSNAME* ptr, int x, int sx, int l );
static bool fault_downstream( const STATECLASSNAME* ptr, int x, int sx );
static bool closed_path( const STATECLASSNAME* ptr, int x, int sx, int y, int sy );
static bool closed_path_line( const STATECLASSNAME* ptr, int x, int sx, int l );


bool
_path( const stateClass& state, int x, int sx, int l )
{
  const STATECLASSNAME* ptr;
  memset( display1, 0, DISPLAYSZ * sizeof( bool ) );
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in predicate path." << endl;
      return( false );
    }
  cout << "path(x=" << x << ",sx=" << sx << ") = "; cout.flush();
  bool rv = path( ptr, x, sx, l );
  cout << rv << endl;
  return( rv );
}

static bool
path( const STATECLASSNAME* ptr, int x, int sx, int l )
{
  // set display
  display1[CODE(x,sx)] = true;

  // base cases
  if( (ptr->staticFunction1[_ac_mode][x] != _ok) || bitValue( &(ptr->predicate1[_faulty][0]), l ) )
    return( false );

  // if line is connected to x, we are done!
  if( bitValue(&(ptr->staticPredicate3[_ext][0]),(l*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
    return( true );

  // expand path
  for( int lin = FIRSTLINE; lin <= LASTLINE; ++lin )
    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
      for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
	  {
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side1) &&
		!display1[CODE(dev,_side1)] && path( ptr, dev, _side1, l ) )
	      return( true );
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side2) &&
		!display1[CODE(dev,_side2)] && path( ptr, dev, _side2, l ) )
	      return( true );
	  }
  return( false );
}

bool
_closed_path( const stateClass& state, int x, int sx, int y, int sy )
{
  const STATECLASSNAME* ptr;
  memset( display2, 0, DISPLAYSZ * sizeof( bool ) );
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in predicate closed_path." << endl;
      return( false );
    }
  //  cout << "closed_path(x=" << x << ",sx=" << sx << ",y=" << y << ",sy=" << sy << ") = "; cout.flush();
  bool rv = closed_path( ptr, x, sx, y, sy );
  //  cout << rv << endl;
  return( rv );
}

static bool
closed_path( const STATECLASSNAME* ptr, int x, int sx, int y, int sy )
{
  // set display
  display2[CODE(x,sx)] = true;

  // x must be closed
  if( !bitValue( &(ptr->predicate1[_closed][0]), x ) )
    return( false );

  // expand path
  for( int lin = FIRSTLINE; lin <= LASTLINE; ++lin )
    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
      {
	// if x is directly connected to y, we are done!
	if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+y)*NUMOBJECTS+sy) )
	  return( true );

	// otherwise, need to continue ..
	for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
	  {
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side1) &&
		!display2[CODE(dev,_side1)] && closed_path( ptr, dev, _side1, y, sy ) )
	      return( true );
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side2) &&
		!display2[CODE(dev,_side2)] && closed_path( ptr, dev, _side2, y, sy ) )
	      return( true );
	  }
      }
  return( false );
}

bool
_closed_path_line( const stateClass& state, int x, int sx, int l )
{
  const STATECLASSNAME* ptr;
  memset( display3, 0, DISPLAYSZ * sizeof( bool ) );
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in predicate closed_path_line." << endl;
      return( false );
    }
  cout << "closed_path_line(x=" << x << ",sx=" << sx << ",l=" << l << ") = "; cout.flush();
  bool rv = closed_path_line( ptr, x, sx, l );
  cout << rv << endl;
  return( rv );
}

static bool
closed_path_line( const STATECLASSNAME* ptr, int x, int sx, int l )
{
  // set display
  display3[CODE(x,sx)] = true;

  // x must be closed
  if( !bitValue( &(ptr->predicate1[_closed][0]), x ) )
    return( false );

  // if line is connected to x, we are done!
  if( bitValue(&(ptr->staticPredicate3[_ext][0]),(l*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
    return( true );

  // expand path
  for( int lin = FIRSTLINE; lin <= LASTLINE; ++lin )
    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
      {
	for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
	  {
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side1) &&
		!display3[CODE(dev,_side1)] && closed_path_line( ptr, dev, _side1, l ) )
	      return( true );
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side2) &&
		!display3[CODE(dev,_side2)] && closed_path_line( ptr, dev, _side2, l ) )
	      return( true );
	  }
      }
  return( false );
}

bool
_fault_downstream( const stateClass& state, int x, int sx )
{
  const STATECLASSNAME* ptr;
  memset( display4, 0, DISPLAYSZ * sizeof( bool ) );
  if( (ptr = dynamic_cast<const STATECLASSNAME*>(&state)) == NULL )
    {
      cerr << "Error: dynamic_cast failed in predicate fault_downstream." << endl;
      return( false );
    }
  //  cout << "fault_downstrem(x=" << x << ",sx=" << sx << ") = "; cout.flush();
  bool rv = fault_downstream( ptr, x, sx );
  //  cout << rv << endl;
  return( rv );
}

static bool
fault_downstream( const STATECLASSNAME* ptr, int x, int sx )
{
  // set display
  display4[CODE(x,sx)] = true;

  // x must be closed
  if( !bitValue( &(ptr->predicate1[_closed][0]), x ) )
    return( false );

  // expand path
  for( int lin = FIRSTLINE; lin <= LASTLINE; ++lin )
    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+x)*NUMOBJECTS+OPP(sx)) )
      {
	// if x is faulty, we are done!
	if( bitValue( &(ptr->predicate1[_faulty][0]), lin ) )
	  return( true );

	// otherwise, need to continue ..
	for( int dev = FIRSTDEVICE; dev <= LASTDEVICE; ++dev )
	  {
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side1) &&
		!display4[CODE(dev,_side1)] && fault_downstream( ptr, dev, _side1 ) )
	      return( true );
	    if( bitValue(&(ptr->staticPredicate3[_ext][0]),(lin*NUMOBJECTS+dev)*NUMOBJECTS+_side2) &&
		!display4[CODE(dev,_side2)] && fault_downstream( ptr, dev, _side2 ) )
	      return( true );
	  }
      }
  return( false );
}
