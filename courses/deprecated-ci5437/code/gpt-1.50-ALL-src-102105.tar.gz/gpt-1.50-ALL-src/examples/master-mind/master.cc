#include <theseus/thePOMDP.h>
#include <theseus/theStandardModel.h>
#include <theseus/theStandardBelief.h>
#include <master.h>
#include <iostream>
#include <math.h>


float
masterHeuristicClass::value( const beliefClass *belief )
{
  double rv = floor(log(belief->supportSize())/log(9.0));
  return( rv );
}
