#include <theseus/theHeuristic.h>

class masterHeuristicClass : public heuristicClass
{
public:
  virtual float  value( const beliefClass *belief );
};
