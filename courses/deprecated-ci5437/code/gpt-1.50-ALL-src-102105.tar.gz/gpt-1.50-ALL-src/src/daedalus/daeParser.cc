#ifndef lint
/*static char yysccsid[] = "from: @(#)yaccpar	1.9 (Berkeley) 02/21/93";*/
static char yyrcsid[] = "$Id: skeleton.c,v 1.2 1997/06/23 02:51:17 tdukes Exp $";
#endif
#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#define YYRECOVERING (yyerrflag!=0)
#define YYPREFIX "yy"
#line 11 "daeParser.y"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <libgen.h>
#include <assert.h>

using namespace std;

#include <daedalus/daeTokens.h>
#include <daedalus/daeTypes.h>
#include <daedalus/daePackage.h>
#include <daedalus/_daeErrors.h>

#include <typeinfo>
#include <list>
#include <map>

#ifdef linux
extern "C" int yylex( void );
#endif

#define MAX(x,y)             ((x)>(y)?(x):(y))


/* globals*/
char*                        yyfile;
char*                        yyparser;
bool                         parsingPredicateId = false;
static const char*           currInternalPredicate = NULL;

static int                   domainType;
static bool                  insideEffect = false; 
static const char*           currentRamification = NULL;
static typeListClass*        plusFunctionDomain = NULL;
static typeClass*            plusFunctionRange = NULL;
static typeListClass*        minusFunctionDomain = NULL;
static typeClass*            minusFunctionRange = NULL;
static int                   maxNumResStates = 0;

list<const codeChunkClass*>* globalChunk = NULL;
predicateClass*              theEqualPredicate = NULL;
predicateClass*              theLessThanPredicate = NULL;
predicateClass*              theLessEqualPredicate = NULL;
predicateClass*              theGreaterEqualPredicate = NULL;
predicateClass*              theGreaterThanPredicate = NULL;

booleanTypeClass*            theBooleanType = NULL;
genericIntegerTypeClass*     theGenericIntegerType = NULL;

domainClass*                 declaredDomain = NULL;
problemClass*                declaredProblem = NULL;
actionClass*                 declaredAction = NULL;

map<const char*,const domainClass*,ltstr> domainHash;
map<const char*,const char*,ltstr> problemSet;

map<const char*,const functionClass*,ltstr>   globalFunctionHash;
map<const char*,const predicateClass*,ltstr>  globalPredicateHash;
map<const char*,const namedTypeClass*,ltstr>  globalNamedTypeHash;
map<const char*,const functionClass*,ltstr>*  functionHash = NULL;
map<const char*,const predicateClass*,ltstr>* predicateHash = NULL;
map<const char*,const namedTypeClass*,ltstr>* namedTypeHash = NULL;
map<const char*,list<const char*>*,ltstr>*    objectHashByType = NULL;
map<const char*,const typeClass*,ltstr>*      objectHashByName = NULL;
map<const char*,const arrayClass*,ltstr>*     arrayHash = NULL;
set<const char*,ltstr>*                       externalProcedureList = NULL;

set<const char*,ltstr>           actionSet;
set<const char*,ltstr>           ramificationSet;
set<const char*,ltstr>           internalPredicateSet;

list<const actionClass*>*            actionList = NULL;
list<const ramificationClass*>*      ramificationList = NULL;
list<const internalPredicateClass*>* internalPredicateList = NULL;

set<const char*,ltstr>           ramDirtyPredicates;
set<const char*,ltstr>           ramDirtyFunctions;

/* environment for variables*/
static list<map<const char*,const typeClass*,ltstr>*> variableEnvironment;
static list<pair<const char*,const typeClass*> >          parameterList;

/* prototypes*/
static void                  startDomain( const char* );
static const codeChunkClass* finishDomain( void );
static void                  declareModel( void );
static void                  declareDynamics( int );
static void                  declareFeedback( int );
static void                  declareExternal( const char* );
static void                  declareExternal( const list<const char*>* );
static void                  declareNamedType( const char*, const list<const char*>* );
static void                  declareFunction( const char*, const typeClass*, const typeClass* );
static void                  declarePredicate( const char*, const typeClass* );
static void                  declareProcedure( const char* );
static void                  declareSimpleObjects( const char*, const list<const char*> * );
static void                  declareIntegerObjects( const char*, const char*, const list<const char*> * );
static void                  declareBooleanObjects( const list<const char*>* );
static void                  declareArrayObjects( const char*, const typeClass*, const list<const char*>* );
static void                  declareVariable( const char*, const typeClass* );
static void                  startRamification( const char* );
static void                  declareRamification( const formulaClass* );
static void                  declareRamification( const effectClass* );
static void                  startLogicalDef( const char* );
static void                  declareLogicalDef( const char*, const formulaClass* );
static void                  startAction( const char* );
static void                  finishAction( void );
static void                  declareActionPrecondition( const formulaClass* );
static void                  declareActionEffect( const effectClass* );
static void                  declareActionCost( const costClass* );
static void                  declareActionObservation( const observationClass* );
static termClass *           fetchVariableTerm( const char*, termClass* );
static termClass *           fetchObjectTerm( const char*, const termClass* );
static void                  setVariableDenotationFor( const char* );
static bool                  checkProbabilities( const probabilisticEffectClass* );
static void                  checkProbabilities(const list<pair<const char*,const observationListClass*>*>*);
static void                  startProblem( const char*, const char* );
static const codeChunkClass* finishProblem( void );
static void                  declareInit( const effectListClass* );
static void                  declareGoal( const formulaClass* );
static void                  declareHook( const hookClass* );
static void                  cleanEnvironment( map<const char*,const typeClass*,ltstr>* );
static void                  printEnvironment( void ); 
static list<map<const char*,const typeClass*,ltstr>*>* environmentClone( void );
extern void                  generateCode( problemClass* );
#line 145 "y.tab.c"
#define DEFINE 257
#define PDOMAIN 258
#define CDOMAIN 259
#define PROBLEM 260
#define REQUIREMENTS 261
#define TYPES 262
#define FUNCTION 263
#define FUNCTIONS 264
#define PREDICATE 265
#define PREDICATES 266
#define PROCEDURE 267
#define EXTERNAL 268
#define OBJECTS 269
#define ACTION 270
#define PARAMETERS 271
#define PRECONDITION 272
#define EFFECT 273
#define COST 274
#define OBSERVATION 275
#define WHEN 276
#define INIT 277
#define GOAL 278
#define PACKAGE 279
#define RAMIFICATION 280
#define FORMULA 281
#define SET 282
#define IN 283
#define ONEOF 284
#define PRINT 285
#define PRINTSTATE 286
#define ASSERT 287
#define HOOKS 288
#define BELIEF 289
#define HEURISTIC 290
#define MODEL 291
#define PLANNING 292
#define CONFORMANT1 293
#define CONFORMANT2 294
#define ND_MDP 295
#define MDP 296
#define ND_POMDP1 297
#define ND_POMDP2 298
#define POMDP1 299
#define POMDP2 300
#define DYNAMICS 301
#define DETERMINISTIC 302
#define NON_DETERMINISTIC 303
#define PROBABILISTIC 304
#define FEEDBACK 305
#define COMPLETE 306
#define PARTIAL 307
#define NULLF 308
#define INTEGER 309
#define BOOLEAN 310
#define ARRAY 311
#define LEFTPAR 312
#define RIGHTPAR 313
#define LEFTSQPAR 314
#define RIGHTSQPAR 315
#define LEFTCURLY 316
#define RIGHTCURLY 317
#define COLON 318
#define STAR 319
#define HYPHEN 320
#define COMMA 321
#define NOT 322
#define AND 323
#define OR 324
#define IF 325
#define IFF 326
#define EQUAL 327
#define LT 328
#define LE 329
#define GE 330
#define GT 331
#define PLUS 332
#define EXISTS 333
#define FORALL 334
#define VECTOR 335
#define SUM 336
#define FOREACH 337
#define INLINE 338
#define CERTAINTY 339
#define TOK_IDENT 340
#define TOK_VIDENT 341
#define TOK_INTEGER 342
#define TOK_FLOAT 343
#define TOK_BOOLEAN 344
#define TOK_STRING 345
#define TOK_FUNCTION 346
#define TOK_PREDICATE 347
#define TOK_PROCEDURE 348
#define BOGUS 349
#define BOGUS2 350
#define BOGUS3 351
#define BOGUS4 352
#define YYERRCODE 256
short yylhs[] = {                                        -1,
    0,    3,    3,    3,   49,    1,   50,   50,   54,   54,
   54,   54,   54,   54,   54,   55,   55,   62,   62,   62,
   63,   63,   63,   64,   64,   64,   56,   56,   67,   65,
   66,   57,   57,   69,   69,    5,    5,    4,   58,   58,
   70,   59,   59,   71,    8,    8,    8,    9,    9,    9,
   11,   12,   72,   10,   10,   60,   60,   73,   73,   73,
   61,   61,   74,   74,   74,   74,    6,    6,   51,   51,
   75,   78,   79,   76,   52,   52,   82,   80,   83,   83,
   81,   81,   77,   77,   84,    7,    7,   53,   53,   87,
   85,   19,   86,   86,   88,   88,   89,   88,   88,   88,
   13,   15,   15,   15,   15,   15,   15,   90,   15,   91,
   15,   16,   16,   14,   14,   17,   17,   17,   20,   20,
   21,   21,   21,   21,   24,   24,   25,   25,   25,   25,
   25,   25,   92,   25,   25,   25,   26,   26,   27,   27,
   23,   23,   22,   22,   28,   28,   28,   35,   35,   29,
   29,   93,   29,   36,   36,   30,   30,   30,   30,   30,
   30,   30,   32,   32,   32,   32,   32,   18,   18,   39,
   39,   34,   37,   37,   31,   40,   41,   41,   41,   42,
   42,   43,   43,   43,   43,   94,   43,   45,   45,   44,
   47,   47,   46,   96,    2,   95,   95,   97,   97,   97,
   97,   98,   99,   99,   38,   38,   33,   33,   33,  101,
   33,  100,  100,   48,   48,   48,  103,   68,  102,
};
short yylen[] = {                                         2,
    1,    2,    2,    0,    0,   13,    3,    2,    3,    3,
    3,    3,    3,    3,    3,    1,    1,    2,    2,    0,
    4,    4,    4,    4,    4,    4,    2,    1,    0,    6,
    1,    2,    1,    2,    1,    2,    1,    3,    2,    1,
    5,    2,    1,    4,    1,    3,    5,    1,    1,    1,
    2,    5,    1,    2,    1,    2,    1,    6,    5,    4,
    2,    1,    3,    3,    3,    7,    2,    1,    3,    0,
    1,    0,    0,    9,    3,    0,    0,    5,    3,    3,
    2,    0,    2,    1,    3,    2,    1,    3,    1,    0,
    5,    1,    2,    0,    2,    2,    0,    3,    2,    2,
    1,    1,    4,    4,    4,    5,    5,    0,    9,    0,
    9,    1,    0,    2,    1,    4,    5,    7,    1,    1,
    1,    1,    1,    1,    2,    0,    1,    2,    1,    4,
    4,    2,    0,    9,    6,    4,    3,    0,    1,    1,
    2,    2,    3,    0,    1,    4,    4,    2,    1,    1,
    5,    0,    8,    2,    1,    5,    8,    8,    4,    4,
    3,    3,    9,    7,   12,    4,    1,    2,    0,    2,
    1,    4,    2,    1,    3,    1,    1,    4,    4,    2,
    1,    1,    1,    5,    5,    0,    8,    2,    1,    4,
    2,    1,    3,    0,   13,    2,    0,    4,    4,    4,
    4,    1,    1,    1,    2,    1,    1,    1,    5,    0,
    8,    2,    1,    4,    4,    4,    0,    5,    1,
};
short yydefred[] = {                                      4,
    0,    0,    0,    2,    3,    0,    0,    0,    0,    0,
    0,    5,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,   28,
    0,    0,   33,    0,    0,   40,    0,    0,   43,    0,
    0,   57,   68,    0,    0,   62,   16,    0,    0,    0,
    0,    8,  194,    0,   10,   27,    0,   37,    0,   11,
   32,    0,   12,   39,    0,   13,   42,    0,    0,    0,
   14,   56,    0,   67,   15,   61,    9,    0,   18,   19,
    0,    0,    0,    0,   71,    0,    7,  197,    0,    0,
   36,    0,   53,    0,    0,   48,    0,   45,   49,   50,
   55,    0,    0,    0,    0,    0,   63,   64,   65,    0,
    0,    0,   77,    0,    0,   89,   69,    0,    0,   29,
   38,    0,   51,    0,    0,    0,   44,   54,    0,    0,
   60,    0,    0,    0,    0,    0,    0,    0,   72,    0,
   92,   90,    0,    6,   75,    0,  195,  196,    0,    0,
    0,   46,   41,    0,   59,    0,   21,   22,   23,   24,
   25,   26,    0,    0,    0,   94,   88,    0,    0,    0,
    0,    0,   30,   31,    0,    0,   58,    0,   87,    0,
    0,   84,    0,    0,    0,   78,    0,    0,    0,  167,
  102,  207,  208,  206,    0,    0,    0,  204,  203,    0,
    0,  213,    0,    0,    0,   47,   66,    0,   86,    0,
   83,    0,  149,  150,    0,    0,    0,    0,   97,    0,
    0,   91,   93,  200,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,  121,  122,  123,  124,
    0,    0,    0,  120,    0,  126,  119,  205,  198,  199,
    0,    0,    0,  201,  212,  217,   52,   85,    0,    0,
    0,    0,   80,  148,   79,    0,   96,  101,    0,    0,
    0,    0,  127,  139,  140,  176,  129,   99,    0,  182,
  183,  100,    0,  181,    0,    0,    0,    0,    0,    0,
    0,    0,  161,    0,    0,  115,    0,    0,    0,    0,
    0,    0,    0,  162,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,   98,    0,    0,    0,    0,
    0,    0,  126,  126,  132,    0,  128,    0,    0,    0,
    0,    0,    0,  180,    0,  126,    0,    0,  126,  166,
  160,  159,  103,  104,  114,  105,    0,    0,    0,    0,
    0,    0,  116,  125,  215,  216,  214,  219,  218,   74,
    0,  155,    0,  126,    0,    0,    0,    0,    0,  142,
    0,  141,    0,    0,    0,    0,    0,    0,  192,    0,
    0,  189,    0,    0,    0,  209,    0,  126,    0,  156,
    0,  106,  107,  117,    0,    0,  210,  151,  154,    0,
  152,    0,  174,    0,    0,  171,    0,  136,    0,    0,
    0,  130,  131,  137,    0,    0,    0,  179,  191,    0,
  178,  188,    0,    0,    0,    0,    0,    0,  112,  108,
  110,    0,    0,    0,    0,  147,  173,    0,  146,  170,
  143,    0,    0,  184,  185,  193,    0,  186,    0,    0,
    0,    0,  168,  164,  118,    0,    0,    0,    0,  175,
    0,  135,  133,  190,    0,  126,  158,  157,    0,    0,
    0,  211,  153,  172,    0,    0,    0,  163,  109,  111,
    0,  187,    0,  134,    0,  165,
};
short yydgoto[] = {                                       1,
    4,    5,    2,   58,   59,   44,  180,   97,  101,  102,
   99,  123,  267,  295,  190,  430,  191,  427,  142,  246,
  247,  370,  324,  305,  354,  327,  277,  316,  213,  214,
  403,  193,  194,  406,  215,  363,  404,  195,  407,  278,
  282,  283,  284,  382,  383,  379,  380,  202,   14,   25,
   50,   83,  115,   26,   48,   29,   32,   35,   38,   41,
   45,   49,   79,   80,   30,  173,  149,  174,   33,   36,
   39,  100,   42,   46,   84,   85,  181,  163,  210,   86,
  165,  140,  186,  182,  116,  187,  166,  223,  269,  456,
  457,  475,  434,  465,  119,   88,  148,  196,  200,  203,
  432,  359,  309,
};
short yysindex[] = {                                      0,
    0, -277, -220,    0,    0, -265, -226, -287, -282, -238,
 -227,    0, -208, -166, -171,  380, -247, -160, -175, -125,
 -117, -107, -156,  -62,  380,  -76,  -68,  -25, -195,    0,
  -59, -294,    0,  -50, -183,    0,  -36, -115,    0,  -42,
 -105,    0,    0, -280, -288,    0,    0,  -45,  -34, -224,
  -15,    0,    0,  -31,    0,    0,  -16,    0,  -59,    0,
    0,  -94,    0,    0, -219,    0,    0,  -20,  -10,   -8,
    0,    0, -172,    0,    0,    0,    0, -130,    0,    0,
   -5,   -6,   69,   48,    0,   53,    0,    0,   58,   29,
    0,   85,    0,  134, -219,    0, -219,    0,    0,    0,
    0, -162,  -94, -219,   82,  136,    0,    0,    0,   25,
   56,   77,    0,  106,  -79,    0,    0,  180,  -74,    0,
    0,  125,    0,  131,  -52,  165,    0,    0, -219,   28,
    0,  144,  183,  189,  190,  191,  198,  206,    0,  222,
    0,    0,   69,    0,    0,  -87,    0,    0,  210,  204,
  208,    0,    0,  224,    0,  226,    0,    0,    0,    0,
    0,    0,  209,  209, -149,    0,    0, -156,  239, -212,
  245,  284,    0,    0,  217, -219,    0, -219,    0, -296,
  209,    0,  209,  255,  259,    0, -191, -187,  -12,    0,
    0,    0,    0,    0,  239,  266,  104,    0,    0,  271,
   99,    0,  -71,  235,  268,    0,    0, -219,    0,  272,
    0, -243,    0,    0,  -61,  278,  209,  259,    0,  246,
  254,    0,    0,    0,  259,  262,  246,  239,  270,  292,
  259,  259,  259,  259,  259,  246,    0,    0,    0,    0,
  252,  256,  260,    0,  300,    0,    0,    0,    0,    0,
  264,  273,  274,    0,    0,    0,    0,    0,  259,  259,
  280,  275,    0,    0,    0,  209,    0,    0,  305,  -38,
  246,  309,    0,    0,    0,    0,    0,    0,   20,    0,
    0,    0,  288,    0,  239, -233,  130,  310,  -37,   78,
  312,  314,    0,  318,  -32,    0,  -27,  259,  259,  246,
  313,  315,  319,    0,  150,  321,  330,  332,  334,  337,
  339,  -41,  246,  333,  -93,    0,  255,  259,  324,  259,
  324,  316,    0,    0,    0,  246,    0,  259,  342,  343,
  259,  317,   50,    0,  -13,    0, -128,  346,    0,    0,
    0,    0,    0,    0,    0,    0,  347,  348,  349,  323,
  325,  326,    0,    0,    0,    0,    0,    0,    0,    0,
 -274,    0,   45,    0,  327,  344,  352,  355,  328,    0,
  246,    0,  353,  168,  176,  354,  270,  288,    0,   79,
  329,    0,   81,  270,  356,    0,  186,    0,  387,    0,
  124,    0,    0,    0,  340,  340,    0,    0,    0,  194,
    0,  255,    0,  103,  336,    0,  127,    0,  350,  246,
  335,    0,    0,    0,  364,  367,  202,    0,    0,  288,
    0,    0,  345,  135,  212,  259,  369,  370,    0,    0,
    0,  239,  270,  255,  132,    0,    0,  255,    0,    0,
    0,  371,  340,    0,    0,    0,  220,    0,  372,  373,
  374,  387,    0,    0,    0,  259,  259,  140,  170,    0,
  172,    0,    0,    0,  246,    0,    0,    0,  376,  377,
  378,    0,    0,    0,  246,  379,  228,    0,    0,    0,
  381,    0,  387,    0,  382,    0,
};
short yyrindex[] = {                                      0,
    0,  693,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,  188,  -33,    0,    0,    0,    0,    0,
 -177,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,  383,  427,
    0,    0,    0,    0,    0,    0,    0,    0, -144,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,  427,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0, -132,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
  385,    0,  -96,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,  386,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0, -163,    0,    0,    0,    0,
    0, -113,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,  148,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,  184,    0,  236,    0,
  236,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,  388,    0,
    0,    0,    0,    0,  390,  390,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,  296,    0,    0,    0,    0,    0,    0,    0,
    0,  388,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,  388,    0,    0,    0,
};
short yygindex[] = {                                      0,
    0,    0,    0,  641,    0,    0,    0,  600,  -53,    3,
  -72,    0,    0,  471, -164, -379,    0, -432,    0,    0,
    0,  384,    0, -309, -198,    0,    0,    0, -211, -169,
  302,    0, -192,  301, -262,    0,    0, -223,    0,    0,
    0, -342, -273,  331,    0,  338,    0,  504,    0,    0,
    0,  591,    0,  685,    0,    0,    0,    0,    0,    0,
  543,    0,    0,    0,  683,    0,    0,    0,  681,  680,
  678,  644,  679,  -43,    0,    0, -151,    0,    0,    0,
    0,    0,    0, -165,  576,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,
};
#define YYTABLESIZE 720
short yytable[] = {                                     192,
  108,   76,  248,  264,  289,  199,  317,  261,   98,  334,
  229,  230,  183,  374,  375,  211,  431,  211,   60,  469,
  216,  276,  281,  208,   75,  192,  387,  287,  288,  391,
  292,    8,  260,    9,    3,  417,    6,  300,  261,   73,
   81,  229,  230,  126,  209,   31,    7,  318,  128,   98,
  485,   43,   10,  268,  400,   82,  280,   11,  192,   74,
  285,  335,  313,  463,  291,  266,  294,  296,  296,  298,
  299,  128,  325,  245,   12,  154,  128,  447,  425,  217,
  218,  219,  220,  221,  281,   13,  319,   17,  338,   92,
   93,  320,   27,  262,  310,  311,  248,  125,  321,  197,
  211,  349,  322,   15,  245,  264,  130,   95,   95,   95,
   95,   95,  323,  336,  338,  192,   28,   55,  280,  192,
   96,  222,  206,  184,  207,  224,  198,  376,   34,   63,
  345,  185,  345,  347,  348,   35,   92,   93,  106,  435,
   82,  362,  248,  334,   76,   16,   92,   93,   82,   95,
  127,   28,   43,  368,  258,  371,  477,  138,  138,  138,
  138,  138,   35,  377,   31,  192,  384,  107,   34,  138,
  110,  459,  410,  334,  111,  461,   81,   96,  416,  281,
   92,  168,  260,   43,   81,  410,   34,  388,  261,  169,
  170,  229,  230,  399,   37,   34,   37,   66,  138,  138,
  171,  138,  138,  138,   40,  138,   40,   71,  458,  366,
  367,  442,  415,  280,   92,   93,   94,   95,  281,  347,
   68,  281,   69,  264,   70,  451,  138,  138,  138,   47,
  138,   70,  143,  144,  451,   52,   70,  146,  147,  318,
  201,  254,  318,  262,   53,   96,   70,  264,  281,  264,
  212,  263,  280,   54,  245,  280,   92,   93,   57,  450,
  152,  453,  192,  225,  389,  248,  476,   77,  450,  226,
  227,  228,  229,  230,  189,  340,  481,   78,  319,  197,
  344,  319,  280,  320,  197,  346,  320,   96,  192,   62,
  321,  470,  471,  321,  322,  328,   87,  322,  189,  386,
  318,   90,  227,   65,  323,  364,  112,  323,   89,  231,
  232,  233,  234,  235,  236,  237,  238,  239,  240,  103,
  241,  242,  329,  330,  243,  328,  133,  134,  135,  104,
  318,  105,  227,  113,  244,  245,   92,   93,  114,  319,
  155,  231,  232,  233,  331,  235,  236,  237,  238,  239,
  240,  321,  241,  242,  332,  322,  361,  398,  318,  117,
  227,  136,  137,  138,  118,  323,  244,   96,  121,  319,
  120,  231,  232,  233,  331,  235,  236,  237,  238,  239,
  240,  321,  241,  242,  332,  322,  227,  251,  252,  253,
  378,  418,  381,  421,  131,  323,  244,  319,  122,  231,
  232,  233,  331,  235,  236,  237,  238,  239,  240,  321,
  241,  242,  337,  322,  402,  436,  139,  449,  177,  177,
  177,  177,  177,  323,  244,  231,  232,  233,  234,  235,
  236,  237,  238,  239,  240,  270,  241,  242,  405,  439,
  428,  270,  271,  212,  460,  141,  290,  124,  271,  132,
  244,  189,  472,  271,  145,  145,  145,  145,  145,   82,
  177,  270,  353,  272,  273,  274,  150,  275,  271,  272,
  273,  274,  151,  275,  272,  273,  274,  153,  275,  270,
  412,  212,  473,  212,  474,  156,  271,  270,  413,  272,
  273,  274,  164,  275,  271,  157,  145,  270,  424,   20,
   20,  158,  159,  160,  271,  270,  433,  272,  273,  274,
  161,  275,  271,  333,  446,  272,  273,  274,  162,  275,
  271,  172,  176,  270,  175,  272,  273,  274,  452,  275,
  271,  333,  464,  272,  273,  274,  177,  275,  271,  270,
  178,  272,  273,  274,  483,  275,  271,  144,  144,  179,
  189,  272,  273,  274,  144,  275,  201,  270,  205,  272,
  273,  274,  204,  275,  271,  279,  212,  272,  273,  274,
  197,  275,  271,  286,  256,  144,  144,  144,  249,  144,
  271,  290,  257,  250,  259,  272,  273,  274,  271,  275,
  265,  312,  301,  272,  273,  274,  302,  275,  271,  333,
  303,  272,  273,  274,  293,  275,  271,  113,  306,  272,
  273,  274,  304,  275,  113,  314,  315,  307,  308,  272,
  273,  274,  326,  275,  341,  339,  342,  272,  273,  274,
  343,  275,  350,  355,  351,  113,  113,  113,  352,  113,
   18,   19,  356,   20,  357,   21,  358,   22,   23,  360,
  361,  369,  365,  378,  381,  402,  373,  385,  390,  392,
  393,  394,  395,  405,  396,  397,  401,  408,  414,  409,
   24,  420,  411,  426,  443,  423,  444,  429,  438,  445,
  441,  454,  455,  462,  448,  467,  468,  466,  478,  479,
  480,  482,    1,  484,  486,   17,   76,   73,  202,   91,
  169,  113,  129,  297,  372,  437,  255,  440,  145,   51,
  188,   56,   61,  422,   64,   67,  109,  419,  167,   72,
};
short yycheck[] = {                                     169,
   73,   45,  195,  215,  228,  170,  269,  282,   62,  283,
  285,  286,  164,  323,  324,  181,  396,  183,  313,  452,
  185,  220,  221,  320,  313,  195,  336,  226,  227,  339,
  229,  258,  276,  260,  312,  378,  257,  236,  282,  320,
  265,  285,  286,   97,  341,  340,  312,  281,  102,  103,
  483,  340,  340,  218,  364,  280,  221,  340,  228,  340,
  225,  285,  261,  443,  229,  217,  231,  232,  233,  234,
  235,  125,  271,  348,  313,  129,  130,  420,  388,  271,
  272,  273,  274,  275,  283,  313,  320,  259,  287,  309,
  310,  325,  340,  337,  259,  260,  289,   95,  332,  312,
  266,  300,  336,  312,  348,  317,  104,  271,  272,  273,
  274,  275,  346,  347,  313,  285,  312,  313,  283,  289,
  340,  313,  176,  273,  178,  313,  339,  326,  312,  313,
  295,  281,  297,  298,  299,  313,  309,  310,  311,  402,
  273,  311,  335,  417,  188,  312,  309,  310,  281,  313,
  313,  312,  340,  318,  208,  320,  466,  271,  272,  273,
  274,  275,  340,  328,  340,  335,  331,  340,  313,  283,
  301,  434,  371,  447,  305,  438,  273,  340,  377,  378,
  309,  269,  276,  340,  281,  384,  312,  316,  282,  277,
  278,  285,  286,  363,  312,  340,  312,  313,  312,  313,
  288,  315,  316,  317,  312,  319,  312,  313,  432,  303,
  304,  410,  377,  378,  309,  310,  311,  312,  417,  384,
  263,  420,  265,  435,  267,  424,  340,  341,  342,  292,
  344,  265,  312,  313,  433,  312,  270,  312,  313,  281,
  312,  313,  281,  337,  313,  340,  280,  459,  447,  461,
  312,  313,  417,  279,  348,  420,  309,  310,  318,  424,
  313,  426,  432,  276,  337,  458,  465,  313,  433,  282,
  283,  284,  285,  286,  312,  313,  475,  312,  320,  312,
  313,  320,  447,  325,  312,  313,  325,  340,  458,  340,
  332,  456,  457,  332,  336,  276,  312,  336,  312,  313,
  281,  318,  283,  340,  346,  347,  312,  346,  340,  322,
  323,  324,  325,  326,  327,  328,  329,  330,  331,  340,
  333,  334,  303,  304,  337,  276,  302,  303,  304,  340,
  281,  340,  283,  340,  347,  348,  309,  310,  270,  320,
  313,  322,  323,  324,  325,  326,  327,  328,  329,  330,
  331,  332,  333,  334,  335,  336,  312,  313,  281,  312,
  283,  306,  307,  308,  312,  346,  347,  340,  340,  320,
  313,  322,  323,  324,  325,  326,  327,  328,  329,  330,
  331,  332,  333,  334,  335,  336,  283,  289,  290,  291,
  312,  313,  312,  313,  313,  346,  347,  320,  314,  322,
  323,  324,  325,  326,  327,  328,  329,  330,  331,  332,
  333,  334,  283,  336,  312,  313,  340,  283,  271,  272,
  273,  274,  275,  346,  347,  322,  323,  324,  325,  326,
  327,  328,  329,  330,  331,  312,  333,  334,  312,  313,
  317,  312,  319,  312,  313,  340,  312,  314,  319,  314,
  347,  312,  313,  319,  271,  272,  273,  274,  275,  280,
  313,  312,  313,  340,  341,  342,  342,  344,  319,  340,
  341,  342,  342,  344,  340,  341,  342,  313,  344,  312,
  313,  312,  313,  312,  313,  342,  319,  312,  313,  340,
  341,  342,  271,  344,  319,  313,  313,  312,  313,  312,
  313,  313,  313,  313,  319,  312,  313,  340,  341,  342,
  313,  344,  319,  312,  313,  340,  341,  342,  313,  344,
  319,  312,  315,  312,  321,  340,  341,  342,  317,  344,
  319,  312,  313,  340,  341,  342,  313,  344,  319,  312,
  315,  340,  341,  342,  317,  344,  319,  312,  313,  341,
  312,  340,  341,  342,  319,  344,  312,  312,  342,  340,
  341,  342,  279,  344,  319,  312,  312,  340,  341,  342,
  312,  344,  319,  312,  340,  340,  341,  342,  313,  344,
  319,  312,  315,  313,  313,  340,  341,  342,  319,  344,
  313,  312,  341,  340,  341,  342,  341,  344,  319,  312,
  341,  340,  341,  342,  313,  344,  319,  312,  345,  340,
  341,  342,  313,  344,  319,  341,  312,  345,  345,  340,
  341,  342,  314,  344,  313,  316,  313,  340,  341,  342,
  313,  344,  320,  313,  320,  340,  341,  342,  320,  344,
  261,  262,  313,  264,  313,  266,  313,  268,  269,  313,
  312,  328,  320,  312,  312,  312,  341,  341,  313,  313,
  313,  313,  340,  312,  340,  340,  340,  313,  315,  342,
  291,  343,  320,  287,  340,  320,  313,  338,  343,  313,
  331,  313,  313,  313,  340,  313,  313,  316,  313,  313,
  313,  313,    0,  313,  313,  313,  270,  313,  313,   59,
  313,  312,  103,  233,  321,  404,  203,  407,  118,   25,
  168,   29,   32,  383,   35,   38,   73,  380,  143,   41,
};
#define YYFINAL 1
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 352
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"DEFINE","PDOMAIN","CDOMAIN",
"PROBLEM","REQUIREMENTS","TYPES","FUNCTION","FUNCTIONS","PREDICATE",
"PREDICATES","PROCEDURE","EXTERNAL","OBJECTS","ACTION","PARAMETERS",
"PRECONDITION","EFFECT","COST","OBSERVATION","WHEN","INIT","GOAL","PACKAGE",
"RAMIFICATION","FORMULA","SET","IN","ONEOF","PRINT","PRINTSTATE","ASSERT",
"HOOKS","BELIEF","HEURISTIC","MODEL","PLANNING","CONFORMANT1","CONFORMANT2",
"ND_MDP","MDP","ND_POMDP1","ND_POMDP2","POMDP1","POMDP2","DYNAMICS",
"DETERMINISTIC","NON_DETERMINISTIC","PROBABILISTIC","FEEDBACK","COMPLETE",
"PARTIAL","NULLF","INTEGER","BOOLEAN","ARRAY","LEFTPAR","RIGHTPAR","LEFTSQPAR",
"RIGHTSQPAR","LEFTCURLY","RIGHTCURLY","COLON","STAR","HYPHEN","COMMA","NOT",
"AND","OR","IF","IFF","EQUAL","LT","LE","GE","GT","PLUS","EXISTS","FORALL",
"VECTOR","SUM","FOREACH","INLINE","CERTAINTY","TOK_IDENT","TOK_VIDENT",
"TOK_INTEGER","TOK_FLOAT","TOK_BOOLEAN","TOK_STRING","TOK_FUNCTION",
"TOK_PREDICATE","TOK_PROCEDURE","BOGUS","BOGUS2","BOGUS3","BOGUS4",
};
char *yyrule[] = {
"$accept : start",
"start : code_chunks",
"code_chunks : code_chunks domain",
"code_chunks : code_chunks problem",
"code_chunks :",
"$$1 :",
"domain : LEFTPAR DEFINE LEFTPAR PDOMAIN TOK_IDENT RIGHTPAR $$1 LEFTPAR global_list definition_list ramification_list action_list RIGHTPAR",
"global_list : global_list global LEFTPAR",
"global_list : global LEFTPAR",
"global : MODEL model_def RIGHTPAR",
"global : REQUIREMENTS requirement_list RIGHTPAR",
"global : TYPES type_list RIGHTPAR",
"global : FUNCTIONS function_list RIGHTPAR",
"global : PREDICATES predicate_list RIGHTPAR",
"global : EXTERNAL external_list RIGHTPAR",
"global : OBJECTS object_list RIGHTPAR",
"model_def : PLANNING",
"model_def : non_plan_model_def",
"non_plan_model_def : non_plan_model_def dynamics_def",
"non_plan_model_def : non_plan_model_def feedback_def",
"non_plan_model_def :",
"dynamics_def : LEFTPAR DYNAMICS DETERMINISTIC RIGHTPAR",
"dynamics_def : LEFTPAR DYNAMICS NON_DETERMINISTIC RIGHTPAR",
"dynamics_def : LEFTPAR DYNAMICS PROBABILISTIC RIGHTPAR",
"feedback_def : LEFTPAR FEEDBACK COMPLETE RIGHTPAR",
"feedback_def : LEFTPAR FEEDBACK PARTIAL RIGHTPAR",
"feedback_def : LEFTPAR FEEDBACK NULLF RIGHTPAR",
"requirement_list : requirement_list requirement",
"requirement_list : requirement",
"$$2 :",
"requirement : LEFTPAR PACKAGE TOK_IDENT RIGHTPAR $$2 rest_requirement",
"rest_requirement : package",
"type_list : type_list type_def",
"type_list : type_def",
"type_def : TOK_IDENT ancestor_list",
"type_def : TOK_IDENT",
"ancestor_list : ancestor_list ancestor",
"ancestor_list : ancestor",
"ancestor : COLON COLON TOK_IDENT",
"function_list : function_list function",
"function_list : function",
"function : LEFTPAR TOK_IDENT compound_type_decl simple_type_decl RIGHTPAR",
"predicate_list : predicate_list predicate",
"predicate_list : predicate",
"predicate : LEFTPAR TOK_IDENT simple_type_decl_list RIGHTPAR",
"compound_type_decl : simple_type_decl",
"compound_type_decl : LEFTPAR simple_type_decl_list RIGHTPAR",
"compound_type_decl : ARRAY LEFTSQPAR TOK_INTEGER RIGHTSQPAR simple_type_decl",
"simple_type_decl : TOK_IDENT",
"simple_type_decl : integer_type",
"simple_type_decl : boolean_type",
"integer_type : INTEGER range",
"range : LEFTSQPAR TOK_INTEGER COMMA TOK_INTEGER RIGHTSQPAR",
"boolean_type : BOOLEAN",
"simple_type_decl_list : simple_type_decl_list simple_type_decl",
"simple_type_decl_list : simple_type_decl",
"external_list : external_list external_decl",
"external_list : external_decl",
"external_decl : LEFTPAR FUNCTION TOK_IDENT compound_type_decl simple_type_decl RIGHTPAR",
"external_decl : LEFTPAR PREDICATE TOK_IDENT simple_type_decl_list RIGHTPAR",
"external_decl : LEFTPAR PROCEDURE TOK_IDENT RIGHTPAR",
"object_list : object_list object_def",
"object_list : object_def",
"object_def : ident_list HYPHEN TOK_IDENT",
"object_def : ident_list HYPHEN integer_type",
"object_def : ident_list HYPHEN boolean_type",
"object_def : ident_list HYPHEN ARRAY LEFTSQPAR TOK_INTEGER RIGHTSQPAR simple_type_decl",
"ident_list : ident_list TOK_IDENT",
"ident_list : TOK_IDENT",
"definition_list : definition_list definition LEFTPAR",
"definition_list :",
"definition : logical_def",
"$$3 :",
"$$4 :",
"logical_def : PREDICATE LEFTPAR TOK_IDENT $$3 parameter_list $$4 RIGHTPAR formula RIGHTPAR",
"ramification_list : ramification_def LEFTPAR ramification_list",
"ramification_list :",
"$$5 :",
"ramification_def : RAMIFICATION TOK_IDENT $$5 optional_parameter ramification_def_rest",
"ramification_def_rest : FORMULA formula RIGHTPAR",
"ramification_def_rest : EFFECT atomic_effect_list RIGHTPAR",
"optional_parameter : PARAMETERS parameter_list",
"optional_parameter :",
"parameter_list : parameter_list parameter",
"parameter_list : parameter",
"parameter : variable_list HYPHEN simple_type_decl",
"variable_list : variable_list TOK_VIDENT",
"variable_list : TOK_VIDENT",
"action_list : action_list LEFTPAR action_def",
"action_list : action_def",
"$$6 :",
"action_def : ACTION action_name $$6 action_body_list RIGHTPAR",
"action_name : TOK_IDENT",
"action_body_list : action_body_list action_body",
"action_body_list :",
"action_body : PARAMETERS parameter_list",
"action_body : PRECONDITION precondition_formula",
"$$7 :",
"action_body : EFFECT $$7 effect_list",
"action_body : COST cost",
"action_body : OBSERVATION observation",
"precondition_formula : formula",
"formula : atomic_formula",
"formula : LEFTPAR NOT formula RIGHTPAR",
"formula : LEFTPAR AND formula_list RIGHTPAR",
"formula : LEFTPAR OR formula_list RIGHTPAR",
"formula : LEFTPAR IF formula formula RIGHTPAR",
"formula : LEFTPAR IFF formula formula RIGHTPAR",
"$$8 :",
"formula : LEFTPAR EXISTS TOK_VIDENT HYPHEN TOK_IDENT optional_inline $$8 formula RIGHTPAR",
"$$9 :",
"formula : LEFTPAR FORALL TOK_VIDENT HYPHEN TOK_IDENT optional_inline $$9 formula RIGHTPAR",
"optional_inline : INLINE",
"optional_inline :",
"formula_list : formula_list formula",
"formula_list : formula",
"atomic_formula : LEFTPAR predicate_symbol term_list RIGHTPAR",
"atomic_formula : LEFTPAR EQUAL term term RIGHTPAR",
"atomic_formula : LEFTPAR IN term LEFTCURLY term_list RIGHTCURLY RIGHTPAR",
"predicate_symbol : primitive_predicate_symbol",
"predicate_symbol : TOK_PREDICATE",
"primitive_predicate_symbol : LT",
"primitive_predicate_symbol : LE",
"primitive_predicate_symbol : GE",
"primitive_predicate_symbol : GT",
"term_list : term_list term",
"term_list :",
"term : TOK_VIDENT",
"term : TOK_IDENT optional_subscript",
"term : value",
"term : LEFTPAR TOK_FUNCTION term_list RIGHTPAR",
"term : LEFTPAR primitive_function_symbol term_list RIGHTPAR",
"term : STAR term",
"$$10 :",
"term : LEFTPAR SUM TOK_VIDENT HYPHEN TOK_IDENT optional_inline $$10 term RIGHTPAR",
"term : LEFTPAR IF formula term term RIGHTPAR",
"term : LEFTPAR FORMULA formula RIGHTPAR",
"optional_subscript : LEFTSQPAR term RIGHTSQPAR",
"optional_subscript :",
"value : TOK_INTEGER",
"value : TOK_BOOLEAN",
"primitive_function_symbol : PLUS optional_modulo",
"primitive_function_symbol : HYPHEN optional_modulo",
"optional_modulo : LT TOK_INTEGER GT",
"optional_modulo :",
"effect_list : atomic_effect_list",
"effect_list : LEFTPAR PROBABILISTIC probabilistic_effect_list RIGHTPAR",
"effect_list : LEFTPAR NON_DETERMINISTIC non_deterministic_effect_list RIGHTPAR",
"atomic_effect_list : atomic_effect_list atomic_effect",
"atomic_effect_list : atomic_effect",
"atomic_effect : basic_effect",
"atomic_effect : LEFTPAR WHEN formula basic_effect_list RIGHTPAR",
"$$11 :",
"atomic_effect : LEFTPAR FOREACH TOK_VIDENT HYPHEN TOK_IDENT $$11 atomic_effect_list RIGHTPAR",
"basic_effect_list : basic_effect_list basic_effect",
"basic_effect_list : basic_effect",
"basic_effect : LEFTPAR SET term term RIGHTPAR",
"basic_effect : LEFTPAR SET LEFTPAR TOK_PREDICATE term_list RIGHTPAR term RIGHTPAR",
"basic_effect : LEFTPAR SET LEFTPAR TOK_PREDICATE term_list RIGHTPAR formula RIGHTPAR",
"basic_effect : LEFTPAR PRINT term RIGHTPAR",
"basic_effect : LEFTPAR PRINT formula RIGHTPAR",
"basic_effect : LEFTPAR PRINTSTATE RIGHTPAR",
"basic_effect : LEFTPAR TOK_PROCEDURE RIGHTPAR",
"init_set_effect : LEFTPAR SET term IN LEFTCURLY term_list RIGHTCURLY optional_assert RIGHTPAR",
"init_set_effect : LEFTPAR SET term IN integer_type optional_assert RIGHTPAR",
"init_set_effect : LEFTPAR SET LEFTPAR TOK_PREDICATE term_list RIGHTPAR IN LEFTCURLY term_list RIGHTCURLY optional_assert RIGHTPAR",
"init_set_effect : LEFTPAR ONEOF atomic_init_effect_list RIGHTPAR",
"init_set_effect : formula",
"optional_assert : ASSERT formula",
"optional_assert :",
"probabilistic_effect_list : probabilistic_effect_list probabilistic_effect",
"probabilistic_effect_list : probabilistic_effect",
"probabilistic_effect : LEFTPAR TOK_FLOAT atomic_effect_list RIGHTPAR",
"non_deterministic_effect_list : non_deterministic_effect_list non_deterministic_effect",
"non_deterministic_effect_list : non_deterministic_effect",
"non_deterministic_effect : LEFTPAR atomic_effect_list RIGHTPAR",
"cost : term",
"observation : observation_list",
"observation : LEFTPAR PROBABILISTIC probabilistic_observation_list RIGHTPAR",
"observation : LEFTPAR NON_DETERMINISTIC non_deterministic_observation_list RIGHTPAR",
"observation_list : observation_list atomic_observation",
"observation_list : atomic_observation",
"atomic_observation : formula",
"atomic_observation : term",
"atomic_observation : LEFTPAR WHEN formula formula RIGHTPAR",
"atomic_observation : LEFTPAR WHEN formula term RIGHTPAR",
"$$12 :",
"atomic_observation : LEFTPAR VECTOR TOK_VIDENT HYPHEN TOK_IDENT $$12 term RIGHTPAR",
"probabilistic_observation_list : probabilistic_observation_list probabilistic_observation",
"probabilistic_observation_list : probabilistic_observation",
"probabilistic_observation : LEFTPAR TOK_FLOAT observation_list RIGHTPAR",
"non_deterministic_observation_list : non_deterministic_observation_list non_deterministic_observation",
"non_deterministic_observation_list : non_deterministic_observation",
"non_deterministic_observation : LEFTPAR observation_list RIGHTPAR",
"$$13 :",
"problem : LEFTPAR DEFINE LEFTPAR PROBLEM TOK_IDENT RIGHTPAR LEFTPAR CDOMAIN TOK_IDENT RIGHTPAR $$13 problem_def_list RIGHTPAR",
"problem_def_list : problem_def_list problem_def",
"problem_def_list :",
"problem_def : LEFTPAR INIT init_def RIGHTPAR",
"problem_def : LEFTPAR GOAL goal_def RIGHTPAR",
"problem_def : LEFTPAR OBJECTS object_list RIGHTPAR",
"problem_def : LEFTPAR HOOKS hook_list RIGHTPAR",
"init_def : atomic_init_effect_list",
"goal_def : formula",
"goal_def : CERTAINTY",
"atomic_init_effect_list : atomic_init_effect_list atomic_init_effect",
"atomic_init_effect_list : atomic_init_effect",
"atomic_init_effect : basic_effect",
"atomic_init_effect : init_set_effect",
"atomic_init_effect : LEFTPAR WHEN formula atomic_init_effect_list RIGHTPAR",
"$$14 :",
"atomic_init_effect : LEFTPAR FOREACH TOK_VIDENT HYPHEN TOK_IDENT $$14 atomic_init_effect_list RIGHTPAR",
"hook_list : hook_list hook",
"hook_list : hook",
"hook : LEFTPAR MODEL TOK_STRING RIGHTPAR",
"hook : LEFTPAR BELIEF TOK_STRING RIGHTPAR",
"hook : LEFTPAR HEURISTIC TOK_STRING RIGHTPAR",
"$$15 :",
"package : LEFTPAR PACKAGE TOK_IDENT $$15 rest_package",
"rest_package : RIGHTPAR",
};
#endif
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH 500
#endif
#endif
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short yyss[YYSTACKSIZE];
YYSTYPE yyvs[YYSTACKSIZE];
#define yystacksize YYSTACKSIZE
#line 1482 "daeParser.y"


//
// Function used by YACC to print syntax errors.
//
void
yyerror( const char *s )
{
  extern int lineno;
#ifdef sparc
  extern char yytext[];      // needed in my g++/sparc
#endif
#ifdef linux
  extern char *yytext;       // needed in my g++/linux
#endif

  insertFmtError( "%s:%d: %s before \"%s\"\n", basename( yyfile ), lineno, s, yytext );
}

//
// Initialization of parsing process. We allocate primitive types and 
// predicates, create basic hash tables, and initialize the package 
// processing facility. This function must be called just once.
//
void
initParser( void )
{
  list<const typeClass*> *domain;

  // declared objects
  declaredDomain = NULL;
  declaredProblem = NULL;
  declaredAction = NULL;
  variableEnvironment.clear();
  parameterList.clear();

  actionSet.clear();
  ramificationSet.clear();
  internalPredicateSet.clear();

  // constant types
  theBooleanType = new booleanTypeClass();
  theGenericIntegerType = new genericIntegerTypeClass();

  // hashs
  domainHash.clear();
  problemSet.clear();
  globalFunctionHash.clear();
  globalPredicateHash.clear();
  globalNamedTypeHash.clear();

  // primitive functions
  domain = new list<const typeClass*>;
  domain->push_back( new genericIntegerTypeClass );
  domain->push_back( new genericIntegerTypeClass );
  plusFunctionDomain = new typeListClass( domain );
  plusFunctionRange = new genericIntegerTypeClass;
  minusFunctionDomain = (typeListClass*)plusFunctionDomain->clone();
  minusFunctionRange = new genericIntegerTypeClass;

  // primitive predicates
  theLessThanPredicate = new predicateClass( strdup("_lessThan"), plusFunctionDomain->clone(), 
					     predicateClass::SIMPLE_DOMAIN, 1 );
  theLessEqualPredicate = new predicateClass( strdup("_lessEqual"), plusFunctionDomain->clone(), 
					      predicateClass::SIMPLE_DOMAIN, 1 );
  theGreaterEqualPredicate = new predicateClass( strdup("_greaterEqual"), plusFunctionDomain->clone(),
						 predicateClass::SIMPLE_DOMAIN, 1 );
  theGreaterThanPredicate = new predicateClass( strdup("_greaterThan"), plusFunctionDomain->clone(),
						predicateClass::SIMPLE_DOMAIN, 1 );
  globalPredicateHash.insert( make_pair( (const char*)"_lessThan", theLessThanPredicate ) );
  globalPredicateHash.insert( make_pair( (const char*)"_lessEqual", theLessEqualPredicate ) );
  globalPredicateHash.insert( make_pair( (const char*)"_greaterEqual", theGreaterEqualPredicate ) );
  globalPredicateHash.insert( make_pair( (const char*)"_greaterThan", theGreaterThanPredicate ) );

  domain = new list<const typeClass*>;
  domain->push_back( new universalTypeClass() );
  domain->push_back( new universalTypeClass() );
  theEqualPredicate = new predicateClass( strdup("="), new typeListClass( domain ), 
					  predicateClass::SIMPLE_DOMAIN );
  globalPredicateHash.insert( make_pair( (const char*)"=", theEqualPredicate ) );

  // primitive types
  globalNamedTypeHash.insert( make_pair( (const char*)":integer", (const namedTypeClass*)NULL ) );
  globalNamedTypeHash.insert( make_pair( (const char*)":boolean", (const namedTypeClass*)NULL ) );

  // packages
  initPackages();
}

static void
startDomain( const char *ident )
{
  map<const char*,const functionClass*,ltstr>::const_iterator it1;
  map<const char*,const predicateClass*,ltstr>::const_iterator it2;
  map<const char*,const namedTypeClass*,ltstr>::const_iterator it3;

  if( domainHash.find( ident ) != domainHash.end() )
    {
      error( nameClash, ident );
      return;
    }

  // allocate domain
  declaredDomain = new domainClass( strdup( yyfile ), ident );

  // default hashes
  for( it1 = globalFunctionHash.begin(); it1 != globalFunctionHash.end(); ++it1 )
    declaredDomain->functionHash.insert( make_pair( (*it1).first, new functionClass( *(*it1).second ) ) );

  for( it2 = globalPredicateHash.begin(); it2 != globalPredicateHash.end(); ++it2 )
    declaredDomain->predicateHash.insert( make_pair( (*it2).first, new predicateClass( *(*it2).second ) ) );

  for( it3 = globalNamedTypeHash.begin(); it3 != globalNamedTypeHash.end(); ++it3 )
    if( (*it3).second )
      declaredDomain->namedTypeHash.insert( make_pair((*it3).first,new namedTypeClass(*(*it3).second)) );
    else
      declaredDomain->namedTypeHash.insert( make_pair( (*it3).first, (const namedTypeClass*)NULL ) );

  // setup global hashes
  namedTypeHash = &declaredDomain->namedTypeHash;
  objectHashByType = &declaredDomain->objectHashByType;
  objectHashByName = &declaredDomain->objectHashByName;
  ramificationList = &declaredDomain->ramificationList;
  internalPredicateList = &declaredDomain->internalPredicateList;
  actionList = &declaredDomain->actionList;
  functionHash = &declaredDomain->functionHash;
  predicateHash = &declaredDomain->predicateHash;
  arrayHash = &declaredDomain->arrayHash;
  externalProcedureList = &declaredDomain->externalProcedureList;
}

static const codeChunkClass *
finishDomain( void )
{
  // update model to appropriate
  if( (declaredDomain->model == ND_POMDP2) && (maxNumResStates == 1) )
    declaredDomain->model = ND_POMDP1;

  // save domain in global hash table
  domainHash.insert( make_pair( declaredDomain->ident, declaredDomain ) );

  actionSet.clear();
  ramificationSet.clear();
  internalPredicateSet.clear();

  // cleanning
  namedTypeHash = NULL;
  objectHashByType = NULL;
  objectHashByName = NULL;
  ramificationList = NULL;
  internalPredicateList = NULL;
  actionList = NULL;
  functionHash = NULL;
  predicateHash = NULL;
  arrayHash = NULL;
  externalProcedureList = NULL;
  domainClass *rv = declaredDomain;
  declaredDomain = NULL;
  return( rv );
}

void
cleanDomains( void )
{
  map<const char*,const domainClass*,ltstr>::const_iterator it;

  map<const char*,const functionClass*,ltstr>::const_iterator it1;
  map<const char*,const predicateClass*,ltstr>::const_iterator it2;
  map<const char*,const namedTypeClass*,ltstr>::const_iterator it3;
  map<const char*,list<const char*>*,ltstr>::const_iterator it4;
  map<const char*,const typeClass*,ltstr>::const_iterator it5;
  map<const char*,const arrayClass*,ltstr>::const_iterator it6;
  list<const ramificationClass*>::const_iterator it7;
  list<const internalFunctionClass*>::const_iterator it8;
  list<const internalPredicateClass*>::const_iterator it9;
  list<const actionClass*>::const_iterator it10;

  for( it = domainHash.begin(); it != domainHash.end(); ++it )
    {
      //      fprintf( stderr, "free of [%p]%s\n", ((*it).second->ident), ((*it).second->ident) );
      //      fprintf( stderr, "free of [%p]%s\n", ((*it).second->fileName), ((*it).second->fileName) );
      free( (void*)((*it).second->ident) );
      free( (void*)((*it).second->fileName) );

      for( it1 = (*it).second->functionHash.begin(); it1 != (*it).second->functionHash.end(); ++it1 );

      // clean predicateHash
      for( it2 = (*it).second->predicateHash.begin(); it2 != (*it).second->predicateHash.end(); ++it2 )
	delete (*it2).second;

      // clean namedTypeHash
      for( it3 = (*it).second->namedTypeHash.begin(); it3 != (*it).second->namedTypeHash.end(); ++it3 )
	delete (*it3).second;

      // clean objectHashByType
      for( it4 = (*it).second->objectHashByType.begin(); it4 != (*it).second->objectHashByType.end(); ++it4 )
	{
	  list<const char*>::const_iterator it;
	  //	  fprintf( stderr, "free of [%p]%s\n", (*it4).first, (*it4).first );
	  free( (void*)((*it4).first) );
	  for( it = (*it4).second->begin(); it != (*it4).second->end(); ++it )
	    {
	      //	      fprintf( stderr, "free of [%p]%s\n", (*it), (*it) );
	      free( (void*)(*it) );
	    }
	  delete (*it4).second;
	}

      // clean objectHashByName
      for( it5 = (*it).second->objectHashByName.begin(); it5 != (*it).second->objectHashByName.end(); ++it5 )
	{
	  //	  fprintf( stderr, "free of [%p]%s\n", (*it5).first, (*it5).first );
	  free( (void*)(*it5).first );
	  delete (*it5).second;
	}

      // clean arrayHash
      for( it6 = (*it).second->arrayHash.begin(); it6 != (*it).second->arrayHash.end(); ++it6 )
	{
	  //	  fprintf( stderr, "free of [%p]%s\n", (*it6).first, (*it6).first );
	  free( (void*)(*it6).first );
	  delete (*it6).second;
	}

      // clean ramification
      for( it7 = (*it).second->ramificationList.begin(); it7 != (*it).second->ramificationList.end(); ++it7 )
	delete (*it7);

      // clean internalFunctions
      for( it8 = (*it).second->internalFunctionList.begin(); it8 != (*it).second->internalFunctionList.end(); ++it8 )
	delete (*it8);

      // clean internalPredicates
      for( it9 = (*it).second->internalPredicateList.begin(); it9 != (*it).second->internalPredicateList.end(); ++it9 )
	delete (*it9);

      // clean actions
      for( it10 = (*it).second->actionList.begin(); it10 != (*it).second->actionList.end(); ++it10 )
	delete (*it10);
    }
}

static void
declareModel( void )
{
  assert( declaredDomain != NULL );
  switch( declaredDomain->feedback )
    {
    case COMPLETE:
      switch( declaredDomain->dynamics )
	{
	case DETERMINISTIC:
	case NON_DETERMINISTIC:
	  declaredDomain->model = ND_MDP;
	  break;
	case PROBABILISTIC:
	  declaredDomain->model = MDP;
	  break;
	}
      break;
    case PARTIAL:
      switch( declaredDomain->dynamics )
	{
	case DETERMINISTIC:
	  declaredDomain->model = POMDP1;
	  break;
	case NON_DETERMINISTIC:
	  declaredDomain->model = ND_POMDP2;
	  break;
	case PROBABILISTIC:
	  declaredDomain->model = POMDP2;
	  break;
	}
      break;
    case NULLF:
      switch( declaredDomain->dynamics )
	{
	case DETERMINISTIC:
	case PROBABILISTIC:
	  declaredDomain->model = CONFORMANT2;
	  break;
	case NON_DETERMINISTIC:
	  declaredDomain->model = CONFORMANT1;
	  break;
	}
      break;
    }
}

static void
declareDynamics( int dynamics )
{
  assert( declaredDomain != NULL );
  if( (dynamics != PROBABILISTIC) && (dynamics != NON_DETERMINISTIC) && (dynamics != DETERMINISTIC) )
    error( undefinedModel );
  else
    declaredDomain->dynamics = dynamics;
}

static void
declareFeedback( int feedback )
{
  assert( declaredDomain != NULL );
  if( (feedback != COMPLETE) && (feedback != PARTIAL) && (feedback != NULLF) )
    error( undefinedModel );
  else
    declaredDomain->feedback = feedback;
}

static void
declareExternal( const char* ident )
{
  map<const char*,const functionClass*,ltstr>::iterator it1;
  map<const char*,const predicateClass*,ltstr>::iterator it2;
  it1 = declaredDomain->functionHash.find( ident );
  it2 = declaredDomain->predicateHash.find( ident );

  if( (it1==declaredDomain->functionHash.end()) && (it2==declaredDomain->predicateHash.end()) )
    error( undefinedFunPred, ident );

  if( it1 != declaredDomain->functionHash.end() )
    {
      if( (*it1).second->external == 0 )
	{
	  ((functionClass*)(*it1).second)->external = 1;
	  --declaredDomain->numFunctions[(*it1).second->numArguments];
	}
    }

  if( it2 != declaredDomain->predicateHash.end() )
    {
      if( (*it2).second->external == 0 )
	{
	  ((predicateClass*)(*it2).second)->external = 1;
	  --declaredDomain->numPredicates[(*it2).second->numArguments];
	}
    }

  free( (void*)ident );
}

static void
declareExternal( const list<const char*> *eList )
{
  assert( declaredDomain != NULL );
  list<const char*>::const_iterator it;
  for( it = eList->begin(); it != eList->end(); ++it )
    declareExternal( *it );
  delete eList;
}

static void
declareNamedType( const char *ident, const list<const char*> *aList )
{
  assert( namedTypeHash != NULL );
  if( namedTypeHash->find( ident ) != namedTypeHash->end() )
    {
      error( nameClash, ident );
    }
  else
    {
      namedTypeClass *type = new namedTypeClass( ident, aList );
      namedTypeHash->insert( make_pair( ident, type ) );
    }
}

static void
declareFunction( const char *ident, const typeClass *domain, const typeClass *range )
{
  functionClass *function;

  assert( functionHash != NULL );
  assert( declaredDomain != NULL );

  if( functionHash->find( ident ) != functionHash->end() )
    {
      error( nameClash, ident );
    }
  else
    {
      function = new functionClass( ident, domain, range, domainType );
      functionHash->insert( make_pair( ident, function ) );
      ++declaredDomain->numFunctions[function->numArguments];
    }
}

static void
declarePredicate( const char *ident, const typeClass *domain )
{
  predicateClass *predicate;

  assert( predicateHash != NULL );
  assert( declaredDomain != NULL );

  if( predicateHash->find( ident ) != predicateHash->end() )
    {
      error( nameClash, ident );
    }
  else
    {
      predicate = new predicateClass( ident, domain, domainType );
      predicateHash->insert( make_pair( ident, predicate ) );
      ++declaredDomain->numPredicates[predicate->numArguments];
    }
}

static void
declareProcedure( const char *ident )
{
  assert( externalProcedureList != NULL );
  if( externalProcedureList->find( ident ) != externalProcedureList->end() )
    error( nameClash, ident );
  else
    externalProcedureList->insert( ident );
}

static void
declareSimpleObjects( const char *ident, const list<const char*> *oList )
{
  typeClass *type;
  list<const char*>::const_iterator it1;
  map<const char*,list<const char*>*,ltstr>::const_iterator it;

  assert( objectHashByType != NULL );
  assert( objectHashByName != NULL );

  // classified insertion of objects into domain objects
  it = objectHashByType->find( ident );
  if( it == objectHashByType->end() )
    objectHashByType->insert( make_pair( strdup( ident ), new list<const char*>(*oList) ) );
  else
    {
      for( it1 = oList->begin(); it1 != oList->end(); ++it1 )
	(*it).second->push_back( *it1 );
    }

  // insert objects into hashByName
  type = new simpleTypeClass( ident );
  for( it1 = oList->begin(); it1 != oList->end(); ++it1 )
    {
      if( objectHashByName->find( (*it1) ) != objectHashByName->end() )
	error( nameClash, (*it1) );
      else
	objectHashByName->insert( make_pair( strdup( *it1 ), type->clone() ) );
    }

  // clean 
  delete type;
  delete oList;
}

static void
declareIntegerObjects( const char *min, const char *max, const list<const char*> *oList )
{
  typeClass *type;
  list<const char*>::const_iterator it1;
  map<const char*,list<const char*>*,ltstr>::const_iterator it;

  assert( objectHashByType != NULL );
  assert( objectHashByName != NULL );

  // classified insertion of objects into domain objects
  it = objectHashByType->find( (const char*)":integer" );
  if( it == objectHashByType->end() )
    objectHashByType->insert( make_pair( strdup(":integer"), new list<const char*>(*oList) ) );
  else
    {
      for( it1 = oList->begin(); it1 != oList->end(); ++it1 )
	(*it).second->push_back( *it1 );
    }

  // insert objects into hashByName
  type = new integerTypeClass( min, max );
  for( it1 = oList->begin(); it1 != oList->end(); ++it1 )
    {
      if( objectHashByName->find( (*it1) ) != objectHashByName->end() )
	error( nameClash, (*it1) );
      else
	objectHashByName->insert( make_pair( strdup( *it1 ), type->clone() ) );
    }

  // clean 
  delete type;
  delete oList;
}

static void
declareBooleanObjects( const list<const char*> *oList )
{
  list<const char*>::const_iterator it1;
  map<const char*,list<const char*>*,ltstr>::const_iterator it;

  assert( objectHashByType != NULL );
  assert( objectHashByName != NULL );

  // classified insertion of objects into domain objects
  it = objectHashByType->find( (const char*)":boolean" );
  if( it == objectHashByType->end() )
    objectHashByType->insert( make_pair( strdup(":boolean"), new list<const char*>(*oList) ) );
  else
    {
      for( it1 = oList->begin(); it1 != oList->end(); ++it1 )
	(*it).second->push_back( *it1 );
    }

  // insert objects into hashByName
  for( it1 = oList->begin(); it1 != oList->end(); ++it1 )
    {
      if( objectHashByName->find( (*it1) ) != objectHashByName->end() )
	error( nameClash, (*it1) );
      else
	objectHashByName->insert( make_pair( strdup( *it1 ), theBooleanType->clone() ) );
    }

  // clean 
  delete oList;
}

static void
declareArrayObjects( const char *size, const typeClass *base, const list<const char*> *oList )
{
  int dim;
  typeClass *type;
  arrayClass *array;
  map<const char*,list<const char*>*,ltstr>::const_iterator it;
  list<const char*>::const_iterator it1;
  map<const char*,const arrayClass*,ltstr>::const_iterator it2;

  assert( arrayHash != NULL );
  assert( declaredDomain != NULL );
  assert( objectHashByType != NULL );
  assert( objectHashByName != NULL );

  // classified insertion of objects into domain objects
  it = objectHashByType->find( (const char*)":array" );
  if( it == objectHashByType->end() )
    objectHashByType->insert( make_pair( strdup(":array"), new list<const char*>(*oList) ) );
  else
    {
      for( it1 = oList->begin(); it1 != oList->end(); ++it1 )
	(*it).second->push_back( *it1 );
    }

  // insert objects into hashByName
  type = new arrayTypeClass( size, base );
  for( it1 = oList->begin(); it1 != oList->end(); ++it1 )
    {
      if( objectHashByName->find( (*it1) ) != objectHashByName->end() )
	error( nameClash, (*it1) );
      else
	objectHashByName->insert( make_pair( strdup( *it1 ), type->clone() ) );
    }

  // declare and insert new array into arrayHash
  for( it1 = oList->begin(); it1 != oList->end(); ++it1 )
    {
      it2 = arrayHash->find( (*it1) );
      if( it2 == arrayHash->end() )
	{
	  array = new arrayClass( strdup( (*it1) ), strdup(size), base->clone() );
	  arrayHash->insert( make_pair( strdup( (*it1) ), array ) );
	  if( declaredProblem != NULL )
	    declaredProblem->numArrays++;
	  else
	    declaredDomain->numArrays++;
	}
    }

  // update maxArraySize
  dim = atoi( size );
  if( declaredProblem != NULL )
    declaredProblem->maxArraySize = (declaredProblem->maxArraySize>dim?declaredProblem->maxArraySize:dim);
  else
    declaredDomain->maxArraySize = (declaredDomain->maxArraySize>dim?declaredDomain->maxArraySize:dim);

  // clean 
  delete type;
  delete oList;
}

static void
declareVariable( const char *ident, const typeClass *type )
{
  if( variableEnvironment.front()->find( ident ) == variableEnvironment.front()->end() )
    variableEnvironment.front()->insert( make_pair( ident, type ) );
  else
    error( nameClash, ident );
}

static void
startRamification( const char *ident )
{
  currentRamification = ident;
  if( ramificationSet.find( ident ) != ramificationSet.end() )
    error( nameClash, ident );
}

static void
declareRamification( const formulaClass *formula )
{
  ramificationClass *ram = new formulaRamificationClass( currentRamification, parameterList, formula );
  ramificationSet.insert( currentRamification );
  ramificationList->push_back( ram );
  cleanEnvironment( variableEnvironment.front() );
  variableEnvironment.pop_front();
  parameterList.clear();
  currentRamification = NULL;
}

static void
declareRamification( const effectClass *effect )
{
  ramificationClass *ram = new effectRamificationClass( currentRamification, parameterList, effect );
  ramificationSet.insert( currentRamification );
  ramificationList->push_back( ram );
  cleanEnvironment( variableEnvironment.front() );
  variableEnvironment.pop_front();
  parameterList.clear();
  currentRamification = NULL;

  ram->dirtyPredicates.insert( ramDirtyPredicates.begin(), ramDirtyPredicates.end() );
  ramDirtyPredicates.clear();
  ram->dirtyFunctions.insert( ramDirtyFunctions.begin(), ramDirtyFunctions.end() );
  ramDirtyFunctions.clear();
}

static void
startLogicalDef( const char *ident )
{
  if( internalPredicateSet.find( ident ) != internalPredicateSet.end() )
    error( nameClash, ident );
  else
    {
      list<pair<const char*,const typeClass*> >::const_iterator it;
      list<const typeClass*> *domain = new list<const typeClass*>;

      // create the type for the domain of the new predicate
      for( it = parameterList.begin(); it != parameterList.end(); ++it )
	domain->push_back( (*it).second->clone() );

      // create the entry in the corresponding hash table
      predicateClass *predicate = new predicateClass( strdup(ident), new typeListClass( domain ), 
						      predicateClass::LIST_DOMAIN );
      predicate->internal = 1;
      predicateHash->insert( make_pair( ident, predicate ) );
    }
}

static void
declareLogicalDef( const char *ident, const formulaClass *formula )
{
  internalPredicateClass *pred = new internalPredicateClass( ident, parameterList, formula );
  internalPredicateSet.insert( ident );
  internalPredicateList->push_back( pred );
  cleanEnvironment( variableEnvironment.front() );
  variableEnvironment.pop_front();
  parameterList.clear();
}

static void
startAction( const char *ident )
{
  actionClass *action;

  if( actionSet.find( ident ) != actionSet.end() )
    error( nameClash, ident );
  else
    {
      assert( actionList != NULL );
      action = new actionClass( ident );
      actionList->push_back( action );
      declaredAction = action;
    }
}

static void
finishAction( void )
{
  //xxxx
  maxNumResStates = MAX(maxNumResStates,declaredAction->numResultingStates);
  declaredAction->parameters.insert( declaredAction->parameters.end(), 
				     parameterList.begin(), parameterList.end() );
  cleanEnvironment( variableEnvironment.front() );
  variableEnvironment.pop_front();
  assert( variableEnvironment.empty() );
  parameterList.clear();
  declaredAction = NULL;
}

static void
declareActionPrecondition( const formulaClass *precondition )
{
  assert( declaredAction != NULL );
  declaredAction->precondition = precondition;
}

static void
declareActionEffect( const effectClass *effect )
{
  assert( declaredAction != NULL );
  declaredAction->effect = effect;
}

static void
declareActionCost( const costClass *cost )
{
  assert( declaredAction != NULL );
  declaredAction->cost = cost;
}

static void
declareActionObservation( const observationClass *observation )
{
  assert( declaredDomain != NULL );
  assert( declaredAction != NULL );
  declaredAction->observation = observation;
}

static termClass *
fetchVariableTerm( const char *ident, termClass *subscript )
{
  termClass *result = NULL;
  list<map<const char*,const typeClass*,ltstr>*>::const_iterator it;
  map<const char*,const typeClass*,ltstr>::const_iterator it2;

  // in this implementation subscript is ALWAYS NULL
  assert( subscript == NULL );

  // fetch variable
  for( it = variableEnvironment.begin(); it != variableEnvironment.end(); ++it )
    {
      it2 = (*it)->find( ident );
      if( it2 != (*it)->end() )
	{
	  result = new variableTermClass( ident, (*it2).second->clone() );
	  break;
	}
    }

  // check for error
  if( it == variableEnvironment.end() )
    {
      error( undefinedVariable, ident );
      result = new universalTermClass();
    }

  // return value
  return( result );
}

static termClass *
fetchObjectTerm( const char *ident, const termClass *subscript )
{
  termClass *rv;
  list<const char*>::const_iterator it;
  map<const char*,const typeClass*,ltstr>::const_iterator it1;
  map<const char*,list<const char*>*,ltstr>::const_iterator it2;

  assert( objectHashByName != NULL );

  // get object type
  it1 = objectHashByName->find( ident );
  if( it1 == objectHashByName->end() )
    {
      error( undefinedObject, ident );
      rv = new universalTermClass();
      delete subscript;
    }
  else
    {
      // check if it is an array
      it2 = objectHashByType->find( (const char*)":array" );
      if( it2 != objectHashByType->end() )
	for( it = (*it2).second->begin(); it != (*it2).second->end(); ++it )
	  if( !strcmp( ident, (*it) ) )
	    break;

      // check for invalid susbcript
      if( (it2 == objectHashByType->end()) || (it == (*it2).second->end()) )
	{
	  if( subscript != NULL )
	    {
	      error( invalidSubscript, ident );
	      rv = new universalTermClass();
	    }
	  else
	    {
	      // simple object 
	      rv = new objectTermClass( ident, (*it1).second->clone() );
	    }
	  delete subscript;
	}
      else
	{
	  // we have an array either without subscript or with subscript
	  rv = new arrayTermClass( ident, (const arrayTypeClass*)(*it1).second->clone(), subscript );
	}
    }

  // return value
  return( rv );
}

static void
setVariableDenotationFor( const char *ident )
{
  if( declaredDomain && 
      (declaredDomain->varDenotation.find( ident ) == declaredDomain->varDenotation.end()) )
    {
      pair<const char*,int> p( strdup( ident ), declaredDomain->varDenotation.size() );
      declaredDomain->varDenotation.insert( p );
    }
  if( declaredProblem && 
      (declaredProblem->varDenotation.find( ident ) == declaredProblem->varDenotation.end()) )
    {
      pair<const char*,int> p( strdup( ident ), declaredProblem->varDenotation.size() );
      declaredProblem->varDenotation.insert( p );
    }
}

static bool
checkProbabilities( const probabilisticEffectClass *effect )
{
  list<pair<const char*,const effectClass*>*>::const_iterator it;

  float prob = 0.0;
  for( it = effect->effectList->begin(); it != effect->effectList->end(); ++it )
    prob += atof( (*it)->first );

#if linux
  prob = (float)((unsigned)(1000.0*prob+0.5))/1000.0;
#endif

  if( prob > 1.0 ) error( probabilitySum );
  if( prob != 1.0 ) warning( probabilitySumWarning, prob );
  return( prob == 1.0 );
}

static void
checkProbabilities( const list<pair<const char*,const observationListClass*>*> *obsList )
{
  list<pair<const char*,const observationListClass*>*>::const_iterator it;

  float prob = 0.0;
  for( it = obsList->begin(); it != obsList->end(); ++it )
    prob += atof( (*it)->first );
  if( prob != 1.0 ) error( probabilitySum );
}

static void
startProblem( const char *problemIdent, const char *domainIdent )
{
  map<const char*,const domainClass*,ltstr>::const_iterator it;

  it = domainHash.find( domainIdent );
  if( it == domainHash.end() )
    {
      // this is a serious error, parsing can't continue.
      // Report it, printErrors on stderr, and exit.
      // this should be improved.
      error( undefinedDomain, domainIdent );
      printErrors( stderr );
      exit( -1 );
    }
  free( (void*)domainIdent );

  if( problemSet.find( problemIdent ) != problemSet.end() )
    error( nameClash, problemIdent );

  // allocate problem
  declaredProblem = new problemClass( strdup( yyfile ), problemIdent, (*it).second );

  // setup global hashes
  namedTypeHash = &declaredProblem->namedTypeHash;
  objectHashByType = &declaredProblem->objectHashByType;
  objectHashByName = &declaredProblem->objectHashByName;
  ramificationList = (list<const ramificationClass*>*)&declaredProblem->domain->ramificationList;
  internalPredicateList = (list<const internalPredicateClass*>*)&declaredProblem->domain->internalPredicateList;
  actionList = (list<const actionClass*>*)&declaredProblem->domain->actionList;
  functionHash = (map<const char*,const functionClass*,ltstr>*)&declaredProblem->domain->functionHash;
  predicateHash = (map<const char*,const predicateClass*,ltstr>*)&declaredProblem->domain->predicateHash;
  arrayHash = &declaredProblem->arrayHash;
}

static const codeChunkClass *
finishProblem( void )
{
  // save domain in global hash table
  problemSet.insert( make_pair( strdup( declaredProblem->ident ), 
				strdup( declaredProblem->domain->ident ) ) );

  actionSet.clear();
  ramificationSet.clear();
  internalPredicateSet.clear();

  // cleanning
  namedTypeHash = NULL;
  objectHashByType = NULL;
  objectHashByName = NULL;
  ramificationList = NULL;
  internalPredicateList = NULL;
  actionList = NULL;
  functionHash = NULL;
  predicateHash = NULL;
  arrayHash = NULL;
  problemClass *rv = declaredProblem;
  declaredProblem = NULL;
  return( rv );
}

static void
declareInit( const effectListClass *effect )
{
  assert( declaredProblem != NULL );
  declaredProblem->initEffect = effect;
}

static void
declareGoal( const formulaClass *formula )
{
  assert( declaredProblem != NULL );
  declaredProblem->goalFormula = formula;
}

static void
declareHook( const hookClass *hook )
{
  assert( declaredProblem != NULL );
  declaredProblem->hookType |= hook->hookType;
  switch( hook->hookType )
    {
    case problemClass::MODEL_HOOK:
      declaredProblem->modelHook = hook;
      break;
    case problemClass::BELIEF_HOOK:
      declaredProblem->beliefHook = hook;
      break;
    case problemClass::HEURISTIC_HOOK:
      declaredProblem->heuristicHook = hook;
      break;
    }
}

static void
cleanEnvironment( map<const char*,const typeClass*,ltstr> *env )
{
  map<const char*,const typeClass*,ltstr>::iterator it;

  for( it = env->begin(); it != env->end(); ++it )
    {
      //      fprintf( stderr, "free of [%p]%s\n", (*it).first, (*it).first );
      free( (void*)(*it).first );
      delete (*it).second;
    }
  delete env;
}

static void
printEnvironment( void )
{
  list<map<const char*,const typeClass*,ltstr>*>::const_iterator it;
  map<const char*,const typeClass*,ltstr>::const_iterator it2;
  for( it = variableEnvironment.begin(); it != variableEnvironment.end(); ++it )
    {
      for( it2 = (*it)->begin(); it2 != (*it)->end(); ++it2 )
	cout << "variable = " << (*it2).first << ", type = " << typeid( (*it2).second ).name() << endl;
    }
}

static list<map<const char*,const typeClass*,ltstr>*> *
environmentClone( void )
{
  list<map<const char*,const typeClass*,ltstr>*> *result;
  list<map<const char*,const typeClass*,ltstr>*>::const_iterator it;
  map<const char*,const typeClass*,ltstr> *m;
  map<const char*,const typeClass*,ltstr>::const_iterator it2;

  result = new list<map<const char*,const typeClass*,ltstr>*>;
  for( it = variableEnvironment.begin(); it != variableEnvironment.end(); ++it )
    if( (*it)->size() > 0 )
      {
	m = new map<const char*,const typeClass*,ltstr>;
	for( it2 = (*it)->begin(); it2 != (*it)->end(); ++it2 )
	  m->insert( make_pair( strdup( (*it2).first ), (*it2).second->clone() ) );
	result->push_back( m );
      }

  return( result );
}
#line 1882 "y.tab.c"
#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
#ifdef __cplusplus
extern "C" { 
char * getenv(const char*);
int yylex();
int yyparse();
}

#endif
int
#if defined(__STDC__)
yyparse(void)
#else
yyparse()
#endif
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register char *yys;
#ifndef __cplusplus
    extern char *getenv(const char*);
#endif

    if (yys = getenv("YYDEBUG"))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if ((yyn = yydefred[yystate]) != 0) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yyss + yystacksize - 1)
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yyss + yystacksize - 1)
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 1:
#line 348 "daeParser.y"
{
			 globalChunk = yyvsp[0].codeChunkList;
		       }
break;
case 2:
#line 354 "daeParser.y"
{
			 yyval.codeChunkList = yyvsp[-1].codeChunkList;
			 yyval.codeChunkList->push_back( yyvsp[0].codeChunk );
		       }
break;
case 3:
#line 359 "daeParser.y"
{
			 yyval.codeChunkList = yyvsp[-1].codeChunkList;
			 yyval.codeChunkList->push_back( yyvsp[0].codeChunk );
		       }
break;
case 4:
#line 364 "daeParser.y"
{
			 yyval.codeChunkList = new list<const codeChunkClass*>;
		       }
break;
case 5:
#line 370 "daeParser.y"
{
			 startDomain( yyvsp[-1].ident );
		       }
break;
case 6:
#line 374 "daeParser.y"
{
			 yyval.codeChunk = finishDomain();
		       }
break;
case 9:
#line 384 "daeParser.y"
{
			 declareModel();
		       }
break;
case 21:
#line 405 "daeParser.y"
{
			 declareDynamics( DETERMINISTIC );
		       }
break;
case 22:
#line 409 "daeParser.y"
{
			 declareDynamics( NON_DETERMINISTIC );
		       }
break;
case 23:
#line 413 "daeParser.y"
{
			 declareDynamics( PROBABILISTIC );
		       }
break;
case 24:
#line 419 "daeParser.y"
{
			 declareFeedback( COMPLETE );
		       }
break;
case 25:
#line 423 "daeParser.y"
{
			 declareFeedback( PARTIAL );
		       }
break;
case 26:
#line 427 "daeParser.y"
{
			 declareFeedback( NULLF );
		       }
break;
case 29:
#line 437 "daeParser.y"
{
			 startPackageParse( yyvsp[-1].ident );
		       }
break;
case 31:
#line 444 "daeParser.y"
{
			 finishPackageParse();
		       }
break;
case 34:
#line 454 "daeParser.y"
{
			 yyvsp[0].identList->push_front( yyvsp[-1].ident );
			 declareNamedType( strdup( yyvsp[-1].ident ), yyvsp[0].identList );
		       }
break;
case 35:
#line 459 "daeParser.y"
{
			 list<const char*> *aList = new list<const char*>;
			 aList->push_front( yyvsp[0].ident );
			 declareNamedType( strdup( yyvsp[0].ident ), aList );
		       }
break;
case 36:
#line 467 "daeParser.y"
{
			 yyval.identList = yyvsp[-1].identList;
			 yyval.identList->push_back( yyvsp[0].ident );
		       }
break;
case 37:
#line 472 "daeParser.y"
{
			 yyval.identList = new list<const char*>;
			 yyval.identList->push_back( yyvsp[0].ident );
		       }
break;
case 38:
#line 479 "daeParser.y"
{
			 yyval.ident = yyvsp[0].ident;
		       }
break;
case 41:
#line 489 "daeParser.y"
{
			 declareFunction( yyvsp[-3].ident, yyvsp[-2].type, yyvsp[-1].type );
		       }
break;
case 44:
#line 499 "daeParser.y"
{
			 domainType = predicateClass::LIST_DOMAIN;
			 declarePredicate( yyvsp[-2].ident, new typeListClass( yyvsp[-1].typeList ) );
		       }
break;
case 45:
#line 506 "daeParser.y"
{
			 domainType = functionClass::SIMPLE_DOMAIN;
			 yyval.type = yyvsp[0].type;
		       }
break;
case 46:
#line 511 "daeParser.y"
{
			 domainType = functionClass::LIST_DOMAIN;
			 yyval.type = new typeListClass( yyvsp[-1].typeList );
		       }
break;
case 47:
#line 516 "daeParser.y"
{
			 /* xxxxxx: array in function range */
			 /* xxxxxx: not supported*/
			 domainType = functionClass::ARRAY_DOMAIN;
			 assert( 0 );
		       }
break;
case 48:
#line 525 "daeParser.y"
{
			 yyval.type = new simpleTypeClass( yyvsp[0].ident );
		       }
break;
case 49:
#line 529 "daeParser.y"
{
			 yyval.type = new integerTypeClass( yyvsp[0].integer.min, yyvsp[0].integer.max );
		       }
break;
case 50:
#line 533 "daeParser.y"
{
			 yyval.type = new booleanTypeClass();
		       }
break;
case 51:
#line 539 "daeParser.y"
{
			 yyval.integer = yyvsp[0].integer;
		       }
break;
case 52:
#line 545 "daeParser.y"
{
			 yyval.integer.min = yyvsp[-3].ident;
			 yyval.integer.max = yyvsp[-1].ident;
		       }
break;
case 54:
#line 556 "daeParser.y"
{
			 yyval.typeList = yyvsp[-1].typeList;
			 yyval.typeList->push_back( yyvsp[0].type );
		       }
break;
case 55:
#line 561 "daeParser.y"
{
			 yyval.typeList = new list<const typeClass*>;
			 yyval.typeList->push_back( yyvsp[0].type );
		       }
break;
case 58:
#line 572 "daeParser.y"
{
			 declareFunction( yyvsp[-3].ident, yyvsp[-2].type, yyvsp[-1].type );
			 declareExternal( strdup(yyvsp[-3].ident) );
		       }
break;
case 59:
#line 577 "daeParser.y"
{
			 domainType = predicateClass::LIST_DOMAIN;
			 declarePredicate( yyvsp[-2].ident, new typeListClass( yyvsp[-1].typeList ) );
			 declareExternal( strdup(yyvsp[-2].ident) );
                       }
break;
case 60:
#line 583 "daeParser.y"
{
			 declareProcedure( yyvsp[-1].ident );
		       }
break;
case 63:
#line 593 "daeParser.y"
{
			 declareSimpleObjects( yyvsp[0].ident, yyvsp[-2].identList );
		       }
break;
case 64:
#line 597 "daeParser.y"
{
			 declareIntegerObjects( yyvsp[0].integer.min, yyvsp[0].integer.max, yyvsp[-2].identList );
                       }
break;
case 65:
#line 601 "daeParser.y"
{
			 declareBooleanObjects( yyvsp[-2].identList );
                       }
break;
case 66:
#line 605 "daeParser.y"
{
			 declareArrayObjects( yyvsp[-2].ident, yyvsp[0].type, yyvsp[-6].identList );
                       }
break;
case 67:
#line 611 "daeParser.y"
{
			 yyval.identList = yyvsp[-1].identList;
			 yyval.identList->push_back( yyvsp[0].ident );
		       }
break;
case 68:
#line 616 "daeParser.y"
{
			 yyval.identList = new list<const char*>;
			 yyval.identList->push_back( yyvsp[0].ident );
		       }
break;
case 72:
#line 630 "daeParser.y"
{
			 variableEnvironment.push_front( new map<const char*,const typeClass*,ltstr> );
		       }
break;
case 73:
#line 634 "daeParser.y"
{
			 currInternalPredicate = yyvsp[-2].ident;
			 startLogicalDef( yyvsp[-2].ident );
		       }
break;
case 74:
#line 639 "daeParser.y"
{
			 currInternalPredicate = NULL;
			 declareLogicalDef( yyvsp[-6].ident, yyvsp[-1].formula );
		       }
break;
case 77:
#line 650 "daeParser.y"
{
			 startRamification( yyvsp[0].ident );
			 variableEnvironment.push_front( new map<const char*,const typeClass*,ltstr> );
		       }
break;
case 79:
#line 659 "daeParser.y"
{
			 declareRamification( yyvsp[-1].formula );
		       }
break;
case 80:
#line 663 "daeParser.y"
{
			 declareRamification( new effectListClass( yyvsp[-1].effectList ) );
		       }
break;
case 85:
#line 678 "daeParser.y"
{
			 list<const char*>::const_iterator it;
			 for( it = yyvsp[-2].identList->begin(); it != yyvsp[-2].identList->end(); ++it )
			   {
			     declareVariable( *it, yyvsp[0].type->clone() );
			     parameterList.push_back( make_pair( strdup(*it), yyvsp[0].type->clone() ) );
			   }
			 delete yyvsp[-2].identList;
			 delete yyvsp[0].type;
		       }
break;
case 86:
#line 691 "daeParser.y"
{
			 yyval.identList = yyvsp[-1].identList;
			 yyval.identList->push_back( yyvsp[0].ident );
		       }
break;
case 87:
#line 696 "daeParser.y"
{
			 yyval.identList = new list<const char*>;
			 yyval.identList->push_back( yyvsp[0].ident );
		       }
break;
case 90:
#line 707 "daeParser.y"
{
			 startAction( yyvsp[0].ident );
			 variableEnvironment.push_front( new map<const char*,const typeClass*,ltstr> );
		       }
break;
case 91:
#line 712 "daeParser.y"
{
			 finishAction();
		       }
break;
case 96:
#line 726 "daeParser.y"
{
			 declareActionPrecondition( yyvsp[0].formula );
		       }
break;
case 97:
#line 730 "daeParser.y"
{
			 insideEffect = true;
		       }
break;
case 98:
#line 734 "daeParser.y"
{
			 insideEffect = false;
			 declareActionEffect( yyvsp[0].effect );
		       }
break;
case 99:
#line 739 "daeParser.y"
{
			 declareActionCost( yyvsp[0].cost );
			 if( declaredDomain->model == PLANNING )
			   warning( featureInModelWarning, ":cost" );
		       }
break;
case 100:
#line 745 "daeParser.y"
{
			 declareActionObservation( yyvsp[0].observation );
			 if( (declaredDomain->model != ND_POMDP1) &&
			     (declaredDomain->model != ND_POMDP2) &&
			     (declaredDomain->model != POMDP1) &&
			     (declaredDomain->model != POMDP2) )
			   error( featureInModel, declaredDomain->model );
		       }
break;
case 103:
#line 761 "daeParser.y"
{
			 yyval.formula = new notFormulaClass( yyvsp[-1].formula );
		       }
break;
case 104:
#line 765 "daeParser.y"
{
			 yyval.formula = new andFormulaClass( yyvsp[-1].formulaList );
		       }
break;
case 105:
#line 769 "daeParser.y"
{
			 yyval.formula = new orFormulaClass( yyvsp[-1].formulaList );
		       }
break;
case 106:
#line 773 "daeParser.y"
{
			 yyval.formula = new ifFormulaClass( yyvsp[-2].formula, yyvsp[-1].formula );
		       }
break;
case 107:
#line 777 "daeParser.y"
{
			 yyval.formula = new iffFormulaClass( yyvsp[-2].formula, yyvsp[-1].formula );
		       }
break;
case 108:
#line 781 "daeParser.y"
{
			 /* if variable already bounded, declare error*/
			 list<map<const char*,const typeClass*,ltstr>*>::const_iterator it;
			 for( it = variableEnvironment.begin(); it != variableEnvironment.end(); ++it )
			   if( (*it)->find( yyvsp[-3].ident ) != (*it)->end() )
			     error( nameClash, yyvsp[-3].ident );

			 /* extend current environment*/
			 variableEnvironment.push_front( new map<const char*,const typeClass*,ltstr> );
			 declareVariable( strdup(yyvsp[-3].ident), new simpleTypeClass( strdup(yyvsp[-1].ident) ) );
		       }
break;
case 109:
#line 793 "daeParser.y"
{
			 yyval.formula = new existsFormulaClass( yyvsp[-6].ident, new simpleTypeClass(yyvsp[-4].ident), yyvsp[-1].formula, environmentClone(), currInternalPredicate, insideEffect, yyvsp[-3].boolean );
			 cleanEnvironment( variableEnvironment.front() );
			 variableEnvironment.pop_front();
		       }
break;
case 110:
#line 799 "daeParser.y"
{
			 /* if variable already bounded, declare error*/
			 list<map<const char*,const typeClass*,ltstr>*>::const_iterator it;
			 for( it = variableEnvironment.begin(); it != variableEnvironment.end(); ++it )
			   if( (*it)->find( yyvsp[-3].ident ) != (*it)->end() )
			     error( nameClash, yyvsp[-3].ident );

			 /* extend current environment*/
			 variableEnvironment.push_front( new map<const char*,const typeClass*,ltstr> );
			 declareVariable( strdup(yyvsp[-3].ident), new simpleTypeClass( strdup(yyvsp[-1].ident) ) );
		       }
break;
case 111:
#line 811 "daeParser.y"
{
			 yyval.formula = new forallFormulaClass( yyvsp[-6].ident, new simpleTypeClass(yyvsp[-4].ident), yyvsp[-1].formula, environmentClone(), currInternalPredicate, insideEffect, yyvsp[-3].boolean );
			 cleanEnvironment( variableEnvironment.front() );
			 variableEnvironment.pop_front();
		       }
break;
case 112:
#line 819 "daeParser.y"
{
			 yyval.boolean = true;
		       }
break;
case 113:
#line 823 "daeParser.y"
{
			 yyval.boolean = false;
		       }
break;
case 114:
#line 829 "daeParser.y"
{
			 yyval.formulaList = yyvsp[-1].formulaList;
			 yyval.formulaList->push_back( yyvsp[0].formula );
		       }
break;
case 115:
#line 834 "daeParser.y"
{
			 yyval.formulaList = new list<const formulaClass*>;
			 yyval.formulaList->push_back( yyvsp[0].formula );
		       }
break;
case 116:
#line 850 "daeParser.y"
{
			 yyval.formula = new atomFormulaClass( yyvsp[-2].ident, new termListClass( yyvsp[-1].termList ) );
		       }
break;
case 117:
#line 854 "daeParser.y"
{
			 yyval.formula = new equalFormulaClass( yyvsp[-2].term, yyvsp[-1].term );
		       }
break;
case 118:
#line 858 "daeParser.y"
{
			 yyval.formula = new inclusionFormulaClass( yyvsp[-4].term, yyvsp[-2].termList );
		       }
break;
case 125:
#line 875 "daeParser.y"
{
			 yyval.termList = yyvsp[-1].termList;
			 yyval.termList->push_back( yyvsp[0].term );
		       }
break;
case 126:
#line 880 "daeParser.y"
{
			 yyval.termList = new list<const termClass*>;
		       }
break;
case 127:
#line 886 "daeParser.y"
{
			 yyval.term = fetchVariableTerm( yyvsp[0].ident, NULL );
		       }
break;
case 128:
#line 890 "daeParser.y"
{
			 yyval.term = fetchObjectTerm( yyvsp[-1].ident, yyvsp[0].term );
		       }
break;
case 130:
#line 895 "daeParser.y"
{
			 yyval.term = new functionTermClass( yyvsp[-2].ident, new termListClass( yyvsp[-1].termList ) );
		       }
break;
case 131:
#line 899 "daeParser.y"
{
			 yyval.term = new functionTermClass( yyvsp[-2].sfunction, new termListClass( yyvsp[-1].termList ) );
		       }
break;
case 132:
#line 903 "daeParser.y"
{
			 if( !insideEffect )
			   error( badStarTerm );
			 yyval.term = new starTermClass( yyvsp[0].term, insideEffect );
                       }
break;
case 133:
#line 909 "daeParser.y"
{
			 /* if variable already bounded, declare error*/
			 list<map<const char*,const typeClass*,ltstr>*>::const_iterator it;
			 for( it = variableEnvironment.begin(); it != variableEnvironment.end(); ++it )
			   if( (*it)->find( yyvsp[-3].ident ) != (*it)->end() )
			     error( nameClash, yyvsp[-3].ident );

			 /* extend current environment*/
			 variableEnvironment.push_front( new map<const char*,const typeClass*,ltstr> );
			 declareVariable( strdup(yyvsp[-3].ident), new simpleTypeClass( strdup(yyvsp[-1].ident) ) );
		       }
break;
case 134:
#line 921 "daeParser.y"
{
			 yyval.term = new sumTermClass(yyvsp[-6].ident,new simpleTypeClass(yyvsp[-4].ident),yyvsp[-1].term,environmentClone(),insideEffect,yyvsp[-3].boolean);
			 cleanEnvironment( variableEnvironment.front() );
			 variableEnvironment.pop_front();
		       }
break;
case 135:
#line 927 "daeParser.y"
{
			 yyval.term = new conditionalTermClass( yyvsp[-3].formula, yyvsp[-2].term, yyvsp[-1].term );
                       }
break;
case 136:
#line 931 "daeParser.y"
{
			 yyval.term = new formulaTermClass( yyvsp[-1].formula );
                       }
break;
case 137:
#line 938 "daeParser.y"
{
			 yyval.term = yyvsp[-1].term;
		       }
break;
case 138:
#line 942 "daeParser.y"
{
			 yyval.term = NULL;
		       }
break;
case 139:
#line 948 "daeParser.y"
{
			 yyval.term = new integerTermClass( yyvsp[0].ident );
		       }
break;
case 140:
#line 952 "daeParser.y"
{
			 yyval.term = new booleanTermClass( yyvsp[0].ident );
		       }
break;
case 141:
#line 959 "daeParser.y"
{
			 list<const termClass*> *extra = new list<const termClass*>;
			 extra->push_back( new integerTermClass( yyvsp[0].ident ) );
			 yyval.sfunction = new specialFunctionClass( strdup("_plus"), 
                                                        plusFunctionDomain->clone(), 
                                                        plusFunctionRange->clone(),
							new termListClass( extra ) );
		       }
break;
case 142:
#line 968 "daeParser.y"
{
			 list<const termClass*> *extra = new list<const termClass*>;
			 extra->push_back( new integerTermClass( yyvsp[0].ident ) );
			 yyval.sfunction = new specialFunctionClass( strdup("_minus"), 
                                                        minusFunctionDomain->clone(), 
                                                        minusFunctionRange->clone(),
							new termListClass( extra ) );
		       }
break;
case 143:
#line 979 "daeParser.y"
{
			 yyval.ident = yyvsp[-1].ident;
		       }
break;
case 144:
#line 983 "daeParser.y"
{
			 yyval.ident = strdup("-1");
		       }
break;
case 145:
#line 989 "daeParser.y"
{
			 yyval.effect = new effectListClass( yyvsp[0].effectList );
		       }
break;
case 146:
#line 993 "daeParser.y"
{
			 probabilisticEffectClass *result = new probabilisticEffectClass( yyvsp[-1].probEffectList );
			 yyval.effect = result;
			 declaredAction->numResultingStates = yyvsp[-1].probEffectList->size();
			 if( !checkProbabilities( result ) )
			   ++declaredAction->numResultingStates;
			 if( (declaredDomain->model != MDP) &&
			     (declaredDomain->model != POMDP2) &&
			     (declaredDomain->model != CONFORMANT2) )
			   error( featureInModel, declaredDomain->model );
		       }
break;
case 147:
#line 1005 "daeParser.y"
{
			 yyval.effect = new nonDeterministicEffectClass( yyvsp[-1].effectList );
			 declaredAction->numResultingStates = yyvsp[-1].effectList->size();
			 if( (declaredDomain->model != ND_MDP) &&
			     (declaredDomain->model != ND_POMDP2) &&
			     (declaredDomain->model != CONFORMANT1) )
			   error( featureInModel, declaredDomain->model );
		       }
break;
case 148:
#line 1017 "daeParser.y"
{
			 yyval.effectList = yyvsp[-1].effectList;
			 yyval.effectList->push_back( yyvsp[0].effect );
		       }
break;
case 149:
#line 1022 "daeParser.y"
{
			 yyval.effectList = new list<const effectClass*>;
			 yyval.effectList->push_back( yyvsp[0].effect );
		       }
break;
case 151:
#line 1030 "daeParser.y"
{
			 yyval.effect = new whenEffectClass( yyvsp[-2].formula, new effectListClass( yyvsp[-1].effectList ) );
		       }
break;
case 152:
#line 1034 "daeParser.y"
{
			 /* if variable already bounded, declare error*/
			 list<map<const char*,const typeClass*,ltstr>*>::const_iterator it;
			 for( it = variableEnvironment.begin(); it != variableEnvironment.end(); ++it )
			   if( (*it)->find( yyvsp[-2].ident ) != (*it)->end() )
			     error( nameClash, yyvsp[-2].ident );

			 /* extend current environment*/
			 variableEnvironment.push_front( new map<const char*,const typeClass*,ltstr> );
			 declareVariable( strdup(yyvsp[-2].ident), new simpleTypeClass( strdup(yyvsp[0].ident) ) );
		       }
break;
case 153:
#line 1046 "daeParser.y"
{
			 yyval.effect = new forEachEffectClass(yyvsp[-5].ident,new simpleTypeClass(yyvsp[-3].ident),new effectListClass(yyvsp[-1].effectList));
			 cleanEnvironment( variableEnvironment.front() );
			 variableEnvironment.pop_front();
		       }
break;
case 154:
#line 1054 "daeParser.y"
{
			 yyval.effectList = yyvsp[-1].effectList;
			 yyval.effectList->push_back( yyvsp[0].effect );
		       }
break;
case 155:
#line 1059 "daeParser.y"
{
			 yyval.effectList = new list<const effectClass*>;
			 yyval.effectList->push_back( yyvsp[0].effect );
		       }
break;
case 156:
#line 1066 "daeParser.y"
{
			 yyval.effect = new termSetEffectClass( yyvsp[-2].term, yyvsp[-1].term );

			 /*
			 ** to get information about dirty functions, we use RTTI.
			 ** I don't like that but now it seems a good reason for it ..
			 */
			 const functionTermClass *fun = dynamic_cast<const functionTermClass*>(yyvsp[-2].term);
			 if( fun != NULL )
			   {
			     if( declaredAction )
			       declaredAction->dirtyFunctions.insert( strdup(fun->function->ident) );
			     if( currentRamification )
			       ramDirtyFunctions.insert( strdup(fun->function->ident) );
			   }

			 /*
			 ** similar for detecting objects with changing denotation
			 */
			 const objectTermClass *obj = dynamic_cast<const objectTermClass*>(yyvsp[-2].term);
			 if( obj != NULL )
			   setVariableDenotationFor( obj->ident );
			 const variableTermClass *var = dynamic_cast<const variableTermClass*>(yyvsp[-2].term);
			 if( var != NULL )
			   error( invalidLValue );
		       }
break;
case 157:
#line 1093 "daeParser.y"
{
			 if( declaredAction ) declaredAction->dirtyPredicates.insert( strdup(yyvsp[-4].ident) );
			 if( currentRamification ) ramDirtyPredicates.insert( strdup(yyvsp[-4].ident) );
			 yyval.effect = new predicateSetEffectClass( yyvsp[-4].ident, new termListClass( yyvsp[-3].termList ), yyvsp[-1].term );
		       }
break;
case 158:
#line 1099 "daeParser.y"
{
			 if( declaredAction ) declaredAction->dirtyPredicates.insert( strdup(yyvsp[-4].ident) );
			 if( currentRamification ) ramDirtyPredicates.insert( strdup(yyvsp[-4].ident) );
			 yyval.effect = new predicateSetEffectClass( yyvsp[-4].ident, new termListClass( yyvsp[-3].termList ), yyvsp[-1].formula );
		       }
break;
case 159:
#line 1105 "daeParser.y"
{
			 yyval.effect = new printEffectClass( yyvsp[-1].term );
		       }
break;
case 160:
#line 1109 "daeParser.y"
{
			 yyval.effect = new printEffectClass( yyvsp[-1].formula );
		       }
break;
case 161:
#line 1113 "daeParser.y"
{
			 yyval.effect = new printStateEffectClass();
		       }
break;
case 162:
#line 1117 "daeParser.y"
{
			 yyval.effect = new procedureEffectClass( yyvsp[-1].ident );
		       }
break;
case 163:
#line 1123 "daeParser.y"
{
			 const functionTermClass *f = dynamic_cast<const functionTermClass*>( yyvsp[-6].term );
			 if( f != NULL ) declaredProblem->dirtyFunctions.insert( strdup(f->function->ident) );
			 yyval.effect = new initTermSetEffectClass( yyvsp[-6].term, yyvsp[-3].termList, yyvsp[-1].formula );

			 const objectTermClass *obj = dynamic_cast<const objectTermClass*>(yyvsp[-6].term);
			 if( obj != NULL )
			   setVariableDenotationFor( obj->ident );
		       }
break;
case 164:
#line 1133 "daeParser.y"
{
			 const functionTermClass *f = dynamic_cast<const functionTermClass*>( yyvsp[-4].term );
			 if( f != NULL ) declaredProblem->dirtyFunctions.insert( strdup(f->function->ident) );
			 yyval.effect = new initTermSetEffectClass( yyvsp[-4].term, yyvsp[-2].integer.min, yyvsp[-2].integer.max, yyvsp[-1].formula );

			 const objectTermClass *obj = dynamic_cast<const objectTermClass*>(yyvsp[-4].term);
			 if( obj != NULL )
			   setVariableDenotationFor( obj->ident );
		       }
break;
case 165:
#line 1144 "daeParser.y"
{
			 yyval.effect = new initPredicateSetEffectClass( yyvsp[-8].ident, new termListClass( yyvsp[-7].termList ), yyvsp[-3].termList, yyvsp[-1].formula );
			 declaredProblem->dirtyPredicates.insert( strdup(yyvsp[-8].ident) );
		       }
break;
case 166:
#line 1149 "daeParser.y"
{
			 yyval.effect = new oneOfEffectClass( yyvsp[-1].effectList );
		       }
break;
case 167:
#line 1153 "daeParser.y"
{
			 yyval.effect = new formulaInitEffectClass( yyvsp[0].formula );
		       }
break;
case 168:
#line 1159 "daeParser.y"
{
			 yyval.formula = yyvsp[0].formula;
		       }
break;
case 169:
#line 1163 "daeParser.y"
{
			 yyval.formula = NULL;
		       }
break;
case 170:
#line 1170 "daeParser.y"
{
			 yyval.probEffectList = yyvsp[-1].probEffectList;
			 yyval.probEffectList->push_back( yyvsp[0].probEffect );
		       }
break;
case 171:
#line 1175 "daeParser.y"
{
			 yyval.probEffectList = new list<pair<const char*,const effectClass*>*>;
			 yyval.probEffectList->push_back( yyvsp[0].probEffect );
		       }
break;
case 172:
#line 1183 "daeParser.y"
{
			 yyval.probEffect = new pair<const char*,const effectClass*>(yyvsp[-2].ident,new effectListClass( yyvsp[-1].effectList ));
		       }
break;
case 173:
#line 1190 "daeParser.y"
{
			 yyval.effectList = yyvsp[-1].effectList;
			 yyval.effectList->push_back( yyvsp[0].effect );
		       }
break;
case 174:
#line 1195 "daeParser.y"
{
			 yyval.effectList = new list<const effectClass*>;
			 yyval.effectList->push_back( yyvsp[0].effect );
		       }
break;
case 175:
#line 1203 "daeParser.y"
{
			 yyval.effect = new effectListClass( yyvsp[-1].effectList );
		       }
break;
case 176:
#line 1209 "daeParser.y"
{
			 yyval.cost = new termCostClass( yyvsp[0].term );
		       }
break;
case 177:
#line 1244 "daeParser.y"
{
			 yyval.observation = new observationListClass( yyvsp[0].obsList );
		       }
break;
case 178:
#line 1248 "daeParser.y"
{
			 checkProbabilities( yyvsp[-1].probObsList );
			 if( declaredDomain->model != POMDP2 )
			   error( featureInModel, declaredDomain->model );
			 yyval.observation = new probabilisticObservationClass( yyvsp[-1].probObsList );
		       }
break;
case 179:
#line 1255 "daeParser.y"
{
			 if( (declaredDomain->model != ND_POMDP1) ||
			     (declaredDomain->model != ND_POMDP2) )
			   error( featureInModel, declaredDomain->model );
			 yyval.observation = new nonDeterministicObservationClass( yyvsp[-1].obsListList );
		       }
break;
case 180:
#line 1264 "daeParser.y"
{
			 yyval.obsList = yyvsp[-1].obsList;
			 yyval.obsList->push_back( yyvsp[0].observation );
		       }
break;
case 181:
#line 1269 "daeParser.y"
{
			 yyval.obsList = new list<const observationClass*>;
			 yyval.obsList->push_back( yyvsp[0].observation );
		       }
break;
case 182:
#line 1277 "daeParser.y"
{
			 yyval.observation = new formulaObservationClass( yyvsp[0].formula );
		       }
break;
case 183:
#line 1281 "daeParser.y"
{
			 yyval.observation = new termObservationClass( yyvsp[0].term );
		       }
break;
case 184:
#line 1285 "daeParser.y"
{
			 yyval.observation = new conditionalFormulaObservationClass( yyvsp[-2].formula, yyvsp[-1].formula );
		       }
break;
case 185:
#line 1289 "daeParser.y"
{
			 yyval.observation = new conditionalTermObservationClass( yyvsp[-2].formula, yyvsp[-1].term );
		       }
break;
case 186:
#line 1293 "daeParser.y"
{
			 /* if variable already bounded, declare error*/
			 list<map<const char*,const typeClass*,ltstr>*>::const_iterator it;
			 for( it = variableEnvironment.begin(); it != variableEnvironment.end(); ++it )
			   if( (*it)->find( yyvsp[-2].ident ) != (*it)->end() )
			     error( nameClash, yyvsp[-2].ident );

			 /* extend current environment*/
			 variableEnvironment.push_front( new map<const char*,const typeClass*,ltstr> );
			 declareVariable( strdup(yyvsp[-2].ident), new simpleTypeClass( strdup(yyvsp[0].ident) ) );
		       }
break;
case 187:
#line 1305 "daeParser.y"
{
			 yyval.observation = new vectorObservationClass( yyvsp[-5].ident, new simpleTypeClass( yyvsp[-3].ident ), yyvsp[-1].term, environmentClone() );
			 cleanEnvironment( variableEnvironment.front() );
			 variableEnvironment.pop_front();
		       }
break;
case 188:
#line 1314 "daeParser.y"
{
			 yyval.probObsList = yyvsp[-1].probObsList;
			 yyval.probObsList->push_back( yyvsp[0].probObs );
		       }
break;
case 189:
#line 1319 "daeParser.y"
{
			 yyval.probObsList = new list<pair<const char*,const observationListClass*>*>;
			 yyval.probObsList->push_back( yyvsp[0].probObs );
		       }
break;
case 190:
#line 1327 "daeParser.y"
{
			 yyval.probObs = new pair<const char*,const observationListClass*>(yyvsp[-2].ident,new observationListClass(yyvsp[-1].obsList));
		       }
break;
case 191:
#line 1334 "daeParser.y"
{
			 yyval.obsListList = yyvsp[-1].obsListList;
			 yyval.obsListList->push_back( (const observationListClass*)yyvsp[0].observation );
		       }
break;
case 192:
#line 1339 "daeParser.y"
{
			 yyval.obsListList = new list<const observationListClass*>;
			 yyval.obsListList->push_back( (const observationListClass*)yyvsp[0].observation );
		       }
break;
case 193:
#line 1347 "daeParser.y"
{
			 yyval.observation = new observationListClass( yyvsp[-1].obsList );
		       }
break;
case 194:
#line 1360 "daeParser.y"
{
			 startProblem( yyvsp[-5].ident, yyvsp[-1].ident );
		       }
break;
case 195:
#line 1364 "daeParser.y"
{
			 yyval.codeChunk = finishProblem();
			 
			 /* can't wait to the end for code generation */
			 generateCode( (problemClass*)yyval.codeChunk );
		       }
break;
case 202:
#line 1383 "daeParser.y"
{
			 declareInit( new effectListClass( yyvsp[0].effectList ) );
		       }
break;
case 203:
#line 1389 "daeParser.y"
{
			 declareGoal( yyvsp[0].formula );
		       }
break;
case 204:
#line 1393 "daeParser.y"
{
			 declareGoal( new certaintyGoalClass );
		       }
break;
case 205:
#line 1400 "daeParser.y"
{
			 yyval.effectList = yyvsp[-1].effectList;
			 yyval.effectList->push_back( yyvsp[0].effect );
		       }
break;
case 206:
#line 1405 "daeParser.y"
{
			 yyval.effectList = new list<const effectClass*>;
			 yyval.effectList->push_back( yyvsp[0].effect );
		       }
break;
case 209:
#line 1415 "daeParser.y"
{
			 yyval.effect = new whenEffectClass( yyvsp[-2].formula, new effectListClass( yyvsp[-1].effectList ) );
		       }
break;
case 210:
#line 1419 "daeParser.y"
{
			 /* if variable already bounded, declare error*/
			 list<map<const char*,const typeClass*,ltstr>*>::const_iterator it;
			 for( it = variableEnvironment.begin(); it != variableEnvironment.end(); ++it )
			   if( (*it)->find( yyvsp[-2].ident ) != (*it)->end() )
			     error( nameClash, yyvsp[-2].ident );

			 /* extend current environment*/
			 variableEnvironment.push_front( new map<const char*,const typeClass*,ltstr> );
			 declareVariable( strdup(yyvsp[-2].ident), new simpleTypeClass( strdup(yyvsp[0].ident) ) );
		       }
break;
case 211:
#line 1431 "daeParser.y"
{
			 yyval.effect = new forEachEffectClass(yyvsp[-5].ident,new simpleTypeClass(yyvsp[-3].ident),new effectListClass(yyvsp[-1].effectList));
			 cleanEnvironment( variableEnvironment.front() );
			 variableEnvironment.pop_front();
		       }
break;
case 212:
#line 1439 "daeParser.y"
{
			 declareHook( yyvsp[0].hook );
		       }
break;
case 213:
#line 1443 "daeParser.y"
{
			 declareHook( yyvsp[0].hook );
		       }
break;
case 214:
#line 1449 "daeParser.y"
{
			 yyval.hook = new hookClass( problemClass::MODEL_HOOK, yyvsp[-1].ident );
		       }
break;
case 215:
#line 1453 "daeParser.y"
{
			 yyval.hook = new hookClass( problemClass::BELIEF_HOOK, yyvsp[-1].ident );
		       }
break;
case 216:
#line 1457 "daeParser.y"
{
			 yyval.hook = new hookClass( problemClass::HEURISTIC_HOOK, yyvsp[-1].ident );
		       }
break;
case 217:
#line 1469 "daeParser.y"
{
			 startPackage( yyvsp[0].ident );
		       }
break;
case 218:
#line 1473 "daeParser.y"
{
			 finishPackage();
		       }
break;
#line 3170 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1)
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
