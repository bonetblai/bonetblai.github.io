/*
**  Daedalus
**  daeAnalysis.h -- Domain Analysis
**
**  Blai Bonet, Hector Geffner
**  Universidad Simon Bolivar, 1998, 1999, 2000, 2001, 2002
**
*/


void  predicateStaticPartition( problemClass *problem );
void  functionStaticPartition( problemClass *problem );
