//  Theseus
//  theStandardPOMDP.cc -- Standard POMDP Implementation
//
//  Blai Bonet, Hector Geffner
//  Universidad Simon Bolivar, 1998, 1999, 2000, 2001, 2002

#ifdef linux
#include <values.h>
#endif
#include <math.h>
#include <iostream>
#include <typeinfo>
#include <queue>
#include <deque>
#include <stack>

using namespace std;

#include <theseus/theStandardPOMDP.h>
#include <theseus/theTopLevel.h>
#include <theseus/theBelief.h>
#include <theseus/theResult.h>
#include <theseus/theException.h>
#include <theseus/theUtils.h>

// static variables
static standardPOMDPClass::QValueClass *bestQValueStaticResult = NULL;


///////////////////////////////////////////////////////////////////////////////
//
// Standard POMDP Class
//

// static members
int standardPOMDPClass::numberStates = 0;

void
standardPOMDPClass::finalize( void )
{
  delete bestQValueStaticResult;
  bestQValueStaticResult = NULL;
}

void
standardPOMDPClass::initRun( int run )
{
  if( quantizationForInitialBelief == NULL )
    beliefHash->quantize( true, true, theInitialBelief, quantizationForInitialBelief );
}

void
standardPOMDPClass::endRun( bool lastRun )
{
  if( !lastRun )
    POMDPClass::endRun( lastRun );
}

const hashEntryClass*
standardPOMDPClass::getTheInitialBelief( void )
{
  if( quantizationForInitialBelief == NULL )
    {
      beliefHash->quantize( true, true, theInitialBelief, quantizationForInitialBelief );
    }
  return( quantizationForInitialBelief );
}

POMDPClass::hashValueClass*
standardPOMDPClass::hashValue( const beliefClass* belief )
{
  hashEntryClass *hashEntry;
  static hashValueClass result;

  assert( belief != NULL );

  // quantization
  beliefHash->quantize( true, true, belief, hashEntry );

  // compute value
  result.value = hashEntry->getValue();
  result.solved = (bool)hashEntry->getExtra();
  return( &result );
}

int
standardPOMDPClass::getBestAction( const hashEntryClass *belief )
{
  int bestAction;
  QValueClass* QResult;

  QResult = bestQValue( (const beliefClass*)belief->getData(), true );
  if( QResult->numTies > 0 )
    bestAction = QResult->ties[0];
  else
    bestAction = -1;
  return( bestAction );
}

void
standardPOMDPClass::expandBeliefWithAction( const hashEntryClass *entry, int action,
					    deque<pair<pair<int,float>,const hashEntryClass*> >&result )
{
  hashEntryClass *quantization;
  const beliefClass *belief, *belief_a, *belief_ao; 
  static map<int,float> possibleObservations;
  static map<int,float>::const_iterator it;

  result.clear();
  belief = (const beliefClass*)entry->getData();
  if( applicable( belief, action ) )
    {
      // compute belief_a and possible observations
      belief_a = belief->updateByA( actionCache, true, action );
      possibleObservations.clear();
      belief_a->nextPossibleObservations( action, possibleObservations );
      assert( !possibleObservations.empty() );

      for( it = possibleObservations.begin(); it != possibleObservations.end(); ++it )
	if( (*it).second > 0.0 )
	  {
	    // compute bel_ao(s)
	    belief_ao = belief_a->updateByAO( observationCache, true, action, (*it).first );
	    beliefHash->quantize( true, true, belief_ao, quantization );
	    result.push_back( make_pair( make_pair( (*it).first, (*it).second ), quantization ) );
	  }
    }
}

void
standardPOMDPClass::algorithm( bool learning, resultClass& result )
{
  register float              realCost; 
  register int                idx, bestAction, state, new_state, observation;
  register beliefClass        *belief, *belief_a, *belief_ao;
  register QValueClass*       QResult;
  register hashEntryClass     *quantization;

  // stopping rule
  stack<hashEntryClass*> Stack;

  // check we have a POMDP problem
  assert( !PD.pddlProblemType || ISPOMDP(PD.handle->problemType) || ISNDPOMDP(PD.handle->problemType) );

  // initialize result
  result.runType = learning;
  result.initialValue = quantizationForInitialBelief->getValue();
  result.solved = (bool)quantizationForInitialBelief->getExtra();
  result.numMoves = 0;
  result.costToGoal = 0.0;
  result.discountedCostToGoal = 0.0;
  result.startTimer();

  // set initial belief and state
  if( learning )
    {
      quantization = quantizationForInitialBelief;
      belief = ((beliefClass*)quantization->getData())->clone();
    }
  else
    {
      quantization = NULL;
      belief = theInitialBelief->clone();
    }
  state = getInitialState( belief );

  // go for it!!!
  while( (PD.signal < 0) && (result.numMoves < maxMoves) )
    {
      // check soundness of belief and simulated system state
      assert( belief->check( state ) );
      if( PD.verboseLevel >= 30 )
	{
	  *PD.outputFile << "state = " << state;
	  *PD.outputFile << ", belief = " << *belief;
	  if( PD.verboseLevel >= 40 )
	    *PD.outputFile << ", quantization = " << quantization;
	  *PD.outputFile << ", HashValue = " << quantization->getValue() << endl;
	}

      // be sure we have the model for this belief
      belief->checkModelAvailability( model );

      // stopping rule
      if( learning && PD.useStopRule )
	{
	  // check for goal state (if in learning trial check also for solved)
	  assert( quantization != NULL );
	  if( inGoal( belief ) || (learning && (bool)quantization->getExtra()) )
	    {
	      result.push_back( state, -1, -1 );
	      quantization->setExtra( (void*)true );
	      goto theEnd;
	    }
	}
      else
	{
	  // check for goal state
	  if( inGoal( belief ) )
	    {
	      result.push_back( state, -1, -1 );
	      goto theEnd;
	    }
	}

      // compute the best QValues
      if( learning )
	QResult = bestQValue( quantization, true );
      else
	QResult = bestQValue( belief, true );

      // greedy selection of best action
      if( QResult->numTies > 0 )
	{
	  idx = (!randomTies ? 0 : lrand48() % QResult->numTies);
	  bestAction = QResult->ties[idx];
	}
      else
	{
	  // we have a dead-end
	  if( learning )
	    {
	      quantization->updateValue( FLT_MAX );
	      if( PD.useStopRule )
		quantization->setExtra( (void*)true );
	    }
	  result.costToGoal = -1.0;
	  result.discountedCostToGoal = -1.0;
	  result.push_back( state, -1, -1 );
	  break;
	}

      // update hash value (if learning)
      if( learning )
	{
	  assert( !PD.useStopRule || !(bool)quantization->getExtra() ||
		  (fabs( (double)(quantization->getValue()-QResult->value) ) < PD.SREpsilon) );
	  quantization->updateValue( QResult->value );

	  // stopping rule
	  if( PD.useStopRule )
	    Stack.push( quantization );
	}

      // get next state and observation
      realCost = cost( state, bestAction );
      result.costToGoal += realCost;
      result.discountedCostToGoal = realCost + discountFactor * result.discountedCostToGoal;
      new_state = nextState( state, bestAction );
      observation = nextObservation( new_state, bestAction );
      result.push_back( state, bestAction, observation );
      state = new_state;

      // get belief_ao and set new belief
      belief_a = belief->updateByA( actionCache, true, bestAction );
      belief_ao = belief_a->updateByAO( observationCache, true, bestAction, observation );
      if( learning )
	{
	  beliefHash->quantize( true, true, belief_ao, quantization );
	  *belief = *((beliefClass*)quantization->getData());
	}
      else
	{
	  *belief = *belief_ao;
	}

      // print info
      if( PD.verboseLevel >= 30 )
	{
	  *PD.outputFile << "action = " << bestAction << endl;
	  *PD.outputFile << "observation = " << observation << endl;
	  *PD.outputFile << "belief_a = " << *belief_a << endl;
	  *PD.outputFile << "belief_ao = " << *belief_ao << endl;
	}
    }

  // dead-end reached, return fail
  result.numMoves = -1;

  // this is the end, ...
 theEnd:
  delete belief;

  // check for abortion
  if( PD.signal >= 0 )
    {
      // cleanup
      int s = PD.signal;
      PD.signal = -1;

      if( PD.useStopRule )
	for( ; !Stack.empty(); Stack.pop() );
      throw( signalExceptionClass( s ) );
    }

  // stopping rule
  if( PD.useStopRule && learning && (result.numMoves < maxMoves) )
    {
      list<hashEntryClass*> closed;
      list<hashEntryClass*>::iterator it;

      while( !Stack.empty() )
	{
	  // get entry
	  hashEntryClass *entry = Stack.top();
	  Stack.pop();

	  // check if already solved
	  if( !(bool)entry->getExtra() )
	    {
	      // try labeling
	      closed.clear();
	      if( checkSolved( entry, closed ) )
		{
		  for( it = closed.begin(); it != closed.end(); ++it )
		    {
		      (*it)->setExtra( (void*)true );
		      *PD.outputFile << "solved belief " << *(beliefClass*)(*it)->getData();
		      *PD.outputFile << ", value = " << (*it)->getValue() << endl;
		    }
		}
	      else
		break;
	    }
	}
    }

  // clean stack and stop timer
  for( ; !Stack.empty(); Stack.pop() );
  result.stopTimer();
}

float
standardPOMDPClass::QValue( const beliefClass* belief, int action, bool useCache )
{
  float result, sum;
  hashValueClass *hValue;
  register beliefClass *belief_a, *belief_ao; 
  static map<int,float> possibleObservations;
  static map<int,float>::const_iterator it;

  if( applicable( belief, action ) )
    {
      // compute bel_a(s)
      belief_a = belief->updateByA( actionCache, useCache, action );

      // compute possible observations
      possibleObservations.clear();
      belief_a->nextPossibleObservations( action, possibleObservations );

      // check if we have observations in the model, if not, the belief doesn't change
      if( !possibleObservations.empty() )
	{
	  // make the calculation for future costs
	  sum = 0.0;
	  for( it = possibleObservations.begin(); it != possibleObservations.end(); ++it )
	    {
	      // compute bel_ao(s)
	      belief_ao = belief_a->updateByAO( observationCache, useCache, action, (*it).first );
	      hValue = hashValue( belief_ao );

	      // update sum
	      if( PD.pddlProblemType )
		{
		  switch( PD.handle->problemType )
		    {
		    case problemHandleClass::PROBLEM_POMDP1:
		    case problemHandleClass::PROBLEM_POMDP2:
		      sum += ((*it).second * hValue->value);
		      break;
		    case problemHandleClass::PROBLEM_ND_POMDP1:
		    case problemHandleClass::PROBLEM_ND_POMDP2:
		      sum = (sum == 0.0 ? hValue->value : (hValue->value > sum ? hValue->value : sum));
		      break;
		    default:
		      throw( unsupportedModelExceptionClass( PD.handle->problemType ) );
		    }
		}
	      else
		{
		  sum += ((*it).second * hValue->value);
		}
	    }
	}
      else
	{
	  sum = hashValue( belief_a )->value;
	}
      result = cost( belief, action ) + discountFactor * sum;
    }
  else
    {
      result = -1.0;
    }
  return( result );
}

standardPOMDPClass::QValueClass*
standardPOMDPClass::bestQValue( const beliefClass* belief, bool useCache )
{
  register int action;
  register bool noBest;
  register float sum, hval;
  register beliefClass *belief_a, *belief_ao; 
  static map<int,float> possibleObservations;
  static map<int,float>::const_iterator it;
  register hashEntryClass *quantization;

  // assertion and initialization
  assert( belief != NULL );
  if( bestQValueStaticResult == NULL )
    {
      bestQValueStaticResult = new QValueClass( numActions );
    }

  noBest = true;
  ++expansions;
  bestQValueStaticResult->numTies = 0;
  for( action = 0; action < numActions; ++action )
    if( applicable( belief, action ) )
      {
	// update statistics
	++branching;

	// compute bel_a(s)
	belief_a = belief->updateByA( actionCache, useCache, action );

	// compute possible observations
	possibleObservations.clear();
	belief_a->nextPossibleObservations( action, possibleObservations );
	assert( !possibleObservations.empty() );

	// make calculation for future costs
	sum = 0.0;
	for( it = possibleObservations.begin(); it != possibleObservations.end(); ++it )
	  if( (*it).second > 0.0 )
	    {
	      // compute bel_ao(s)
	      belief_ao = belief_a->updateByAO( observationCache, useCache, action, (*it).first );
	      beliefHash->quantize( true, false, belief_ao, quantization );
	      hval = quantization->getValue();

	      // update value
	      if( PD.pddlProblemType )
		{
		  switch( PD.handle->problemType )
		    {
		    case problemHandleClass::PROBLEM_POMDP1:
		    case problemHandleClass::PROBLEM_POMDP2:
		      sum += ((*it).second * hval);
		      break;
		    case problemHandleClass::PROBLEM_ND_POMDP1:
		    case problemHandleClass::PROBLEM_ND_POMDP2:
		      sum = (sum == 0.0 ? hval : (hval > sum ? hval : sum));
		      break;
		    default:
		      throw( unsupportedModelExceptionClass( PD.handle->problemType ) );
		    }
		}
	      else
		{
		  sum += ((*it).second * hval);
		}
	    }
	sum = cost( belief, action ) + discountFactor * sum;

	// look for the best action
	if( noBest || best( sum, bestQValueStaticResult->value ) || (sum == bestQValueStaticResult->value) )
	  {
	    if( noBest || (sum != bestQValueStaticResult->value) )
	      bestQValueStaticResult->numTies = 0;
	    noBest = false;
	    bestQValueStaticResult->value = sum;
	    bestQValueStaticResult->ties[bestQValueStaticResult->numTies] = action;
	    ++bestQValueStaticResult->numTies;
	  }
      }

  // if we have a dead-end, then result->numTies is zero.
  return( bestQValueStaticResult );
}

standardPOMDPClass::QValueClass*
standardPOMDPClass::bestQValue( const hashEntryClass* qBelief, bool useCache )
{
  register int action;
  register bool noBest;
  register float sum, hval;
  register beliefClass *belief, *belief_a, *belief_ao; 
  static map<int,float> possibleObservations;
  static map<int,float>::const_iterator it;
  register hashEntryClass *quantization;

  // assertion and initialization
  assert( qBelief != NULL );
  if( bestQValueStaticResult == NULL )
    {
      bestQValueStaticResult = new QValueClass( numActions );
    }

  noBest = true;
  ++expansions;
  bestQValueStaticResult->numTies = 0;
  belief = (beliefClass*)qBelief->getData();
  for( action = 0; action < numActions; ++action )
    if( applicable( belief, action ) )
      {
	// update statistics
	++branching;

	// compute bel_a(s)
	belief_a = belief->updateByA( actionCache, useCache, action );

	// compute possible observations
	possibleObservations.clear();
	belief_a->nextPossibleObservations( action, possibleObservations );
	assert( !possibleObservations.empty() );

	// check if we can insert belief_a into transition cache
	if( possibleObservations.size() == 1 ) ;

	// make calculation for future costs
	sum = 0.0;
	for( it = possibleObservations.begin(); it != possibleObservations.end(); ++it )
	  if( (*it).second > 0.0 )
	    {
	      // compute bel_ao(s)
	      belief_ao = belief_a->updateByAO( observationCache, useCache, action, (*it).first );
	      beliefHash->quantize( true, true, belief_ao, quantization );
	      hval = quantization->getValue();

	      // update value
	      if( PD.pddlProblemType )
		{
		  switch( PD.handle->problemType )
		    {
		    case problemHandleClass::PROBLEM_POMDP1:
		    case problemHandleClass::PROBLEM_POMDP2:
		      sum += ((*it).second * hval);
		      break;
		    case problemHandleClass::PROBLEM_ND_POMDP1:
		    case problemHandleClass::PROBLEM_ND_POMDP2:
		      sum = (sum == 0.0 ? hval : (hval > sum ? hval : sum));
		      break;
		    default:
		      throw( unsupportedModelExceptionClass( PD.handle->problemType ) );
		    }
		}
	      else
		{
		  sum += ((*it).second * hval);
		}
	    }
	sum = cost( belief, action ) + discountFactor * sum;

	// look for the best action
	if( noBest || best( sum, bestQValueStaticResult->value ) || (sum == bestQValueStaticResult->value) )
	  {
	    if( noBest || (sum != bestQValueStaticResult->value) )
	      bestQValueStaticResult->numTies = 0;
	    noBest = false;
	    bestQValueStaticResult->value = sum;
	    bestQValueStaticResult->ties[bestQValueStaticResult->numTies] = action;
	    ++bestQValueStaticResult->numTies;
	  }
      }

  // if we have a dead-end, then result->numTies is zero.
  return( bestQValueStaticResult );
}

bool
standardPOMDPClass::checkSolved( hashEntryClass *current, list<hashEntryClass*>& closed )
{
  register int action;
  register QValueClass  *QResult;
  register beliefClass *belief, *belief_a, *belief_ao;
  register hashEntryClass *quantization;
  map<int,float> possibleObservations;
  map<int,float>::const_iterator it;
  list<hashEntryClass*> open;
  set<hashEntryClass*> aux;

  // initialization
  aux.clear();
  closed.clear();
  open.clear();
  if( !(bool)current->getExtra() )
    open.push_front( current );

  // dfs
  bool rv = true;
  while( !open.empty() )
    {
      // get first from queue
      current = open.front();
      open.pop_front();
      closed.push_front( current );

      // check epsilon condition 
      belief = (beliefClass*)current->getData();
      belief->checkModelAvailability( model );
      QResult = bestQValue( current, true );
      if( QResult->numTies == 0 )
	{
	  // dead-end state
	  current->updateValue( FLT_MAX );
	  current->setExtra( (void*)true );
	  rv = false;
	  continue;
	}
      if( fabs( QResult->value - current->getValue() ) > PD.SREpsilon )
	{
	  rv = false;
	  continue;
	}
      action = QResult->ties[0];

      // unfold control
      possibleObservations.clear();
      belief_a = belief->updateByA( actionCache, true, action );
      belief_a->nextPossibleObservations( action, possibleObservations );
      if( !possibleObservations.empty() )
	{
	  for( it = possibleObservations.begin(); it != possibleObservations.end(); ++it )
	    if( (*it).second > 0.0 )
	      {
		// compute next belief_ao
		belief_ao = belief_a->updateByAO( observationCache, true, action, (*it).first );
		belief_ao->checkModelAvailability( model );
		if( !inGoal( belief_ao ) )
		  {
		    beliefHash->quantize( true, true, belief_ao, quantization );
		    if( !(bool)quantization->getExtra() && (aux.find(quantization) == aux.end()) )
		      {
			open.push_front( quantization );
			aux.insert( quantization );
		      }
		  }
	      }
	}
      else
	{
	  belief_a->checkModelAvailability( model );
	  if( !inGoal( belief_a ) )
	    {
	      beliefHash->quantize( true, true, belief_a, quantization );
	      if( !(bool)quantization->getExtra() && (aux.find( quantization ) == aux.end()) )
		{
		  open.push_front( quantization );
		  aux.insert( quantization );
		}
	    }
	}
    }

  // process nodes in dfs postorder
  if( !rv )
    {
      while( !closed.empty() )
	{
	  current = closed.front();
	  closed.pop_front();
	  QResult = bestQValue( current, true );
	  if( QResult->numTies > 0 )
	    current->updateValue( QResult->value );
	}
    }
  return( rv );
}


///////////////////////
//
// serialization

void
standardPOMDPClass::checkIn( void )
{
  signRegistration( typeid( standardPOMDPClass ).name(),
		    (void (*)( istream&, POMDPClass * )) &standardPOMDPClass::fill,
		    (POMDPClass *(*)( void )) &standardPOMDPClass::constructor );
}

void
standardPOMDPClass::write( ostream& os ) const
{
  const char *id;
  unsigned len;

  // write registrationId
  id = typeid( *this ).name();
  len = strlen( id ) + 1;
  safeWrite( &len, sizeof( unsigned ), 1, os );
  safeWrite( (void*)id, sizeof( char ), strlen( id ) + 1, os );

  // serialize base class
  POMDPClass::write( os );
}

standardPOMDPClass *
standardPOMDPClass::read( istream& is )
{
  standardPOMDPClass *pomdp;
  
  pomdp = new standardPOMDPClass;
  fill( is, pomdp );

  return( pomdp );
}

standardPOMDPClass *
standardPOMDPClass::constructor( void )
{
  return( new standardPOMDPClass );
}

void
standardPOMDPClass::fill( istream& is, standardPOMDPClass *pomdp )
{
  POMDPClass::fill( is, pomdp );
}
