#include <s0_std_avg.h>
#include <pkg/standard.h>
#include <list>
#include <map>

// static predicates 1 argument(s)
unsigned stateFor_s0Class::staticPredicate1[2][1];

// static predicates 3 argument(s)
unsigned stateFor_s0Class::staticPredicate3[1][432];

// static functions 1 argument(s)
int stateFor_s0Class::staticFunction1[3][24];

void
stateFor_s0Class::ramificationCode_open_ramification( register int _v_x )
{
  if( ( (object[0/*_need_wait*/] == false) && bitValue( &(staticPredicate1[_breaker][0]), _v_x ) && internalPredicate_affected( 0, NULL, false, _v_x ) ) )
    {
      setBit( &(predicate1[_closed][0]), _v_x, false );
    }

}

void
_s0Ramification0( stateFor_s0Class& s )
{
  s.ramificationCode_open_ramification( _cb1 );
}

void
_s0Ramification1( stateFor_s0Class& s )
{
  s.ramificationCode_open_ramification( _cb2 );
}

void
_s0Ramification2( stateFor_s0Class& s )
{
  s.ramificationCode_open_ramification( _cb3 );
}

void
_s0Ramification3( stateFor_s0Class& s )
{
  s.ramificationCode_open_ramification( _sd1 );
}

void
_s0Ramification4( stateFor_s0Class& s )
{
  s.ramificationCode_open_ramification( _sd2 );
}

void
_s0Ramification5( stateFor_s0Class& s )
{
  s.ramificationCode_open_ramification( _sd3 );
}

void
_s0Ramification6( stateFor_s0Class& s )
{
  s.ramificationCode_open_ramification( _sd4 );
}

void
_s0Ramification7( stateFor_s0Class& s )
{
  s.ramificationCode_open_ramification( _sd5 );
}

void
_s0Ramification8( stateFor_s0Class& s )
{
  s.ramificationCode_open_ramification( _sd6 );
}

void
_s0Ramification9( stateFor_s0Class& s )
{
  s.ramificationCode_open_ramification( _sd7 );
}

bool
stateFor_s0Class::internalPredicate_con( int depth, ARforPredicate_con *AR, bool defVal, register int _v_x, register int _v_sx, register int _v_y, register int _v_sy ) const
{
  bool rv;
  ARforPredicate_con current, *p;

  // initialize current Activation Record
  current._v_x = _v_x;
  current._v_sx = _v_sx;
  current._v_y = _v_y;
  current._v_sy = _v_sy;
  current.prev = AR;

  // check for branch loop
  for( p = AR; p != NULL; p = p->prev )
    if( (_v_x == p->_v_x) && (_v_sx == p->_v_sx) && (_v_y == p->_v_y) && (_v_sy == p->_v_sy) )
      return( defVal );

  rv = ( (!(_v_x == _v_y) || !(_v_sx == _v_sy)) && exists0( NULL, depth, &current, _v_sx, _v_sy, _v_x, _v_y ) );

  return( rv );
}

bool
stateFor_s0Class::internalPredicate_upstream( int depth, ARforPredicate_upstream *AR, bool defVal, register int _v_x, register int _v_sx, register int _v_y, register int _v_sy ) const
{
  bool rv;
  ARforPredicate_upstream current, *p;

  // initialize current Activation Record
  current._v_x = _v_x;
  current._v_sx = _v_sx;
  current._v_y = _v_y;
  current._v_sy = _v_sy;
  current.prev = AR;

  // check for branch loop
  for( p = AR; p != NULL; p = p->prev )
    if( (_v_x == p->_v_x) && (_v_sx == p->_v_sx) && (_v_y == p->_v_y) && (_v_sy == p->_v_sy) )
      return( defVal );

  rv = ( bitValue( &(predicate1[_closed][0]), _v_x ) && ( ( bitValue( &(staticPredicate1[_breaker][0]), _v_x ) && internalPredicate_con( 0, NULL, false, _v_x, staticFunction1[_opposite][_v_sx], _v_y, _v_sy ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _v_x ) && exists2( NULL, depth, &current, _v_sx, _v_sy, _v_x, _v_y ) ) || ( !bitValue( &(staticPredicate1[_breaker][0]), _v_x ) && ( ( internalPredicate_con( 0, NULL, false, _v_x, staticFunction1[_opposite][_v_sx], _v_y, _v_sy ) && exists4( NULL, depth, &current, _v_sx, _v_sy, _v_x, _v_y ) ) || exists6( NULL, depth, &current, _v_sx, _v_sy, _v_x, _v_y ) ) ) ) );

  return( rv );
}

bool
stateFor_s0Class::internalPredicate_fed( int depth, ARforPredicate_fed *AR, bool defVal, register int _v_x ) const
{
  bool rv;
  ARforPredicate_fed current, *p;

  // initialize current Activation Record
  current._v_x = _v_x;
  current.prev = AR;

  // check for branch loop
  for( p = AR; p != NULL; p = p->prev )
    if( (_v_x == p->_v_x) )
      return( defVal );

  rv = ( ( bitValue( &(staticPredicate1[_breaker][0]), _v_x ) && bitValue( &(predicate1[_closed][0]), _v_x ) ) || exists9( NULL, depth, &current, _v_x ) );

  return( rv );
}

bool
stateFor_s0Class::internalPredicate_affected( int depth, ARforPredicate_affected *AR, bool defVal, register int _v_x ) const
{
  bool rv;
  ARforPredicate_affected current, *p;

  // initialize current Activation Record
  current._v_x = _v_x;
  current.prev = AR;

  // check for branch loop
  for( p = AR; p != NULL; p = p->prev )
    if( (_v_x == p->_v_x) )
      return( defVal );

  rv = ( bitValue( &(predicate1[_closed][0]), _v_x ) && exists17( NULL, depth, &current, _v_x ) );

  return( rv );
}

bool
stateFor_s0Class::internalPredicate_closed_path( int depth, ARforPredicate_closed_path *AR, bool defVal, register int _v_x, register int _v_sx, register int _v_l ) const
{
  bool rv;
  ARforPredicate_closed_path current, *p;

  // initialize current Activation Record
  current._v_x = _v_x;
  current._v_sx = _v_sx;
  current._v_l = _v_l;
  current.prev = AR;

  // check for branch loop
  for( p = AR; p != NULL; p = p->prev )
    if( (_v_x == p->_v_x) && (_v_sx == p->_v_sx) && (_v_l == p->_v_l) )
      return( defVal );

  rv = ( bitValue( &(predicate1[_closed][0]), _v_x ) && !bitValue( &(predicate1[_faulty][0]), _v_l ) && ( bitValue( &(staticPredicate3[_ext][0]), ((_v_l)*NUMOBJECTS + _v_x)*NUMOBJECTS + staticFunction1[_opposite][_v_sx] ) || exists20( NULL, depth, &current, _v_l, _v_sx, _v_x ) ) );

  return( rv );
}

bool
stateFor_s0Class::internalPredicate_fed_line( int depth, ARforPredicate_fed_line *AR, bool defVal, register int _v_l ) const
{
  bool rv;
  ARforPredicate_fed_line current, *p;

  // initialize current Activation Record
  current._v_l = _v_l;
  current.prev = AR;

  // check for branch loop
  for( p = AR; p != NULL; p = p->prev )
    if( (_v_l == p->_v_l) )
      return( defVal );

  rv = exists22( NULL, depth, &current, _v_l );

  return( rv );
}

bool
stateFor_s0Class::internalPredicate_bad( int depth, ARforPredicate_bad *AR, bool defVal, register int _v_x ) const
{
  bool rv;
  ARforPredicate_bad current, *p;

  // initialize current Activation Record
  current._v_x = _v_x;
  current.prev = AR;

  // check for branch loop
  for( p = AR; p != NULL; p = p->prev )
    if( (_v_x == p->_v_x) )
      return( defVal );

  rv = ( (!!bitValue( &(staticPredicate1[_breaker][0]), _v_x ) || exists26( NULL, depth, &current, _v_x )) && (!bitValue( &(staticPredicate1[_breaker][0]), _v_x ) || exists30( NULL, depth, &current, _v_x )) );

  return( rv );
}

stateListFor_s0Class *
stateFor_s0Class::statesAfter_wait( register int opId ) const 
{
  register int prec;
  register stateListFor_s0Class *ptr;
  static stateListFor_s0Class result[2];

  // setup resulting states
  *result[0].state = *this;
  result[0].action = opId;
  result[0].probability = 1.0;
  result[0].state->valid = 1;
  result[1].probability = -1.0;
  ptr = result;

  prec = (object[0/*_need_wait*/] == true);
  if( prec == 1 )
    {
      ((stateFor_s0Class*)ptr->state)->object[0/*_need_wait*/] = false;
    }
  else
    result[0].probability = -1.0;
  return( result );
}

float
stateFor_s0Class::costAfter_wait( void ) const
{
  return( 0 );
}

observationListFor_s0Class *
stateFor_s0Class::observationsAfter_wait( void ) const
{
  register observationListFor_s0Class *result, *ptr;
  register int offset;

  // setup resulting observations
  result = new observationListFor_s0Class[0+1];
  result[0].probability = -1.0;
  ptr = &result[0];
  offset = 0;

  return( result );
}

stateListClass *
_s0Action0( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_wait();
  result = s.statesAfter_wait( 0 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_wait();
    }
  return( result );
}

stateListFor_s0Class *
stateFor_s0Class::statesAfter_finish( register int opId ) const 
{
  register int prec;
  register stateListFor_s0Class *ptr;
  static stateListFor_s0Class result[2];

  // setup resulting states
  *result[0].state = *this;
  result[0].action = opId;
  result[0].probability = 1.0;
  result[0].state->valid = 1;
  result[1].probability = -1.0;
  ptr = result;

  prec = (object[0/*_need_wait*/] == false);
  if( prec == 1 )
    {
      ((stateFor_s0Class*)ptr->state)->object[1/*_done*/] = true;
    }
  else
    result[0].probability = -1.0;
  return( result );
}

float
stateFor_s0Class::costAfter_finish( void ) const
{
  return( summation0( NULL ) );
}

observationListFor_s0Class *
stateFor_s0Class::observationsAfter_finish( void ) const
{
  register observationListFor_s0Class *result, *ptr;
  register int offset;

  // setup resulting observations
  result = new observationListFor_s0Class[0+1];
  result[0].probability = -1.0;
  ptr = &result[0];
  offset = 0;

  return( result );
}

stateListClass *
_s0Action1( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_finish();
  result = s.statesAfter_finish( 1 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_finish();
    }
  return( result );
}

stateListFor_s0Class *
stateFor_s0Class::statesAfter_close( register int opId, register int _v_x ) const 
{
  register int prec;
  register stateListFor_s0Class *ptr;
  static stateListFor_s0Class result[2];

  // setup resulting states
  *result[0].state = *this;
  result[0].action = opId;
  result[0].probability = 1.0;
  result[0].state->valid = 1;
  result[1].probability = -1.0;
  ptr = result;

  prec = ( (object[0/*_need_wait*/] == false) && !internalPredicate_bad( 0, NULL, false, _v_x ) );
  if( prec == 1 )
    {
      ((stateFor_s0Class*)ptr->state)->object[0/*_need_wait*/] = true;
      if( (staticFunction1[_ac_mode][_v_x] == _ok) )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _v_x, true );
        }

    }
  else
    result[0].probability = -1.0;
  return( result );
}

float
stateFor_s0Class::costAfter_close( register int _v_x ) const
{
  return( 1.0 );
}

observationListFor_s0Class *
stateFor_s0Class::observationsAfter_close( register int _v_x ) const
{
  register observationListFor_s0Class *result, *ptr;
  register int offset;

  // setup resulting observations
  result = new observationListFor_s0Class[1+1];
  result[0].probability = 1.0;
  result[1].probability = -1.0;
  ptr = &result[0];
  offset = 0;

  // observation code
  ptr->observation->setValue( offset++, (staticFunction1[_ac_mode][_v_x] == _out) );

  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _cb1 )?bitValue( &(predicate1[_closed][0]), _cb1 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _cb2 )?bitValue( &(predicate1[_closed][0]), _cb2 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _cb3 )?bitValue( &(predicate1[_closed][0]), _cb3 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _sd1 )?bitValue( &(predicate1[_closed][0]), _sd1 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _sd2 )?bitValue( &(predicate1[_closed][0]), _sd2 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _sd3 )?bitValue( &(predicate1[_closed][0]), _sd3 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _sd4 )?bitValue( &(predicate1[_closed][0]), _sd4 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _sd5 )?bitValue( &(predicate1[_closed][0]), _sd5 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _sd6 )?bitValue( &(predicate1[_closed][0]), _sd6 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _sd7 )?bitValue( &(predicate1[_closed][0]), _sd7 ):false) );

  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_cb1] == _out) && internalPredicate_fed( 0, NULL, false, _cb1 ) )?((staticFunction1[_fd_mode][_cb1] == _ok)?internalPredicate_affected( 0, NULL, false, _cb1 ):!internalPredicate_affected( 0, NULL, false, _cb1 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_cb2] == _out) && internalPredicate_fed( 0, NULL, false, _cb2 ) )?((staticFunction1[_fd_mode][_cb2] == _ok)?internalPredicate_affected( 0, NULL, false, _cb2 ):!internalPredicate_affected( 0, NULL, false, _cb2 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_cb3] == _out) && internalPredicate_fed( 0, NULL, false, _cb3 ) )?((staticFunction1[_fd_mode][_cb3] == _ok)?internalPredicate_affected( 0, NULL, false, _cb3 ):!internalPredicate_affected( 0, NULL, false, _cb3 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_sd1] == _out) && internalPredicate_fed( 0, NULL, false, _sd1 ) )?((staticFunction1[_fd_mode][_sd1] == _ok)?internalPredicate_affected( 0, NULL, false, _sd1 ):!internalPredicate_affected( 0, NULL, false, _sd1 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_sd2] == _out) && internalPredicate_fed( 0, NULL, false, _sd2 ) )?((staticFunction1[_fd_mode][_sd2] == _ok)?internalPredicate_affected( 0, NULL, false, _sd2 ):!internalPredicate_affected( 0, NULL, false, _sd2 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_sd3] == _out) && internalPredicate_fed( 0, NULL, false, _sd3 ) )?((staticFunction1[_fd_mode][_sd3] == _ok)?internalPredicate_affected( 0, NULL, false, _sd3 ):!internalPredicate_affected( 0, NULL, false, _sd3 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_sd4] == _out) && internalPredicate_fed( 0, NULL, false, _sd4 ) )?((staticFunction1[_fd_mode][_sd4] == _ok)?internalPredicate_affected( 0, NULL, false, _sd4 ):!internalPredicate_affected( 0, NULL, false, _sd4 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_sd5] == _out) && internalPredicate_fed( 0, NULL, false, _sd5 ) )?((staticFunction1[_fd_mode][_sd5] == _ok)?internalPredicate_affected( 0, NULL, false, _sd5 ):!internalPredicate_affected( 0, NULL, false, _sd5 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_sd6] == _out) && internalPredicate_fed( 0, NULL, false, _sd6 ) )?((staticFunction1[_fd_mode][_sd6] == _ok)?internalPredicate_affected( 0, NULL, false, _sd6 ):!internalPredicate_affected( 0, NULL, false, _sd6 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_sd7] == _out) && internalPredicate_fed( 0, NULL, false, _sd7 ) )?((staticFunction1[_fd_mode][_sd7] == _ok)?internalPredicate_affected( 0, NULL, false, _sd7 ):!internalPredicate_affected( 0, NULL, false, _sd7 )):false) );

  return( result );
}

stateListClass *
_s0Action2( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_close( _cb1 );
  result = s.statesAfter_close( 2, _cb1 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_close( _cb1 );
    }
  return( result );
}

stateListClass *
_s0Action3( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_close( _cb2 );
  result = s.statesAfter_close( 3, _cb2 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_close( _cb2 );
    }
  return( result );
}

stateListClass *
_s0Action4( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_close( _cb3 );
  result = s.statesAfter_close( 4, _cb3 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_close( _cb3 );
    }
  return( result );
}

stateListClass *
_s0Action5( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_close( _sd1 );
  result = s.statesAfter_close( 5, _sd1 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_close( _sd1 );
    }
  return( result );
}

stateListClass *
_s0Action6( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_close( _sd2 );
  result = s.statesAfter_close( 6, _sd2 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_close( _sd2 );
    }
  return( result );
}

stateListClass *
_s0Action7( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_close( _sd3 );
  result = s.statesAfter_close( 7, _sd3 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_close( _sd3 );
    }
  return( result );
}

stateListClass *
_s0Action8( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_close( _sd4 );
  result = s.statesAfter_close( 8, _sd4 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_close( _sd4 );
    }
  return( result );
}

stateListClass *
_s0Action9( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_close( _sd5 );
  result = s.statesAfter_close( 9, _sd5 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_close( _sd5 );
    }
  return( result );
}

stateListClass *
_s0Action10( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_close( _sd6 );
  result = s.statesAfter_close( 10, _sd6 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_close( _sd6 );
    }
  return( result );
}

stateListClass *
_s0Action11( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_close( _sd7 );
  result = s.statesAfter_close( 11, _sd7 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_close( _sd7 );
    }
  return( result );
}

stateListFor_s0Class *
stateFor_s0Class::statesAfter_open( register int opId, register int _v_x ) const 
{
  register int prec;
  register stateListFor_s0Class *ptr;
  static stateListFor_s0Class result[2];

  // setup resulting states
  *result[0].state = *this;
  result[0].action = opId;
  result[0].probability = 1.0;
  result[0].state->valid = 1;
  result[1].probability = -1.0;
  ptr = result;

  prec = (object[0/*_need_wait*/] == false);
  if( prec == 1 )
    {
      ((stateFor_s0Class*)ptr->state)->object[0/*_need_wait*/] = true;
      if( (staticFunction1[_ac_mode][_v_x] == _ok) )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _v_x, false );
        }

    }
  else
    result[0].probability = -1.0;
  return( result );
}

float
stateFor_s0Class::costAfter_open( register int _v_x ) const
{
  return( 1.0 );
}

observationListFor_s0Class *
stateFor_s0Class::observationsAfter_open( register int _v_x ) const
{
  register observationListFor_s0Class *result, *ptr;
  register int offset;

  // setup resulting observations
  result = new observationListFor_s0Class[1+1];
  result[0].probability = 1.0;
  result[1].probability = -1.0;
  ptr = &result[0];
  offset = 0;

  // observation code
  ptr->observation->setValue( offset++, (staticFunction1[_ac_mode][_v_x] == _out) );

  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _cb1 )?bitValue( &(predicate1[_closed][0]), _cb1 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _cb2 )?bitValue( &(predicate1[_closed][0]), _cb2 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _cb3 )?bitValue( &(predicate1[_closed][0]), _cb3 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _sd1 )?bitValue( &(predicate1[_closed][0]), _sd1 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _sd2 )?bitValue( &(predicate1[_closed][0]), _sd2 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _sd3 )?bitValue( &(predicate1[_closed][0]), _sd3 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _sd4 )?bitValue( &(predicate1[_closed][0]), _sd4 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _sd5 )?bitValue( &(predicate1[_closed][0]), _sd5 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _sd6 )?bitValue( &(predicate1[_closed][0]), _sd6 ):false) );
  ptr->observation->setValue( offset++, (bitValue( &(staticPredicate1[_pd_ok][0]), _sd7 )?bitValue( &(predicate1[_closed][0]), _sd7 ):false) );

  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_cb1] == _out) && internalPredicate_fed( 0, NULL, false, _cb1 ) )?((staticFunction1[_fd_mode][_cb1] == _ok)?internalPredicate_affected( 0, NULL, false, _cb1 ):!internalPredicate_affected( 0, NULL, false, _cb1 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_cb2] == _out) && internalPredicate_fed( 0, NULL, false, _cb2 ) )?((staticFunction1[_fd_mode][_cb2] == _ok)?internalPredicate_affected( 0, NULL, false, _cb2 ):!internalPredicate_affected( 0, NULL, false, _cb2 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_cb3] == _out) && internalPredicate_fed( 0, NULL, false, _cb3 ) )?((staticFunction1[_fd_mode][_cb3] == _ok)?internalPredicate_affected( 0, NULL, false, _cb3 ):!internalPredicate_affected( 0, NULL, false, _cb3 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_sd1] == _out) && internalPredicate_fed( 0, NULL, false, _sd1 ) )?((staticFunction1[_fd_mode][_sd1] == _ok)?internalPredicate_affected( 0, NULL, false, _sd1 ):!internalPredicate_affected( 0, NULL, false, _sd1 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_sd2] == _out) && internalPredicate_fed( 0, NULL, false, _sd2 ) )?((staticFunction1[_fd_mode][_sd2] == _ok)?internalPredicate_affected( 0, NULL, false, _sd2 ):!internalPredicate_affected( 0, NULL, false, _sd2 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_sd3] == _out) && internalPredicate_fed( 0, NULL, false, _sd3 ) )?((staticFunction1[_fd_mode][_sd3] == _ok)?internalPredicate_affected( 0, NULL, false, _sd3 ):!internalPredicate_affected( 0, NULL, false, _sd3 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_sd4] == _out) && internalPredicate_fed( 0, NULL, false, _sd4 ) )?((staticFunction1[_fd_mode][_sd4] == _ok)?internalPredicate_affected( 0, NULL, false, _sd4 ):!internalPredicate_affected( 0, NULL, false, _sd4 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_sd5] == _out) && internalPredicate_fed( 0, NULL, false, _sd5 ) )?((staticFunction1[_fd_mode][_sd5] == _ok)?internalPredicate_affected( 0, NULL, false, _sd5 ):!internalPredicate_affected( 0, NULL, false, _sd5 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_sd6] == _out) && internalPredicate_fed( 0, NULL, false, _sd6 ) )?((staticFunction1[_fd_mode][_sd6] == _ok)?internalPredicate_affected( 0, NULL, false, _sd6 ):!internalPredicate_affected( 0, NULL, false, _sd6 )):false) );
  ptr->observation->setValue( offset++, (( !(staticFunction1[_fd_mode][_sd7] == _out) && internalPredicate_fed( 0, NULL, false, _sd7 ) )?((staticFunction1[_fd_mode][_sd7] == _ok)?internalPredicate_affected( 0, NULL, false, _sd7 ):!internalPredicate_affected( 0, NULL, false, _sd7 )):false) );

  return( result );
}

stateListClass *
_s0Action12( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_open( _cb1 );
  result = s.statesAfter_open( 12, _cb1 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_open( _cb1 );
    }
  return( result );
}

stateListClass *
_s0Action13( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_open( _cb2 );
  result = s.statesAfter_open( 13, _cb2 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_open( _cb2 );
    }
  return( result );
}

stateListClass *
_s0Action14( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_open( _cb3 );
  result = s.statesAfter_open( 14, _cb3 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_open( _cb3 );
    }
  return( result );
}

stateListClass *
_s0Action15( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_open( _sd1 );
  result = s.statesAfter_open( 15, _sd1 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_open( _sd1 );
    }
  return( result );
}

stateListClass *
_s0Action16( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_open( _sd2 );
  result = s.statesAfter_open( 16, _sd2 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_open( _sd2 );
    }
  return( result );
}

stateListClass *
_s0Action17( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_open( _sd3 );
  result = s.statesAfter_open( 17, _sd3 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_open( _sd3 );
    }
  return( result );
}

stateListClass *
_s0Action18( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_open( _sd4 );
  result = s.statesAfter_open( 18, _sd4 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_open( _sd4 );
    }
  return( result );
}

stateListClass *
_s0Action19( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_open( _sd5 );
  result = s.statesAfter_open( 19, _sd5 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_open( _sd5 );
    }
  return( result );
}

stateListClass *
_s0Action20( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_open( _sd6 );
  result = s.statesAfter_open( 20, _sd6 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_open( _sd6 );
    }
  return( result );
}

stateListClass *
_s0Action21( const stateFor_s0Class& s )
{
  register float cost;
  register stateListFor_s0Class *result, *p;

  cost = s.costAfter_open( _sd7 );
  result = s.statesAfter_open( 21, _sd7 );
  for( p = result; p->probability != -1; ++p )
    {
      p->cost = cost;
      p->state->applyRamifications();
      p->observations = ((stateFor_s0Class*)p->state)->observationsAfter_open( _sd7 );
    }
  return( result );
}

stateFor_s0Class::stateFor_s0Class()
{
  valid = 1;
  object[1/*_done*/] = 0;
  object[0/*_need_wait*/] = 0;
  memset( predicate1, 0, 2 * 1 * sizeof(unsigned) );
}

stateFor_s0Class::~stateFor_s0Class()
{
}

stateClass&
stateFor_s0Class::operator=( register const stateClass& s )
{
  return( this->operator=( (const stateFor_s0Class&)s ) );
}

stateClass&
stateFor_s0Class::operator=( register const stateFor_s0Class& s )
{
  valid = s.valid;
  memcpy( object, s.object, 2 * sizeof( int ) );
  memcpy( &predicate1[0][0], &s.predicate1[0][0], 2 * 1 * sizeof(unsigned) );
  return( *this );
}

bool
stateFor_s0Class::operator==( register const stateClass& s ) const
{
  return( this->operator==( (const stateFor_s0Class&)s ) );
}

bool
stateFor_s0Class::operator==( register const stateFor_s0Class& s ) const
{
  return( (valid == s.valid) &&
          !memcmp( object, s.object, 2 * sizeof( int ) ) &&
          !memcmp( &predicate1[0][0], &s.predicate1[0][0], 2 * 1 * sizeof(unsigned) ) );
}

stateClass *
stateFor_s0Class::clone( void ) const
{
  register stateFor_s0Class *state;

  state = new stateFor_s0Class;
  return( &(*state = *this) );
}

stateListFor_s0Class::stateListFor_s0Class()
{
  state = new stateFor_s0Class;
}

stateListClass *
stateListFor_s0Class::alloc( register int size )
{
  return( new stateListFor_s0Class[size] );
}

int observationFor_s0Class::observationSize = 21+1;

observationFor_s0Class::observationFor_s0Class()
{
  memset( obs, -1, observationSize * sizeof( int ) );
}

observationClass&
observationFor_s0Class::operator=( register const observationClass& o )
{
  return( this->operator=( (const observationFor_s0Class&)o ) );
}

observationClass&
observationFor_s0Class::operator=( register const observationFor_s0Class& o )
{
  memcpy( obs, o.obs, observationSize * sizeof( int ) );
  return( *this );
}

bool
observationFor_s0Class::operator==( register const observationClass& o ) const
{
  return( this->operator==( (const observationFor_s0Class&)o ) );
}

bool
observationFor_s0Class::operator==( register const observationFor_s0Class& o ) const
{
  return( !memcmp( obs, o.obs, observationSize * sizeof( int ) ) );
}

observationClass *
observationFor_s0Class::clone( void ) const
{
  register observationFor_s0Class *newObs;

  newObs = new observationFor_s0Class;
  return( &(*newObs = *this) );
}

void
observationFor_s0Class::setValue( register int offset, register int value )
{
  obs[offset] = value;
}

void
observationFor_s0Class::print( ostream& os, int indent ) const
{
  os << "[";
  os << obs[0] << ",";
  os << obs[1] << ",";
  os << obs[2] << ",";
  os << obs[3] << ",";
  os << obs[4] << ",";
  os << obs[5] << ",";
  os << obs[6] << ",";
  os << obs[7] << ",";
  os << obs[8] << ",";
  os << obs[9] << ",";
  os << obs[10] << ",";
  os << obs[11] << ",";
  os << obs[12] << ",";
  os << obs[13] << ",";
  os << obs[14] << ",";
  os << obs[15] << ",";
  os << obs[16] << ",";
  os << obs[17] << ",";
  os << obs[18] << ",";
  os << obs[19] << ",";
  os << obs[20] << "]" << endl;
}

observationListFor_s0Class::observationListFor_s0Class()
{
  observation = new observationFor_s0Class;
}

observationListFor_s0Class::~observationListFor_s0Class()
{
  delete observation;
}

void
observationListFor_s0Class::print( ostream& os, int indent ) const
{
  os << "hello world!" << endl;
}

int stateFor_s0Class::numActions;
const char **stateFor_s0Class::actionName;
void (**stateFor_s0Class::ramificationTable)( stateFor_s0Class& );

stateListClass *(**stateFor_s0Class::actionTable)( const stateFor_s0Class& );

void
stateFor_s0Class::fillTables( void )
{
  // actionTable
  actionTable = (stateListClass*(**)( const stateFor_s0Class& ))new void*[23];
  actionTable[0] = &_s0Action0;
  actionTable[1] = &_s0Action1;
  actionTable[2] = &_s0Action2;
  actionTable[3] = &_s0Action3;
  actionTable[4] = &_s0Action4;
  actionTable[5] = &_s0Action5;
  actionTable[6] = &_s0Action6;
  actionTable[7] = &_s0Action7;
  actionTable[8] = &_s0Action8;
  actionTable[9] = &_s0Action9;
  actionTable[10] = &_s0Action10;
  actionTable[11] = &_s0Action11;
  actionTable[12] = &_s0Action12;
  actionTable[13] = &_s0Action13;
  actionTable[14] = &_s0Action14;
  actionTable[15] = &_s0Action15;
  actionTable[16] = &_s0Action16;
  actionTable[17] = &_s0Action17;
  actionTable[18] = &_s0Action18;
  actionTable[19] = &_s0Action19;
  actionTable[20] = &_s0Action20;
  actionTable[21] = &_s0Action21;
  actionTable[22] = NULL;
  numActions = 22;
  observationFor_s0Class::observationSize = 21+1;

  actionName = new const char*[22];
  actionName[0] = "wait()";
  actionName[1] = "finish()";
  actionName[2] = "close(_cb1)";
  actionName[3] = "close(_cb2)";
  actionName[4] = "close(_cb3)";
  actionName[5] = "close(_sd1)";
  actionName[6] = "close(_sd2)";
  actionName[7] = "close(_sd3)";
  actionName[8] = "close(_sd4)";
  actionName[9] = "close(_sd5)";
  actionName[10] = "close(_sd6)";
  actionName[11] = "close(_sd7)";
  actionName[12] = "open(_cb1)";
  actionName[13] = "open(_cb2)";
  actionName[14] = "open(_cb3)";
  actionName[15] = "open(_sd1)";
  actionName[16] = "open(_sd2)";
  actionName[17] = "open(_sd3)";
  actionName[18] = "open(_sd4)";
  actionName[19] = "open(_sd5)";
  actionName[20] = "open(_sd6)";
  actionName[21] = "open(_sd7)";

  // ramificationTable
  ramificationTable = (void(**)( stateFor_s0Class& ))new void*[11];
  ramificationTable[0] = &_s0Ramification0;
  ramificationTable[1] = &_s0Ramification1;
  ramificationTable[2] = &_s0Ramification2;
  ramificationTable[3] = &_s0Ramification3;
  ramificationTable[4] = &_s0Ramification4;
  ramificationTable[5] = &_s0Ramification5;
  ramificationTable[6] = &_s0Ramification6;
  ramificationTable[7] = &_s0Ramification7;
  ramificationTable[8] = &_s0Ramification8;
  ramificationTable[9] = &_s0Ramification9;
  ramificationTable[10] = NULL;
}

void
stateFor_s0Class::cleanUp( void )
{
  delete[] actionTable;
  delete[] actionName;
  delete[] ramificationTable;
}

stateListClass *
stateFor_s0Class::bootstrap( void )
{
  return( stateFor_s0Class::getInitialSituations() );
}

void
stateFor_s0Class::printAction( ostream& os, int action )
{
  os << actionName[action];
}

void
stateFor_s0Class::generateField( int index, stateListFor_s0Class*& actualList )
{
  register stateListFor_s0Class *result, *ptr, *tmp;
  stateListFor_s0Class *newElement = NULL;
  list<stateListFor_s0Class*> toBeRemoved;
  list<stateListFor_s0Class*>::iterator it;

  // allocate space
  newElement = new stateListFor_s0Class;

  // generate indicated field
  result = NULL;
  switch( index )
    {
    case 0:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_opposite][_side1] = _side2;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 1:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_opposite][_side2] = _side1;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 2:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->object[0/*_need_wait*/] = true;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 3:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->object[1/*_done*/] = false;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 4:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate1[_breaker][0]), _cb1, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 5:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate1[_breaker][0]), _cb2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 6:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate1[_breaker][0]), _cb3, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 7:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l1)*NUMOBJECTS + _cb1)*NUMOBJECTS + _side2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 8:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l1)*NUMOBJECTS + _sd6)*NUMOBJECTS + _side1, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 9:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l2)*NUMOBJECTS + _sd6)*NUMOBJECTS + _side2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 10:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l2)*NUMOBJECTS + _sd5)*NUMOBJECTS + _side1, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 11:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l2)*NUMOBJECTS + _sd7)*NUMOBJECTS + _side2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 12:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l3)*NUMOBJECTS + _sd5)*NUMOBJECTS + _side2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 13:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l3)*NUMOBJECTS + _sd1)*NUMOBJECTS + _side1, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 14:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l4)*NUMOBJECTS + _sd1)*NUMOBJECTS + _side2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 15:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l4)*NUMOBJECTS + _sd2)*NUMOBJECTS + _side2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 16:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l4)*NUMOBJECTS + _sd3)*NUMOBJECTS + _side2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 17:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l5)*NUMOBJECTS + _cb2)*NUMOBJECTS + _side2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 18:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l5)*NUMOBJECTS + _sd4)*NUMOBJECTS + _side1, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 19:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l6)*NUMOBJECTS + _sd2)*NUMOBJECTS + _side1, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 20:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l6)*NUMOBJECTS + _sd4)*NUMOBJECTS + _side2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 21:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l6)*NUMOBJECTS + _sd7)*NUMOBJECTS + _side1, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 22:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l7)*NUMOBJECTS + _cb3)*NUMOBJECTS + _side2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 23:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate3[_ext][0]), ((_l7)*NUMOBJECTS + _sd3)*NUMOBJECTS + _side1, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 24:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _cb1, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 25:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_fd_mode][_cb1] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 26:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate1[_pd_ok][0]), _cb1, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 27:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_ac_mode][_cb1] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 28:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _cb2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 29:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_fd_mode][_cb2] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 30:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate1[_pd_ok][0]), _cb2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 31:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_ac_mode][_cb2] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 32:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _cb3, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 33:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_fd_mode][_cb3] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 34:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate1[_pd_ok][0]), _cb3, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 35:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_ac_mode][_cb3] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 36:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _sd1, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 37:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_fd_mode][_sd1] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 38:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate1[_pd_ok][0]), _sd1, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 39:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_ac_mode][_sd1] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 40:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _sd2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 41:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_fd_mode][_sd2] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 42:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate1[_pd_ok][0]), _sd2, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 43:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_ac_mode][_sd2] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 44:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _sd3, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 45:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_fd_mode][_sd3] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 46:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate1[_pd_ok][0]), _sd3, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 47:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_ac_mode][_sd3] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 48:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _sd4, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 49:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_fd_mode][_sd4] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 50:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate1[_pd_ok][0]), _sd4, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 51:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_ac_mode][_sd4] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 52:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _sd5, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 53:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_fd_mode][_sd5] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 54:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate1[_pd_ok][0]), _sd5, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 55:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_ac_mode][_sd5] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 56:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _sd6, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 57:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_fd_mode][_sd6] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 58:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate1[_pd_ok][0]), _sd6, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 59:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_ac_mode][_sd6] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 60:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _sd7, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 61:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_fd_mode][_sd7] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 62:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->staticPredicate1[_pd_ok][0]), _sd7, true );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 63:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          ((stateFor_s0Class*)ptr->state)->staticFunction1[_ac_mode][_sd7] = _ok;          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 65:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _sd3, false );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 66:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _sd5, false );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 67:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          setBit( &(((stateFor_s0Class*)ptr->state)->predicate1[_closed][0]), _sd7, false );          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    case 68:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          // new value (predicate)
          *(newElement->state) = *(ptr->state);
          setBit( &(((stateFor_s0Class*)newElement->state)->predicate1[_faulty][0]), _l1, true );
          concatLists( (stateListClass*&)result, newElement );
          newElement = new stateListFor_s0Class;

          // new value (predicate)
          *(newElement->state) = *(ptr->state);
          setBit( &(((stateFor_s0Class*)newElement->state)->predicate1[_faulty][0]), _l1, false );
          concatLists( (stateListClass*&)result, newElement );
          newElement = new stateListFor_s0Class;

          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
          delete ptr;
        }
      actualList = result;
      break;
    case 69:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          // new value (predicate)
          *(newElement->state) = *(ptr->state);
          setBit( &(((stateFor_s0Class*)newElement->state)->predicate1[_faulty][0]), _l2, true );
          concatLists( (stateListClass*&)result, newElement );
          newElement = new stateListFor_s0Class;

          // new value (predicate)
          *(newElement->state) = *(ptr->state);
          setBit( &(((stateFor_s0Class*)newElement->state)->predicate1[_faulty][0]), _l2, false );
          concatLists( (stateListClass*&)result, newElement );
          newElement = new stateListFor_s0Class;

          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
          delete ptr;
        }
      actualList = result;
      break;
    case 70:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          // new value (predicate)
          *(newElement->state) = *(ptr->state);
          setBit( &(((stateFor_s0Class*)newElement->state)->predicate1[_faulty][0]), _l3, true );
          concatLists( (stateListClass*&)result, newElement );
          newElement = new stateListFor_s0Class;

          // new value (predicate)
          *(newElement->state) = *(ptr->state);
          setBit( &(((stateFor_s0Class*)newElement->state)->predicate1[_faulty][0]), _l3, false );
          concatLists( (stateListClass*&)result, newElement );
          newElement = new stateListFor_s0Class;

          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
          delete ptr;
        }
      actualList = result;
      break;
    case 71:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          // new value (predicate)
          *(newElement->state) = *(ptr->state);
          setBit( &(((stateFor_s0Class*)newElement->state)->predicate1[_faulty][0]), _l4, true );
          concatLists( (stateListClass*&)result, newElement );
          newElement = new stateListFor_s0Class;

          // new value (predicate)
          *(newElement->state) = *(ptr->state);
          setBit( &(((stateFor_s0Class*)newElement->state)->predicate1[_faulty][0]), _l4, false );
          concatLists( (stateListClass*&)result, newElement );
          newElement = new stateListFor_s0Class;

          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
          delete ptr;
        }
      actualList = result;
      break;
    case 72:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          // new value (predicate)
          *(newElement->state) = *(ptr->state);
          setBit( &(((stateFor_s0Class*)newElement->state)->predicate1[_faulty][0]), _l5, true );
          concatLists( (stateListClass*&)result, newElement );
          newElement = new stateListFor_s0Class;

          // new value (predicate)
          *(newElement->state) = *(ptr->state);
          setBit( &(((stateFor_s0Class*)newElement->state)->predicate1[_faulty][0]), _l5, false );
          concatLists( (stateListClass*&)result, newElement );
          newElement = new stateListFor_s0Class;

          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
          delete ptr;
        }
      actualList = result;
      break;
    case 73:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          // new value (predicate)
          *(newElement->state) = *(ptr->state);
          setBit( &(((stateFor_s0Class*)newElement->state)->predicate1[_faulty][0]), _l6, true );
          concatLists( (stateListClass*&)result, newElement );
          newElement = new stateListFor_s0Class;

          // new value (predicate)
          *(newElement->state) = *(ptr->state);
          setBit( &(((stateFor_s0Class*)newElement->state)->predicate1[_faulty][0]), _l6, false );
          concatLists( (stateListClass*&)result, newElement );
          newElement = new stateListFor_s0Class;

          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
          delete ptr;
        }
      actualList = result;
      break;
    case 74:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {
          // new value (predicate)
          *(newElement->state) = *(ptr->state);
          setBit( &(((stateFor_s0Class*)newElement->state)->predicate1[_faulty][0]), _l7, true );
          concatLists( (stateListClass*&)result, newElement );
          newElement = new stateListFor_s0Class;

          // new value (predicate)
          *(newElement->state) = *(ptr->state);
          setBit( &(((stateFor_s0Class*)newElement->state)->predicate1[_faulty][0]), _l7, false );
          concatLists( (stateListClass*&)result, newElement );
          newElement = new stateListFor_s0Class;

          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
          delete ptr;
        }
      actualList = result;
      break;
    case 76:
      for( ptr = actualList; ptr != NULL; ptr = tmp )
        {

          // check assertion
          if( !(((stateFor_s0Class*)ptr->state)->summation1( NULL ) == 0) )
            toBeRemoved.push_front( ptr );
          // next state
          tmp = (stateListFor_s0Class*)ptr->next;
        }
      break;
    }
  delete newElement;

  // clean actualList
  for( it = toBeRemoved.begin(); it != toBeRemoved.end(); ++it )
    removeElement( (stateListClass*&)actualList, *it );
}

stateListClass*
stateFor_s0Class::getInitialSituations( void )
{
  register int i;
  register stateListFor_s0Class *result, *ptr;

  // initialize
  result = new stateListFor_s0Class;
  // generate each field (pointer to list is passed by reference)
  for( i = 0; i < 77; ++i )
    generateField( i, result );

  // apply ramifications and count valid states
  for( ptr = result, i = 0; ptr != NULL; ptr = (stateListFor_s0Class*)ptr->next )
    {
      ptr->state->applyRamifications();
      i += ptr->state->valid;
    }

  // assign probabilities
  for( ptr = result; ptr != NULL; ptr = (stateListFor_s0Class*)ptr->next )
    ptr->probability = 1.0 / ((float)i);

  // return list of initial states
  return( result );
}

void
stateFor_s0Class::alloc( register int number, register stateClass **pool )
{
  register int i;
  register stateFor_s0Class *result;

  result = new stateFor_s0Class[number];
  for( i = 0; i < number; ++i )
    pool[i] = &result[i];
}

void
stateFor_s0Class::dealloc( register stateClass *pool )
{
  delete[] (stateFor_s0Class*)pool;
}

void
stateFor_s0Class::initialize( void )
{
}

void
stateFor_s0Class::applyRamifications( void )
{
  register void (**op)( stateFor_s0Class& );

  for( op = ramificationTable; *op != NULL; ++op )
    (**op)( *this );
}

bool
stateFor_s0Class::goal( void ) const
{
  return( (object[1/*_done*/] == true) );
}

stateListClass *
stateFor_s0Class::applyAllActions( void ) const
{
  register float mass;
  register stateListClass *resPtr, *tmp, *ptr;
  register stateListClass *(**op)( const stateFor_s0Class& );
  static stateListFor_s0Class result[23];

  resPtr = result;
  for( op = actionTable; *op != NULL; ++op )
    {
      // apply action
      tmp = (**op)( *this );

      // normalize probabilities
      for( mass = 0.0, ptr = tmp; ptr->probability != -1; ++ptr )
        mass += (ptr->state->valid ? ptr->probability : 0.0);
      for( ptr = tmp; ptr->probability != -1; ++ptr )
        ptr->probability /= mass;

      // store result
      for( ptr = tmp; ptr->probability != -1; ++ptr )
        {
          if( ptr->state->valid )
            {
              resPtr->action = ptr->action;
              resPtr->cost = ptr->cost;
              resPtr->probability = ptr->probability;
              *resPtr->state = *ptr->state;
              resPtr->observations = ptr->observations;
              ++resPtr;
            }
          else
            {
              delete[] ptr->observations;
            }
        }
    }
  // return
  resPtr->probability = -1;
  return( (stateListClass*)result );
}

void
stateFor_s0Class::print( ostream& os, int indent ) const
{
  register int i, *ip;
  register bool *bp;

  (os.width( indent ), os) << "";
  os << "object[1] = " << object[1] << endl;	// _done
  (os.width( indent ), os) << "";
  os << "object[0] = " << object[0] << endl;	// _need_wait

  // predicates of arity 1
  (os.width( indent ), os) << "";
  os << "predicate1[_closed] = { ";
  for( int i = 0; i < 1; ++i )
    {
      os << "[" << i << "]:";
      printBits( os, predicate1[_closed][i] );
      os << " ";
    }
  os << " }" << endl;
  (os.width( indent ), os) << "";
  os << "predicate1[_faulty] = { ";
  for( int i = 0; i < 1; ++i )
    {
      os << "[" << i << "]:";
      printBits( os, predicate1[_faulty][i] );
      os << " ";
    }
  os << " }" << endl;
}

bool
stateFor_s0Class::exists0( stateListFor_s0Class *ptr, int depth, ARforPredicate_con *current, int _v_sx, int _v_sy, int _v_x, int _v_y ) const
{
  return( false || ( bitValue( &(staticPredicate3[_ext][0]), ((_l1)*NUMOBJECTS + _v_x)*NUMOBJECTS + _v_sx ) && bitValue( &(staticPredicate3[_ext][0]), ((_l1)*NUMOBJECTS + _v_y)*NUMOBJECTS + _v_sy ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_l2)*NUMOBJECTS + _v_x)*NUMOBJECTS + _v_sx ) && bitValue( &(staticPredicate3[_ext][0]), ((_l2)*NUMOBJECTS + _v_y)*NUMOBJECTS + _v_sy ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_l3)*NUMOBJECTS + _v_x)*NUMOBJECTS + _v_sx ) && bitValue( &(staticPredicate3[_ext][0]), ((_l3)*NUMOBJECTS + _v_y)*NUMOBJECTS + _v_sy ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_l4)*NUMOBJECTS + _v_x)*NUMOBJECTS + _v_sx ) && bitValue( &(staticPredicate3[_ext][0]), ((_l4)*NUMOBJECTS + _v_y)*NUMOBJECTS + _v_sy ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_l5)*NUMOBJECTS + _v_x)*NUMOBJECTS + _v_sx ) && bitValue( &(staticPredicate3[_ext][0]), ((_l5)*NUMOBJECTS + _v_y)*NUMOBJECTS + _v_sy ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_l6)*NUMOBJECTS + _v_x)*NUMOBJECTS + _v_sx ) && bitValue( &(staticPredicate3[_ext][0]), ((_l6)*NUMOBJECTS + _v_y)*NUMOBJECTS + _v_sy ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_l7)*NUMOBJECTS + _v_x)*NUMOBJECTS + _v_sx ) && bitValue( &(staticPredicate3[_ext][0]), ((_l7)*NUMOBJECTS + _v_y)*NUMOBJECTS + _v_sy ) ) );
}

bool
stateFor_s0Class::exists2( stateListFor_s0Class *ptr, int depth, ARforPredicate_upstream *current, int _v_sx, int _v_sy, int _v_x, int _v_y ) const
{
  return( false || ( bitValue( &(predicate1[_closed][0]), _cb1 ) && exists1( NULL, depth, current, _cb1, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _cb2 ) && exists1( NULL, depth, current, _cb2, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _cb3 ) && exists1( NULL, depth, current, _cb3, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _sd1 ) && exists1( NULL, depth, current, _sd1, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _sd2 ) && exists1( NULL, depth, current, _sd2, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _sd3 ) && exists1( NULL, depth, current, _sd3, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _sd4 ) && exists1( NULL, depth, current, _sd4, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _sd5 ) && exists1( NULL, depth, current, _sd5, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _sd6 ) && exists1( NULL, depth, current, _sd6, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _sd7 ) && exists1( NULL, depth, current, _sd7, _v_sx, _v_sy, _v_x, _v_y ) ) );
}

bool
stateFor_s0Class::exists4( stateListFor_s0Class *ptr, int depth, ARforPredicate_upstream *current, int _v_sx, int _v_sy, int _v_x, int _v_y ) const
{
  return( false || ( bitValue( &(staticPredicate1[_breaker][0]), _cb1 ) && bitValue( &(predicate1[_closed][0]), _cb1 ) && exists3( NULL, depth, current, _cb1, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _cb2 ) && bitValue( &(predicate1[_closed][0]), _cb2 ) && exists3( NULL, depth, current, _cb2, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _cb3 ) && bitValue( &(predicate1[_closed][0]), _cb3 ) && exists3( NULL, depth, current, _cb3, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd1 ) && bitValue( &(predicate1[_closed][0]), _sd1 ) && exists3( NULL, depth, current, _sd1, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd2 ) && bitValue( &(predicate1[_closed][0]), _sd2 ) && exists3( NULL, depth, current, _sd2, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd3 ) && bitValue( &(predicate1[_closed][0]), _sd3 ) && exists3( NULL, depth, current, _sd3, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd4 ) && bitValue( &(predicate1[_closed][0]), _sd4 ) && exists3( NULL, depth, current, _sd4, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd5 ) && bitValue( &(predicate1[_closed][0]), _sd5 ) && exists3( NULL, depth, current, _sd5, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd6 ) && bitValue( &(predicate1[_closed][0]), _sd6 ) && exists3( NULL, depth, current, _sd6, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd7 ) && bitValue( &(predicate1[_closed][0]), _sd7 ) && exists3( NULL, depth, current, _sd7, _v_sx, _v_sy, _v_x, _v_y ) ) );
}

bool
stateFor_s0Class::exists6( stateListFor_s0Class *ptr, int depth, ARforPredicate_upstream *current, int _v_sx, int _v_sy, int _v_x, int _v_y ) const
{
  return( false || ( bitValue( &(predicate1[_closed][0]), _cb1 ) && exists5( NULL, depth, current, _cb1, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _cb2 ) && exists5( NULL, depth, current, _cb2, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _cb3 ) && exists5( NULL, depth, current, _cb3, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _sd1 ) && exists5( NULL, depth, current, _sd1, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _sd2 ) && exists5( NULL, depth, current, _sd2, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _sd3 ) && exists5( NULL, depth, current, _sd3, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _sd4 ) && exists5( NULL, depth, current, _sd4, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _sd5 ) && exists5( NULL, depth, current, _sd5, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _sd6 ) && exists5( NULL, depth, current, _sd6, _v_sx, _v_sy, _v_x, _v_y ) ) || ( bitValue( &(predicate1[_closed][0]), _sd7 ) && exists5( NULL, depth, current, _sd7, _v_sx, _v_sy, _v_x, _v_y ) ) );
}

bool
stateFor_s0Class::exists9( stateListFor_s0Class *ptr, int depth, ARforPredicate_fed *current, int _v_x ) const
{
  return( false || ( bitValue( &(staticPredicate1[_breaker][0]), _cb1 ) && exists8( NULL, depth, current, _cb1, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _cb2 ) && exists8( NULL, depth, current, _cb2, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _cb3 ) && exists8( NULL, depth, current, _cb3, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd1 ) && exists8( NULL, depth, current, _sd1, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd2 ) && exists8( NULL, depth, current, _sd2, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd3 ) && exists8( NULL, depth, current, _sd3, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd4 ) && exists8( NULL, depth, current, _sd4, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd5 ) && exists8( NULL, depth, current, _sd5, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd6 ) && exists8( NULL, depth, current, _sd6, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd7 ) && exists8( NULL, depth, current, _sd7, _v_x ) ) );
}

bool
stateFor_s0Class::exists17( stateListFor_s0Class *ptr, int depth, ARforPredicate_affected *current, int _v_x ) const
{
  return( false || ( bitValue( &(predicate1[_faulty][0]), _l1 ) && ( ( bitValue( &(staticPredicate1[_breaker][0]), _v_x ) && exists10( NULL, depth, current, _l1, _v_x ) ) || exists13( NULL, depth, current, _l1, _v_x ) || exists16( NULL, depth, current, _l1, _v_x ) ) ) || ( bitValue( &(predicate1[_faulty][0]), _l2 ) && ( ( bitValue( &(staticPredicate1[_breaker][0]), _v_x ) && exists10( NULL, depth, current, _l2, _v_x ) ) || exists13( NULL, depth, current, _l2, _v_x ) || exists16( NULL, depth, current, _l2, _v_x ) ) ) || ( bitValue( &(predicate1[_faulty][0]), _l3 ) && ( ( bitValue( &(staticPredicate1[_breaker][0]), _v_x ) && exists10( NULL, depth, current, _l3, _v_x ) ) || exists13( NULL, depth, current, _l3, _v_x ) || exists16( NULL, depth, current, _l3, _v_x ) ) ) || ( bitValue( &(predicate1[_faulty][0]), _l4 ) && ( ( bitValue( &(staticPredicate1[_breaker][0]), _v_x ) && exists10( NULL, depth, current, _l4, _v_x ) ) || exists13( NULL, depth, current, _l4, _v_x ) || exists16( NULL, depth, current, _l4, _v_x ) ) ) || ( bitValue( &(predicate1[_faulty][0]), _l5 ) && ( ( bitValue( &(staticPredicate1[_breaker][0]), _v_x ) && exists10( NULL, depth, current, _l5, _v_x ) ) || exists13( NULL, depth, current, _l5, _v_x ) || exists16( NULL, depth, current, _l5, _v_x ) ) ) || ( bitValue( &(predicate1[_faulty][0]), _l6 ) && ( ( bitValue( &(staticPredicate1[_breaker][0]), _v_x ) && exists10( NULL, depth, current, _l6, _v_x ) ) || exists13( NULL, depth, current, _l6, _v_x ) || exists16( NULL, depth, current, _l6, _v_x ) ) ) || ( bitValue( &(predicate1[_faulty][0]), _l7 ) && ( ( bitValue( &(staticPredicate1[_breaker][0]), _v_x ) && exists10( NULL, depth, current, _l7, _v_x ) ) || exists13( NULL, depth, current, _l7, _v_x ) || exists16( NULL, depth, current, _l7, _v_x ) ) ) );
}

bool
stateFor_s0Class::exists20( stateListFor_s0Class *ptr, int depth, ARforPredicate_closed_path *current, int _v_l, int _v_sx, int _v_x ) const
{
  return( false || ( !bitValue( &(predicate1[_faulty][0]), _l1 ) && bitValue( &(staticPredicate3[_ext][0]), ((_l1)*NUMOBJECTS + _v_x)*NUMOBJECTS + staticFunction1[_opposite][_v_sx] ) && exists19( NULL, depth, current, _l1, _v_l, _v_sx, _v_x ) ) || ( !bitValue( &(predicate1[_faulty][0]), _l2 ) && bitValue( &(staticPredicate3[_ext][0]), ((_l2)*NUMOBJECTS + _v_x)*NUMOBJECTS + staticFunction1[_opposite][_v_sx] ) && exists19( NULL, depth, current, _l2, _v_l, _v_sx, _v_x ) ) || ( !bitValue( &(predicate1[_faulty][0]), _l3 ) && bitValue( &(staticPredicate3[_ext][0]), ((_l3)*NUMOBJECTS + _v_x)*NUMOBJECTS + staticFunction1[_opposite][_v_sx] ) && exists19( NULL, depth, current, _l3, _v_l, _v_sx, _v_x ) ) || ( !bitValue( &(predicate1[_faulty][0]), _l4 ) && bitValue( &(staticPredicate3[_ext][0]), ((_l4)*NUMOBJECTS + _v_x)*NUMOBJECTS + staticFunction1[_opposite][_v_sx] ) && exists19( NULL, depth, current, _l4, _v_l, _v_sx, _v_x ) ) || ( !bitValue( &(predicate1[_faulty][0]), _l5 ) && bitValue( &(staticPredicate3[_ext][0]), ((_l5)*NUMOBJECTS + _v_x)*NUMOBJECTS + staticFunction1[_opposite][_v_sx] ) && exists19( NULL, depth, current, _l5, _v_l, _v_sx, _v_x ) ) || ( !bitValue( &(predicate1[_faulty][0]), _l6 ) && bitValue( &(staticPredicate3[_ext][0]), ((_l6)*NUMOBJECTS + _v_x)*NUMOBJECTS + staticFunction1[_opposite][_v_sx] ) && exists19( NULL, depth, current, _l6, _v_l, _v_sx, _v_x ) ) || ( !bitValue( &(predicate1[_faulty][0]), _l7 ) && bitValue( &(staticPredicate3[_ext][0]), ((_l7)*NUMOBJECTS + _v_x)*NUMOBJECTS + staticFunction1[_opposite][_v_sx] ) && exists19( NULL, depth, current, _l7, _v_l, _v_sx, _v_x ) ) );
}

bool
stateFor_s0Class::exists22( stateListFor_s0Class *ptr, int depth, ARforPredicate_fed_line *current, int _v_l ) const
{
  return( false || ( bitValue( &(staticPredicate1[_breaker][0]), _cb1 ) && bitValue( &(predicate1[_closed][0]), _cb1 ) && exists21( NULL, depth, current, _cb1, _v_l ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _cb2 ) && bitValue( &(predicate1[_closed][0]), _cb2 ) && exists21( NULL, depth, current, _cb2, _v_l ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _cb3 ) && bitValue( &(predicate1[_closed][0]), _cb3 ) && exists21( NULL, depth, current, _cb3, _v_l ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd1 ) && bitValue( &(predicate1[_closed][0]), _sd1 ) && exists21( NULL, depth, current, _sd1, _v_l ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd2 ) && bitValue( &(predicate1[_closed][0]), _sd2 ) && exists21( NULL, depth, current, _sd2, _v_l ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd3 ) && bitValue( &(predicate1[_closed][0]), _sd3 ) && exists21( NULL, depth, current, _sd3, _v_l ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd4 ) && bitValue( &(predicate1[_closed][0]), _sd4 ) && exists21( NULL, depth, current, _sd4, _v_l ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd5 ) && bitValue( &(predicate1[_closed][0]), _sd5 ) && exists21( NULL, depth, current, _sd5, _v_l ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd6 ) && bitValue( &(predicate1[_closed][0]), _sd6 ) && exists21( NULL, depth, current, _sd6, _v_l ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd7 ) && bitValue( &(predicate1[_closed][0]), _sd7 ) && exists21( NULL, depth, current, _sd7, _v_l ) ) );
}

bool
stateFor_s0Class::exists26( stateListFor_s0Class *ptr, int depth, ARforPredicate_bad *current, int _v_x ) const
{
  return( false || ( bitValue( &(staticPredicate1[_breaker][0]), _cb1 ) && exists23( NULL, depth, current, _cb1, _v_x ) && exists25( NULL, depth, current, _cb1, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _cb2 ) && exists23( NULL, depth, current, _cb2, _v_x ) && exists25( NULL, depth, current, _cb2, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _cb3 ) && exists23( NULL, depth, current, _cb3, _v_x ) && exists25( NULL, depth, current, _cb3, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd1 ) && exists23( NULL, depth, current, _sd1, _v_x ) && exists25( NULL, depth, current, _sd1, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd2 ) && exists23( NULL, depth, current, _sd2, _v_x ) && exists25( NULL, depth, current, _sd2, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd3 ) && exists23( NULL, depth, current, _sd3, _v_x ) && exists25( NULL, depth, current, _sd3, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd4 ) && exists23( NULL, depth, current, _sd4, _v_x ) && exists25( NULL, depth, current, _sd4, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd5 ) && exists23( NULL, depth, current, _sd5, _v_x ) && exists25( NULL, depth, current, _sd5, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd6 ) && exists23( NULL, depth, current, _sd6, _v_x ) && exists25( NULL, depth, current, _sd6, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd7 ) && exists23( NULL, depth, current, _sd7, _v_x ) && exists25( NULL, depth, current, _sd7, _v_x ) ) );
}

bool
stateFor_s0Class::exists30( stateListFor_s0Class *ptr, int depth, ARforPredicate_bad *current, int _v_x ) const
{
  return( false || exists29( NULL, depth, current, _side1, _v_x ) || exists29( NULL, depth, current, _side2, _v_x ) );
}

int
stateFor_s0Class::summation0( stateListFor_s0Class *ptr ) const
{
  return( 0 + (( bitValue( &(predicate1[_faulty][0]), _l1 ) || internalPredicate_fed_line( 0, NULL, false, _l1 ) )?0:5) + (( bitValue( &(predicate1[_faulty][0]), _l2 ) || internalPredicate_fed_line( 0, NULL, false, _l2 ) )?0:5) + (( bitValue( &(predicate1[_faulty][0]), _l3 ) || internalPredicate_fed_line( 0, NULL, false, _l3 ) )?0:5) + (( bitValue( &(predicate1[_faulty][0]), _l4 ) || internalPredicate_fed_line( 0, NULL, false, _l4 ) )?0:5) + (( bitValue( &(predicate1[_faulty][0]), _l5 ) || internalPredicate_fed_line( 0, NULL, false, _l5 ) )?0:5) + (( bitValue( &(predicate1[_faulty][0]), _l6 ) || internalPredicate_fed_line( 0, NULL, false, _l6 ) )?0:5) + (( bitValue( &(predicate1[_faulty][0]), _l7 ) || internalPredicate_fed_line( 0, NULL, false, _l7 ) )?0:5) );
}

int
stateFor_s0Class::summation1( stateListFor_s0Class *ptr ) const
{
  return( 0 + (bitValue( &(predicate1[_faulty][0]), _l1 )?1:0) + (bitValue( &(predicate1[_faulty][0]), _l2 )?1:0) + (bitValue( &(predicate1[_faulty][0]), _l3 )?1:0) + (bitValue( &(predicate1[_faulty][0]), _l4 )?1:0) + (bitValue( &(predicate1[_faulty][0]), _l5 )?1:0) + (bitValue( &(predicate1[_faulty][0]), _l6 )?1:0) + (bitValue( &(predicate1[_faulty][0]), _l7 )?1:0) );
}

bool
stateFor_s0Class::exists1( stateListFor_s0Class *ptr, int depth, ARforPredicate_upstream *current, int _v_z, int _v_sx, int _v_sy, int _v_x, int _v_y ) const
{
  return( false || ( internalPredicate_con( 0, NULL, false, _v_z, staticFunction1[_opposite][_side1], _v_y, _v_sy ) && internalPredicate_upstream( 1+depth, current, false, _v_x, _v_sx, _v_z, _side1 ) ) || ( internalPredicate_con( 0, NULL, false, _v_z, staticFunction1[_opposite][_side2], _v_y, _v_sy ) && internalPredicate_upstream( 1+depth, current, false, _v_x, _v_sx, _v_z, _side2 ) ) );
}

bool
stateFor_s0Class::exists3( stateListFor_s0Class *ptr, int depth, ARforPredicate_upstream *current, int _v_z, int _v_sx, int _v_sy, int _v_x, int _v_y ) const
{
  return( false || internalPredicate_upstream( 1+depth, current, false, _v_z, _side1, _v_x, _v_sx ) || internalPredicate_upstream( 1+depth, current, false, _v_z, _side2, _v_x, _v_sx ) );
}

bool
stateFor_s0Class::exists5( stateListFor_s0Class *ptr, int depth, ARforPredicate_upstream *current, int _v_u, int _v_sx, int _v_sy, int _v_x, int _v_y ) const
{
  return( false || ( internalPredicate_con( 0, NULL, false, _v_u, staticFunction1[_opposite][_side1], _v_y, _v_sy ) && internalPredicate_upstream( 1+depth, current, false, _v_x, _v_sx, _v_u, _side1 ) ) || ( internalPredicate_con( 0, NULL, false, _v_u, staticFunction1[_opposite][_side2], _v_y, _v_sy ) && internalPredicate_upstream( 1+depth, current, false, _v_x, _v_sx, _v_u, _side2 ) ) );
}

bool
stateFor_s0Class::exists8( stateListFor_s0Class *ptr, int depth, ARforPredicate_fed *current, int _v_y, int _v_x ) const
{
  return( false || exists7( NULL, depth, current, _side1, _v_y, _v_x ) || exists7( NULL, depth, current, _side2, _v_y, _v_x ) );
}

bool
stateFor_s0Class::exists10( stateListFor_s0Class *ptr, int depth, ARforPredicate_affected *current, int _v_l, int _v_x ) const
{
  return( false || bitValue( &(staticPredicate3[_ext][0]), ((_v_l)*NUMOBJECTS + _v_x)*NUMOBJECTS + _side1 ) || bitValue( &(staticPredicate3[_ext][0]), ((_v_l)*NUMOBJECTS + _v_x)*NUMOBJECTS + _side2 ) );
}

bool
stateFor_s0Class::exists13( stateListFor_s0Class *ptr, int depth, ARforPredicate_affected *current, int _v_l, int _v_x ) const
{
  return( false || ( bitValue( &(staticPredicate3[_ext][0]), ((_v_l)*NUMOBJECTS + _v_x)*NUMOBJECTS + staticFunction1[_opposite][_side1] ) && exists12( NULL, depth, current, _side1, _v_l, _v_x ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_v_l)*NUMOBJECTS + _v_x)*NUMOBJECTS + staticFunction1[_opposite][_side2] ) && exists12( NULL, depth, current, _side2, _v_l, _v_x ) ) );
}

bool
stateFor_s0Class::exists16( stateListFor_s0Class *ptr, int depth, ARforPredicate_affected *current, int _v_l, int _v_x ) const
{
  return( false || exists15( NULL, depth, current, _cb1, _v_l, _v_x ) || exists15( NULL, depth, current, _cb2, _v_l, _v_x ) || exists15( NULL, depth, current, _cb3, _v_l, _v_x ) || exists15( NULL, depth, current, _sd1, _v_l, _v_x ) || exists15( NULL, depth, current, _sd2, _v_l, _v_x ) || exists15( NULL, depth, current, _sd3, _v_l, _v_x ) || exists15( NULL, depth, current, _sd4, _v_l, _v_x ) || exists15( NULL, depth, current, _sd5, _v_l, _v_x ) || exists15( NULL, depth, current, _sd6, _v_l, _v_x ) || exists15( NULL, depth, current, _sd7, _v_l, _v_x ) );
}

bool
stateFor_s0Class::exists19( stateListFor_s0Class *ptr, int depth, ARforPredicate_closed_path *current, int _v_l2, int _v_l, int _v_sx, int _v_x ) const
{
  return( false || ( !(_v_x == _cb1) && bitValue( &(predicate1[_closed][0]), _cb1 ) && exists18( NULL, depth, current, _cb1, _v_l2, _v_l, _v_sx, _v_x ) ) || ( !(_v_x == _cb2) && bitValue( &(predicate1[_closed][0]), _cb2 ) && exists18( NULL, depth, current, _cb2, _v_l2, _v_l, _v_sx, _v_x ) ) || ( !(_v_x == _cb3) && bitValue( &(predicate1[_closed][0]), _cb3 ) && exists18( NULL, depth, current, _cb3, _v_l2, _v_l, _v_sx, _v_x ) ) || ( !(_v_x == _sd1) && bitValue( &(predicate1[_closed][0]), _sd1 ) && exists18( NULL, depth, current, _sd1, _v_l2, _v_l, _v_sx, _v_x ) ) || ( !(_v_x == _sd2) && bitValue( &(predicate1[_closed][0]), _sd2 ) && exists18( NULL, depth, current, _sd2, _v_l2, _v_l, _v_sx, _v_x ) ) || ( !(_v_x == _sd3) && bitValue( &(predicate1[_closed][0]), _sd3 ) && exists18( NULL, depth, current, _sd3, _v_l2, _v_l, _v_sx, _v_x ) ) || ( !(_v_x == _sd4) && bitValue( &(predicate1[_closed][0]), _sd4 ) && exists18( NULL, depth, current, _sd4, _v_l2, _v_l, _v_sx, _v_x ) ) || ( !(_v_x == _sd5) && bitValue( &(predicate1[_closed][0]), _sd5 ) && exists18( NULL, depth, current, _sd5, _v_l2, _v_l, _v_sx, _v_x ) ) || ( !(_v_x == _sd6) && bitValue( &(predicate1[_closed][0]), _sd6 ) && exists18( NULL, depth, current, _sd6, _v_l2, _v_l, _v_sx, _v_x ) ) || ( !(_v_x == _sd7) && bitValue( &(predicate1[_closed][0]), _sd7 ) && exists18( NULL, depth, current, _sd7, _v_l2, _v_l, _v_sx, _v_x ) ) );
}

bool
stateFor_s0Class::exists21( stateListFor_s0Class *ptr, int depth, ARforPredicate_fed_line *current, int _v_x, int _v_l ) const
{
  return( false || internalPredicate_closed_path( 0, NULL, false, _v_x, _side1, _v_l ) || internalPredicate_closed_path( 0, NULL, false, _v_x, _side2, _v_l ) );
}

bool
stateFor_s0Class::exists23( stateListFor_s0Class *ptr, int depth, ARforPredicate_bad *current, int _v_y, int _v_x ) const
{
  return( false || internalPredicate_upstream( 0, NULL, false, _v_y, _side1, _v_x, _side1 ) || internalPredicate_upstream( 0, NULL, false, _v_y, _side2, _v_x, _side1 ) );
}

bool
stateFor_s0Class::exists25( stateListFor_s0Class *ptr, int depth, ARforPredicate_bad *current, int _v_y, int _v_x ) const
{
  return( false || ( bitValue( &(staticPredicate1[_breaker][0]), _cb1 ) && exists24( NULL, depth, current, _cb1, _v_y, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _cb2 ) && exists24( NULL, depth, current, _cb2, _v_y, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _cb3 ) && exists24( NULL, depth, current, _cb3, _v_y, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd1 ) && exists24( NULL, depth, current, _sd1, _v_y, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd2 ) && exists24( NULL, depth, current, _sd2, _v_y, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd3 ) && exists24( NULL, depth, current, _sd3, _v_y, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd4 ) && exists24( NULL, depth, current, _sd4, _v_y, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd5 ) && exists24( NULL, depth, current, _sd5, _v_y, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd6 ) && exists24( NULL, depth, current, _sd6, _v_y, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd7 ) && exists24( NULL, depth, current, _sd7, _v_y, _v_x ) ) );
}

bool
stateFor_s0Class::exists29( stateListFor_s0Class *ptr, int depth, ARforPredicate_bad *current, int _v_sx, int _v_x ) const
{
  return( false || ( bitValue( &(staticPredicate3[_ext][0]), ((_l1)*NUMOBJECTS + _v_x)*NUMOBJECTS + _v_sx ) && exists28( NULL, depth, current, _l1, _v_sx, _v_x ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_l2)*NUMOBJECTS + _v_x)*NUMOBJECTS + _v_sx ) && exists28( NULL, depth, current, _l2, _v_sx, _v_x ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_l3)*NUMOBJECTS + _v_x)*NUMOBJECTS + _v_sx ) && exists28( NULL, depth, current, _l3, _v_sx, _v_x ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_l4)*NUMOBJECTS + _v_x)*NUMOBJECTS + _v_sx ) && exists28( NULL, depth, current, _l4, _v_sx, _v_x ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_l5)*NUMOBJECTS + _v_x)*NUMOBJECTS + _v_sx ) && exists28( NULL, depth, current, _l5, _v_sx, _v_x ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_l6)*NUMOBJECTS + _v_x)*NUMOBJECTS + _v_sx ) && exists28( NULL, depth, current, _l6, _v_sx, _v_x ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_l7)*NUMOBJECTS + _v_x)*NUMOBJECTS + _v_sx ) && exists28( NULL, depth, current, _l7, _v_sx, _v_x ) ) );
}

bool
stateFor_s0Class::exists7( stateListFor_s0Class *ptr, int depth, ARforPredicate_fed *current, int _v_sy, int _v_y, int _v_x ) const
{
  return( false || internalPredicate_upstream( 0, NULL, false, _v_y, _v_sy, _v_x, _side1 ) || internalPredicate_upstream( 0, NULL, false, _v_y, _v_sy, _v_x, _side2 ) );
}

bool
stateFor_s0Class::exists12( stateListFor_s0Class *ptr, int depth, ARforPredicate_affected *current, int _v_sx, int _v_l, int _v_x ) const
{
  return( false || ( bitValue( &(staticPredicate1[_breaker][0]), _cb1 ) && bitValue( &(predicate1[_closed][0]), _cb1 ) && exists11( NULL, depth, current, _cb1, _v_sx, _v_l, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _cb2 ) && bitValue( &(predicate1[_closed][0]), _cb2 ) && exists11( NULL, depth, current, _cb2, _v_sx, _v_l, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _cb3 ) && bitValue( &(predicate1[_closed][0]), _cb3 ) && exists11( NULL, depth, current, _cb3, _v_sx, _v_l, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd1 ) && bitValue( &(predicate1[_closed][0]), _sd1 ) && exists11( NULL, depth, current, _sd1, _v_sx, _v_l, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd2 ) && bitValue( &(predicate1[_closed][0]), _sd2 ) && exists11( NULL, depth, current, _sd2, _v_sx, _v_l, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd3 ) && bitValue( &(predicate1[_closed][0]), _sd3 ) && exists11( NULL, depth, current, _sd3, _v_sx, _v_l, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd4 ) && bitValue( &(predicate1[_closed][0]), _sd4 ) && exists11( NULL, depth, current, _sd4, _v_sx, _v_l, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd5 ) && bitValue( &(predicate1[_closed][0]), _sd5 ) && exists11( NULL, depth, current, _sd5, _v_sx, _v_l, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd6 ) && bitValue( &(predicate1[_closed][0]), _sd6 ) && exists11( NULL, depth, current, _sd6, _v_sx, _v_l, _v_x ) ) || ( bitValue( &(staticPredicate1[_breaker][0]), _sd7 ) && bitValue( &(predicate1[_closed][0]), _sd7 ) && exists11( NULL, depth, current, _sd7, _v_sx, _v_l, _v_x ) ) );
}

bool
stateFor_s0Class::exists15( stateListFor_s0Class *ptr, int depth, ARforPredicate_affected *current, int _v_y, int _v_l, int _v_x ) const
{
  return( false || ( bitValue( &(staticPredicate3[_ext][0]), ((_v_l)*NUMOBJECTS + _v_y)*NUMOBJECTS + staticFunction1[_opposite][_side1] ) && bitValue( &(predicate1[_closed][0]), _v_y ) && exists14( NULL, depth, current, _side1, _v_y, _v_l, _v_x ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_v_l)*NUMOBJECTS + _v_y)*NUMOBJECTS + staticFunction1[_opposite][_side2] ) && bitValue( &(predicate1[_closed][0]), _v_y ) && exists14( NULL, depth, current, _side2, _v_y, _v_l, _v_x ) ) );
}

bool
stateFor_s0Class::exists18( stateListFor_s0Class *ptr, int depth, ARforPredicate_closed_path *current, int _v_z, int _v_l2, int _v_l, int _v_sx, int _v_x ) const
{
  return( false || ( bitValue( &(staticPredicate3[_ext][0]), ((_v_l2)*NUMOBJECTS + _v_z)*NUMOBJECTS + _side1 ) && internalPredicate_closed_path( 1+depth, current, false, _v_z, _side1, _v_l ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_v_l2)*NUMOBJECTS + _v_z)*NUMOBJECTS + _side2 ) && internalPredicate_closed_path( 1+depth, current, false, _v_z, _side2, _v_l ) ) );
}

bool
stateFor_s0Class::exists24( stateListFor_s0Class *ptr, int depth, ARforPredicate_bad *current, int _v_z, int _v_y, int _v_x ) const
{
  return( false || internalPredicate_upstream( 0, NULL, false, _v_z, _side1, _v_x, _side2 ) || internalPredicate_upstream( 0, NULL, false, _v_z, _side2, _v_x, _side2 ) );
}

bool
stateFor_s0Class::exists28( stateListFor_s0Class *ptr, int depth, ARforPredicate_bad *current, int _v_l, int _v_sx, int _v_x ) const
{
  return( false || exists27( NULL, depth, current, _cb1, _v_l, _v_sx, _v_x ) || exists27( NULL, depth, current, _cb2, _v_l, _v_sx, _v_x ) || exists27( NULL, depth, current, _cb3, _v_l, _v_sx, _v_x ) || exists27( NULL, depth, current, _sd1, _v_l, _v_sx, _v_x ) || exists27( NULL, depth, current, _sd2, _v_l, _v_sx, _v_x ) || exists27( NULL, depth, current, _sd3, _v_l, _v_sx, _v_x ) || exists27( NULL, depth, current, _sd4, _v_l, _v_sx, _v_x ) || exists27( NULL, depth, current, _sd5, _v_l, _v_sx, _v_x ) || exists27( NULL, depth, current, _sd6, _v_l, _v_sx, _v_x ) || exists27( NULL, depth, current, _sd7, _v_l, _v_sx, _v_x ) );
}

bool
stateFor_s0Class::exists11( stateListFor_s0Class *ptr, int depth, ARforPredicate_affected *current, int _v_y, int _v_sx, int _v_l, int _v_x ) const
{
  return( false || internalPredicate_upstream( 0, NULL, false, _v_y, _side1, _v_x, _v_sx ) || internalPredicate_upstream( 0, NULL, false, _v_y, _side2, _v_x, _v_sx ) );
}

bool
stateFor_s0Class::exists14( stateListFor_s0Class *ptr, int depth, ARforPredicate_affected *current, int _v_sy, int _v_y, int _v_l, int _v_x ) const
{
  return( false || internalPredicate_upstream( 0, NULL, false, _v_x, _side1, _v_y, _v_sy ) || internalPredicate_upstream( 0, NULL, false, _v_x, _side2, _v_y, _v_sy ) );
}

bool
stateFor_s0Class::exists27( stateListFor_s0Class *ptr, int depth, ARforPredicate_bad *current, int _v_y, int _v_l, int _v_sx, int _v_x ) const
{
  return( false || ( bitValue( &(staticPredicate3[_ext][0]), ((_v_l)*NUMOBJECTS + _v_y)*NUMOBJECTS + _side1 ) && internalPredicate_closed_path( 0, NULL, false, _v_y, _side1, _v_l ) ) || ( bitValue( &(staticPredicate3[_ext][0]), ((_v_l)*NUMOBJECTS + _v_y)*NUMOBJECTS + _side2 ) && internalPredicate_closed_path( 0, NULL, false, _v_y, _side2, _v_l ) ) );
}

const stateClass::node_t*
stateFor_s0Class::lookup( const node_t *node ) const
{
  int value;
  node_t **ch;
  switch( node->depth )
    {
    case 0:
      value = object[0];
      break;
    case 1:
      value = object[1];
      break;
    case 2:
      value = predicate1[0][0];
      break;
    case 3:
      value = predicate1[1][0];
      break;
    case 4:
      return( node );
      break;
    default:
      cerr << "ERROR: bad depth index " << node->depth << "." << endl;
      return( NULL );
      break;
    }

  if( !node->children )
    return( NULL );
  else
    {
      for( ch = node->children; *ch != NULL; ++ch )
        if( (*ch)->value == value )
          return( lookup( *ch ) );
      return( NULL );
    }
}

const stateClass::node_t*
stateFor_s0Class::insert( node_t *node, int index ) const
{
  int n, value;
  node_t **ch;
  switch( node->depth )
    {
    case 0:
      value = object[0];
      break;
    case 1:
      value = object[1];
      break;
    case 2:
      value = predicate1[0][0];
      break;
    case 3:
      value = predicate1[1][0];
      break;
    case 4:
      node->children = (node_t**)index;
      return( node );
      break;
    default:
      cerr << "ERROR: bad depth index " << node->depth << "." << endl;
      return( NULL );
      break;
    }

  if( !node->children )
    {
      node->children = (node_t**)malloc( 1 * sizeof( node_t* ) );
      node->children[0] = NULL;
    }

  for( ch = node->children, n = 0; *ch != NULL; ++ch, ++n )
    if( (*ch)->value == value )
      return( insert( *ch, index ) );
  if( *ch == NULL )
    {
      node->children = (node_t**)realloc( node->children, (2+n) * sizeof( node_t* ) );
      node->children[n+1] = NULL;
      node->children[n] = new node_t;
      node->children[n]->value = value;
      node->children[n]->depth = 1 + node->depth;
      node->children[n]->parent = node;
      return( insert( node->children[n], index ) );
    }
}

void
stateFor_s0Class::recover( const node_t *node )
{
  switch( node->depth - 1 )
    {
    case 0:
      object[0] = node->value;
      break;
    case 1:
      object[1] = node->value;
      break;
    case 2:
      predicate1[0][0] = node->value;
      break;
    case 3:
      predicate1[1][0] = node->value;
      break;
    case 4:
      break;
    default:
      cerr << "ERROR: bad depth index " << node->depth << "." << endl;
      break;
    }

}

problemHandleClass *
problemRegister( void )
{
  problemHandleClass *handle;

  stateFor_s0Class::fillTables();
  handle = new problemHandleClass;
  handle->problemType = problemHandleClass::PROBLEM_POMDP1;
  handle->hookType = 0;
  handle->numActions = stateFor_s0Class::numActions;
  handle->stateSize = sizeof( stateFor_s0Class );
  handle->observationSize = sizeof( observationFor_s0Class );
  handle->theNullObservation = new observationFor_s0Class;
  handle->bootstrap = &stateFor_s0Class::bootstrap;
  handle->cleanUp = &stateFor_s0Class::cleanUp;
  handle->printAction = &stateFor_s0Class::printAction;
  handle->stateAllocFunction = &stateFor_s0Class::alloc;
  handle->stateDeallocFunction = &stateFor_s0Class::dealloc;
  handle->initializeFunction = &stateFor_s0Class::initialize;
  handle->otherInfo = 0;
  handle->modelHook = NULL;
  handle->beliefHook = NULL;
  handle->heuristicHook = NULL;
  return( handle );
}

