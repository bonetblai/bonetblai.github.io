#include <iostream>
#include <stdio.h>

using namespace std;
#include <theseus/theRtStandard.h>

// object labels
#define _need_wait          0
#define _done               1
#define _l1                 2
#define _l2                 3
#define _l3                 4
#define _l4                 5
#define _l5                 6
#define _l6                 7
#define _l7                 8
#define _ok                 9
#define _out                10
#define _liar               11
#define _side1              12
#define _side2              13
#define _cb1                14
#define _cb2                15
#define _cb3                16
#define _sd1                17
#define _sd2                18
#define _sd3                19
#define _sd4                20
#define _sd5                21
#define _sd6                22
#define _sd7                23

#define NUMOBJECTS          24

// labels for functions of arity 1
#define _ac_mode            0	// static
#define _fd_mode            1	// static
#define _opposite           2	// static

// labels for predicates of arity 1
#define _breaker            0	// static
#define _closed             0	// non-static
#define _faulty             1	// non-static
#define _pd_ok              1	// static

// labels for predicates of arity 3
#define _ext                0	// static



// forward references
class stateFor_s0Class;
class stateListFor_s0Class;
class observationFor_s0Class;
class observationListFor_s0Class;


class stateFor_s0Class : public stateClass
{
public:
  // objects
  int                      object[2];

  // static functions 1 argument(s)
  static int               staticFunction1[3][24];

  // predicates 1 argument(s)
  unsigned                 predicate1[2][1];

  // static predicates 1 argument(s)
  static unsigned          staticPredicate1[2][1];

  // static predicates 3 argument(s)
  static unsigned          staticPredicate3[1][432];

  // basics methods
                           stateFor_s0Class();
  virtual                  ~stateFor_s0Class();
  virtual stateClass&      operator=( register const stateClass& s );
  virtual stateClass&      operator=( register const stateFor_s0Class& s );
  virtual bool             operator==( register const stateClass& s ) const;
  virtual bool             operator==( register const stateFor_s0Class& s ) const;
  virtual stateClass*      clone( void ) const;

  // static members and methods
  static int               numActions;
  static const char**      actionName;
  static void              (**ramificationTable)( stateFor_s0Class& );
  static stateListClass*   (**actionTable)( const stateFor_s0Class& );
  static void              fillTables( void );
  static void              cleanUp( void );
  static stateListClass*   bootstrap( void );
  static void              printAction( ostream& os, int action );
  static void              generateField( int idx, stateListFor_s0Class *&list );
  static stateListClass*   getInitialSituations( void );
  static void              alloc( register int number, register stateClass **pool );
  static void              dealloc( register stateClass *pool );
  static void              initialize( void );

  // virtual methods
  virtual void             applyRamifications( void );
  virtual bool             goal( void ) const;
  virtual stateListClass*  applyAllActions( void ) const;
  virtual void             print( ostream& os, int indent ) const;
  virtual const stateClass::node_t*lookup( const node_t *node ) const;
  virtual const stateClass::node_t*insert( node_t *node, int index ) const;
  virtual void             recover( const node_t *node );

  // Activation Records
  struct ARforPredicate_con {
    int _v_x;
    int _v_sx;
    int _v_y;
    int _v_sy;
    struct ARforPredicate_con *prev;
  };
  struct ARforPredicate_upstream {
    int _v_x;
    int _v_sx;
    int _v_y;
    int _v_sy;
    struct ARforPredicate_upstream *prev;
  };
  struct ARforPredicate_fed {
    int _v_x;
    struct ARforPredicate_fed *prev;
  };
  struct ARforPredicate_affected {
    int _v_x;
    struct ARforPredicate_affected *prev;
  };
  struct ARforPredicate_closed_path {
    int _v_x;
    int _v_sx;
    int _v_l;
    struct ARforPredicate_closed_path *prev;
  };
  struct ARforPredicate_fed_line {
    int _v_l;
    struct ARforPredicate_fed_line *prev;
  };
  struct ARforPredicate_bad {
    int _v_x;
    struct ARforPredicate_bad *prev;
  };

  // methods
  void ramificationCode_open_ramification( register int _v_x );
  bool internalPredicate_con( int depth, ARforPredicate_con *AR, bool defVal, register int _v_x, register int _v_sx, register int _v_y, register int _v_sy ) const;
  bool internalPredicate_upstream( int depth, ARforPredicate_upstream *AR, bool defVal, register int _v_x, register int _v_sx, register int _v_y, register int _v_sy ) const;
  bool internalPredicate_fed( int depth, ARforPredicate_fed *AR, bool defVal, register int _v_x ) const;
  bool internalPredicate_affected( int depth, ARforPredicate_affected *AR, bool defVal, register int _v_x ) const;
  bool internalPredicate_closed_path( int depth, ARforPredicate_closed_path *AR, bool defVal, register int _v_x, register int _v_sx, register int _v_l ) const;
  bool internalPredicate_fed_line( int depth, ARforPredicate_fed_line *AR, bool defVal, register int _v_l ) const;
  bool internalPredicate_bad( int depth, ARforPredicate_bad *AR, bool defVal, register int _v_x ) const;
  float costAfter_wait( void ) const;
  stateListFor_s0Class* statesAfter_wait( register int opId ) const;
  observationListFor_s0Class* observationsAfter_wait( void ) const;
  float costAfter_finish( void ) const;
  stateListFor_s0Class* statesAfter_finish( register int opId ) const;
  observationListFor_s0Class* observationsAfter_finish( void ) const;
  float costAfter_close( register int _v_x ) const;
  stateListFor_s0Class* statesAfter_close( register int opId, register int _v_x ) const;
  observationListFor_s0Class* observationsAfter_close( register int _v_x ) const;
  float costAfter_open( register int _v_x ) const;
  stateListFor_s0Class* statesAfter_open( register int opId, register int _v_x ) const;
  observationListFor_s0Class* observationsAfter_open( register int _v_x ) const;

  bool  exists30( stateListFor_s0Class* ptr, int depth, ARforPredicate_bad *AR, int _v_x ) const;
  bool  exists29( stateListFor_s0Class* ptr, int depth, ARforPredicate_bad *AR, int _v_sx, int _v_x ) const;
  bool  exists28( stateListFor_s0Class* ptr, int depth, ARforPredicate_bad *AR, int _v_l, int _v_sx, int _v_x ) const;
  bool  exists27( stateListFor_s0Class* ptr, int depth, ARforPredicate_bad *AR, int _v_y, int _v_l, int _v_sx, int _v_x ) const;
  bool  exists26( stateListFor_s0Class* ptr, int depth, ARforPredicate_bad *AR, int _v_x ) const;
  bool  exists25( stateListFor_s0Class* ptr, int depth, ARforPredicate_bad *AR, int _v_y, int _v_x ) const;
  bool  exists24( stateListFor_s0Class* ptr, int depth, ARforPredicate_bad *AR, int _v_z, int _v_y, int _v_x ) const;
  bool  exists23( stateListFor_s0Class* ptr, int depth, ARforPredicate_bad *AR, int _v_y, int _v_x ) const;
  bool  exists22( stateListFor_s0Class* ptr, int depth, ARforPredicate_fed_line *AR, int _v_l ) const;
  bool  exists21( stateListFor_s0Class* ptr, int depth, ARforPredicate_fed_line *AR, int _v_x, int _v_l ) const;
  bool  exists20( stateListFor_s0Class* ptr, int depth, ARforPredicate_closed_path *AR, int _v_l, int _v_sx, int _v_x ) const;
  bool  exists19( stateListFor_s0Class* ptr, int depth, ARforPredicate_closed_path *AR, int _v_l2, int _v_l, int _v_sx, int _v_x ) const;
  bool  exists18( stateListFor_s0Class* ptr, int depth, ARforPredicate_closed_path *AR, int _v_z, int _v_l2, int _v_l, int _v_sx, int _v_x ) const;
  bool  exists17( stateListFor_s0Class* ptr, int depth, ARforPredicate_affected *AR, int _v_x ) const;
  bool  exists16( stateListFor_s0Class* ptr, int depth, ARforPredicate_affected *AR, int _v_l, int _v_x ) const;
  bool  exists15( stateListFor_s0Class* ptr, int depth, ARforPredicate_affected *AR, int _v_y, int _v_l, int _v_x ) const;
  bool  exists14( stateListFor_s0Class* ptr, int depth, ARforPredicate_affected *AR, int _v_sy, int _v_y, int _v_l, int _v_x ) const;
  bool  exists13( stateListFor_s0Class* ptr, int depth, ARforPredicate_affected *AR, int _v_l, int _v_x ) const;
  bool  exists12( stateListFor_s0Class* ptr, int depth, ARforPredicate_affected *AR, int _v_sx, int _v_l, int _v_x ) const;
  bool  exists11( stateListFor_s0Class* ptr, int depth, ARforPredicate_affected *AR, int _v_y, int _v_sx, int _v_l, int _v_x ) const;
  bool  exists10( stateListFor_s0Class* ptr, int depth, ARforPredicate_affected *AR, int _v_l, int _v_x ) const;
  bool  exists9( stateListFor_s0Class* ptr, int depth, ARforPredicate_fed *AR, int _v_x ) const;
  bool  exists8( stateListFor_s0Class* ptr, int depth, ARforPredicate_fed *AR, int _v_y, int _v_x ) const;
  bool  exists7( stateListFor_s0Class* ptr, int depth, ARforPredicate_fed *AR, int _v_sy, int _v_y, int _v_x ) const;
  bool  exists6( stateListFor_s0Class* ptr, int depth, ARforPredicate_upstream *AR, int _v_sx, int _v_sy, int _v_x, int _v_y ) const;
  bool  exists5( stateListFor_s0Class* ptr, int depth, ARforPredicate_upstream *AR, int _v_u, int _v_sx, int _v_sy, int _v_x, int _v_y ) const;
  bool  exists4( stateListFor_s0Class* ptr, int depth, ARforPredicate_upstream *AR, int _v_sx, int _v_sy, int _v_x, int _v_y ) const;
  bool  exists3( stateListFor_s0Class* ptr, int depth, ARforPredicate_upstream *AR, int _v_z, int _v_sx, int _v_sy, int _v_x, int _v_y ) const;
  bool  exists2( stateListFor_s0Class* ptr, int depth, ARforPredicate_upstream *AR, int _v_sx, int _v_sy, int _v_x, int _v_y ) const;
  bool  exists1( stateListFor_s0Class* ptr, int depth, ARforPredicate_upstream *AR, int _v_z, int _v_sx, int _v_sy, int _v_x, int _v_y ) const;
  bool  exists0( stateListFor_s0Class* ptr, int depth, ARforPredicate_con *AR, int _v_sx, int _v_sy, int _v_x, int _v_y ) const;
  int  summation1( stateListFor_s0Class *ptr ) const;
  int  summation0( stateListFor_s0Class *ptr ) const;
};

class stateListFor_s0Class : public stateListClass
{
public:
  stateListFor_s0Class();
  virtual stateListClass* alloc( register int size );
};

class observationFor_s0Class : public observationClass
{
public:
  int obs[21+1];
  static int observationSize;

  observationFor_s0Class();
  virtual observationClass&     operator=( register const observationClass& o );
  virtual observationClass&     operator=( register const observationFor_s0Class& o );
  virtual bool                  operator==( register const observationClass& o ) const;
  virtual bool                  operator==( register const observationFor_s0Class& o ) const;

  virtual void                  setValue( register int offset, register int value );
  virtual observationClass*     clone( void ) const;
  virtual void                  print( ostream& os, int indent ) const;
};

class observationListFor_s0Class : public observationListClass
{
public:
  observationListFor_s0Class();
  ~observationListFor_s0Class();
  virtual void print( ostream& os, int indent ) const;
};

