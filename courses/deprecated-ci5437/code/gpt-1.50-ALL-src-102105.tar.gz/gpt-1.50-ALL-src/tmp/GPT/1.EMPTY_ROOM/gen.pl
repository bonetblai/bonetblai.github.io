#! /usr/bin/perl

# 3 4 5 6 7 8 9 10 12 14 16 18 20 22 24 26 28 30 32 34 36 38 40 42 44 46 48 50;

my $size = $ARGV[0];
my $maxx = $size - 1;
my $maxy = $maxx;
my $goalx = int($maxx / 2);
my $goaly = $goalx;

print "
(define (problem p${size})
  (:domain emptyroom)
  (:init (:set maxx ${maxx})
         (:set maxy ${maxy})
";
print "
         (:set posx :in {";

for ($i = 0; $i <= ${maxx}; $i++) {
   print " $i";
}

print " })
";
print "
         (:set posy :in {";
for ($i = 0; $i <= ${maxy}; $i++) {
   print " $i";
}
print " }))";
  print "
         (:goal (:and (= posx ${goalx}) (= posy ${goaly}))))\n\n";
