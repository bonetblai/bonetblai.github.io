#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int seed = 13;       /* seed for random number generator */
int width = 21;      /* has to be odd */
int height = 21;     /* has to be odd */
int removals = 10;   /* walls to be removed */

int forwardx[4]  = { -1,  1,  0,  0 };
int forwardy[4]  = {  0,  0, -1,  1 };
int reverse[4]   = {  1,  0,  3,  2 }; 

int startx, starty;
int goalx, goaly;

int **maze;

int stacksize;
int **stack;

void error(char *string)
{
  printf("error: %s\n", string);
  exit(1);
}

void print_walls (FILE * file)
{
  int x,y;

  fprintf(file, "\nint _no_walls (const stateClass&, int x, int y)
{
  return
(");
  for (y=0; y<height; ++y) {
    fprintf(file, "\n// row %d\n", y);
    for (x=0; x<width; ++x) {
      if ((maze[x][y] == -1)) {
        fprintf(file, "0 ||\n");
      }
      else {
        fprintf(file, "(x == %d && y == %d) ||\n", x, y);
      }
    }
  }
  fprintf(file, "// no more rows for no_walls\n0\n);
}\n");

  fprintf(file, "\nint _wall_left (const stateClass&, int x, int y)
{
  return
(");
  for (y=0; y<height; ++y) {
    fprintf(file, "\n// row %d\n", y);
    for (x=0; x<width; ++x)
      {
	if ((maze[x][y] != -1) && ((x == 0) || (maze[x-1][y] == -1))) {
	  fprintf(file, "(x == %d && y == %d) ||\n", x, y);
	}
	else {
	  fprintf(file, "0 ||\n");
	}
      }
  }
  fprintf(file, "// no more rows for wall_left\n0\n);
}\n");

  fprintf(file, "\nint _wall_right (const stateClass&, int x, int y)
{
  return
(");
  for (y=0; y<height; ++y) {
    fprintf(file, "\n// row %d\n", y);
    for (x=0; x<width; ++x)
      {
	if ((maze[x][y] != -1) && ((x == width-1) || (maze[x+1][y] == -1))) {
	  fprintf(file, "(x == %d && y == %d) |\n", x, y);
	}
	else {
	  fprintf(file, "0 |\n");
	}
      }
  }
  fprintf(file, "// no more rows for wall_right\n0\n);
}\n");

  fprintf(file, "\nint _wall_up (const stateClass&, int x, int y)
{
  return
(");
  for (y=0; y<height; ++y) {
    fprintf(file, "\n// row %d\n", y);
    for (x=0; x<width; ++x)
      {
	if ((maze[x][y] != -1) && ((y == 0) || (maze[x][y-1] == -1))) {
	  fprintf(file, "(x == %d && y == %d) ||\n", x, y);
	}
	else {
	  fprintf(file, "0 ||\n");
	}
      }
  }
  fprintf(file, "// no more rows for wall_up\n0\n);
}\n");


  fprintf(file, "\nint _wall_down (const stateClass&, int x, int y)
{
  return
(");
  for (y=0; y<height; ++y) {
    fprintf(file, "\n// row %d\n", y);
    for (x=0; x<width; ++x)
      {
	if ((maze[x][y] != -1) && ((y == height-1) || (maze[x][y+1] == -1))) {
	  fprintf(file, "(x == %d && y == %d) ||\n", x, y);
	}
	else {
	  fprintf(file, "0 ||\n");
	}
      }
  }
  fprintf(file, "// no more rows for wall_down\n0\n);
}\n");

}

void print_cfile(const char * fname, int h, int w) {

  FILE * file = fopen(fname, "w");

  fprintf(file, "#include <iostream.h>
#include <theseus/theRtStandard.h>


int
_up( const stateClass&, int y )
{
  return ( ( y - 1 ) %% %d);
}

int
_down( const stateClass&, int y )
{
  return ( ( y + 1 ) %% %d);
}

int
_left( const stateClass&, int x )
{
  return ( ( x - 1 ) %% %d);
}

int
_right( const stateClass&, int x )
{
  return ( ( x + 1 ) %% %d);
}
", w, w, h, h);
  print_walls(file);
}

int main(int argc, char **argv)
{
  int i;
  int x, y;
  int dx, dy;
  int direction;
  int directions;
  int randomstartgoal;
  char *filename, *endpointer;
  char *cfilename;
  FILE *file;

  if (argc != 7)
    error("usage: makemaze <filename> <height> <width> <walls to remove>  <random start and goal states, 1 = random> <seed>");
  filename = (char *)malloc(strlen(argv[1])+strlen(".ppdl") + 1);
  sprintf(filename, "%s.pddl", argv[1]);
  cfilename = (char *)malloc(strlen(argv[1])+strlen(".cc") + 1);
  sprintf(cfilename, "%s.cc", argv[1]);
  endpointer = NULL;
  height = (int)strtoul(argv[2], &endpointer, 10);
  width = (int)strtoul(argv[3], &endpointer, 10);
  removals = (int)strtoul(argv[4], &endpointer, 10);  
  randomstartgoal = (int)strtoul(argv[5], &endpointer, 10);
  seed = (int)strtoul(argv[6], &endpointer, 10);
  if (height % 2 == 0 || width % 2 == 0)
    error("height and width must be odd");

  srandom(seed);
  if (randomstartgoal)
    {
      startx = 2*(random() % ((width+1)/2));
      starty = 2*(random() % ((height+1)/2));
      goalx = 2*(random() % ((width+1)/2));
      goaly = 2*(random() % ((height+1)/2));
    }
  else
    {
      startx = width-1;
      starty = height-1;
      goalx  = 0;
      goaly  = 0;
    }

  /* ALLOCATE MEMORY FOR MAZE */
  maze = (int **)calloc(width, sizeof(int *));
  for (x=0; x<width; ++x)
    {  
      maze[x] = (int *)calloc(height, sizeof(int));
      for (y=0; y<height; ++y)
	maze[x][y] = -1;
    }

  /* BUILD MAZE */
  x = 0;
  y = 0;
  maze[x][y] = 4;
  while (1)
    {
      directions = 0;
      direction = -1;
      for (i=0; i<4; ++i)
	if (x + 2*forwardx[i] >= 0 && x + 2*forwardx[i] < width &&
	    y + 2*forwardy[i] >= 0 && y + 2*forwardy[i] < height &&
	    maze[x + 2*forwardx[i]][y + 2*forwardy[i]] == -1)
	  if (random() % ++directions == 0)
	    direction = i;
      if (direction == -1)
	{
	  if (maze[x][y] == 4)
	    break;
	  else if (maze[x][y] == -1)
	    error("error 1\n");
	  else
	    direction = reverse[maze[x][y]];
	}
      x = x + forwardx[direction];
      y = y + forwardy[direction];
      maze[x][y] = 0;
      x = x + forwardx[direction];
      y = y + forwardy[direction];
      if (maze[x][y] == -1)
	maze[x][y] = direction;
    }

  stacksize = 0;
  for (x=0; x<width; ++x)
    for (y=0; y<height; ++y)
      if ((x+y)%2==1 && maze[x][y] == -1)
	++stacksize;
  stack = (int **)calloc(stacksize, sizeof(int *));

  stacksize = 0;
  stack = (int **)calloc((width+1)*(height+1)/4, sizeof(int *));
  for (x=0; x<width; ++x)
    for (y=0; y<height; ++y)
      if ((x+y)%2==1 && maze[x][y] == -1)
	stack[stacksize++] = &maze[x][y];
{
  int orem = removals;
  while (removals > 0 && stacksize > 0)
    {
      i = random() % stacksize;
      *stack[i] = 4;
      stack[i] = stack[--stacksize];
      removals -= 1;
    }
  if (removals > 0)
    error("there were not enough walls to remove");
  removals = orem;
}

  /* Print out the maze in 0/1 matrix format */
  file = fopen(filename, "w");
  fprintf(file, "width = %d, height = %d, steps = 2\n", width, height);
  fprintf(file, "start(x,y) = (%d,%d), goal(x,y) = (%d,%d)\n\n",
	  startx, starty, goalx, goaly);
  for (y=0; y<height; ++y)
    {  
      for (x=0; x<width; ++x)
	if (maze[x][y] == -1)
	  fprintf(file, "1 ");
	else
	  fprintf(file, "0 ");
      fprintf(file, "\n");
    }
  fclose(file);

  /* 
     **********************************************************************
     Added by Alessandro Cimatti

     Print out Maze in PDDL format (damn PDDL!).
     **********************************************************************
  */
  printf("Printing maze in file %s ...",filename);
  {
  file = fopen(filename, "w");
  /* AC: introduced this variable to control simplification of action effects */
  int do_not_simplify = 1;

  fprintf(file, "; \n");
  fprintf(file, ";  PDDL maze generator\n");
  fprintf(file, "; \n");
  fprintf(file, ";  width = %d, height = %d, steps = 2\n", width, height);
  fprintf(file, ";  0 <= x < %d is the column\n", width);
  fprintf(file, ";  0 <= y < %d is the row\n", height);
  fprintf(file, "; \n");
  fprintf(file, ";  go_left , go_west :  (x, y) => (x-1, y  )\n");
  fprintf(file, ";  go_right, go_east :  (x, y) => (x+1, y  )\n");
  fprintf(file, ";  go_up   , go_north:  (x, y) => (x,   y-1)\n");
  fprintf(file, ";  go_down , go_south:  (x, y) => (x,   y+1)\n");
  fprintf(file, "; \n");
  fprintf(file, ";  start(x,y) = (%d,%d), goal(x,y) = (%d,%d)\n",
	  startx, starty, goalx, goaly);
  fprintf(file, "; \n");
  fprintf(file, ";  The maze structure:\n");
  fprintf(file, ";  y\\\\x");
  for (x=0; x<width; ++x)
    fprintf(file, "%2d", x);
  fprintf(file, "\n");

  /* Start and goal must be not walls */
  if (maze[startx][starty] == -1)
    error("start on wall!!!");
  if (maze[goalx][goaly] == -1)
    error("goal on wall!!!");

  /* Printing the maze with start state (S) and goal state (G) */
  fprintf(file, "; ");
  for (x=0; x<width+9; ++x) 
    fprintf(file, "*");
  fprintf(file, "*\n");

  for (y=0; y<height; ++y) {  
    fprintf(file, ";  [%2d] *", y);
    for (x=0; x<width; ++x) {
      if (maze[x][y] == -1) {
	fprintf(file, "*");
      }
      else 
        if ((x == goalx) && (y == goaly)) {
	    fprintf(file, "G");
      } else {
	fprintf(file, " ");
      }
    }
    fprintf(file, "*\n");
  }
  fprintf(file, "; ");
  for (x=0; x<width+9; ++x) 
    fprintf(file, "*");
  fprintf(file, "*\n");

  fprintf(file, "\n\n(define (domain maze_h%d_w%d_r%d_s%d)\n",height, width, removals, seed);
  fprintf(file, "  (:model (:dynamics :non-deterministic) (:feedback :partial))\n");
  {
    int j = height - 1;
    fprintf(file, "  (:external (:function up    (:integer[0,%d] ) :integer[0,%d])
             (:function down  (:integer[0,%d] ) :integer[0,%d])
             (:function left  (:integer[0,%d] ) :integer[0,%d])
             (:function right (:integer[0,%d] ) :integer[0,%d])
             (:function no_walls   (:integer[0,%d] :integer[0,%d]) :boolean) 
             (:function wall_left  (:integer[0,%d] :integer[0,%d]) :boolean) 
             (:function wall_right (:integer[0,%d] :integer[0,%d]) :boolean) 
             (:function wall_up    (:integer[0,%d] :integer[0,%d]) :boolean) 
             (:function wall_down  (:integer[0,%d] :integer[0,%d]) :boolean))\n",
            j, j, j, j, j, j, j, j, j, j, j, j, j, j, j, j, j, j);
    fprintf(file, "  (:objects x - :integer[0,%d]
            y - :integer[0,%d])\n\n", j, j);
  }
  
  fprintf(file, "  (:action go_up
    :precondition (= (wall_up x y) false)
    :effect (:set y (up y))
  )

  (:action go_down
    :precondition (= (wall_down x y) false)
    :effect (:set y (down y))
  )

  (:action go_right
    :precondition (= (wall_right x y) false)   
    :effect (:set x (right x))
  )

  (:action go_left
    :precondition (= (wall_left x y) false)   
    :effect (:set x (left x))
  )

  (:action observe_left
   :observation (wall_left x y))

  (:action observe_right
   :observation (wall_right x y))

  (:action observe_up
   :observation (wall_up x y))

  (:action observe_down
   :observation (wall_down x y))

)\n");

  fprintf(file, "\n\n(define (problem pb)
  (:domain  maze_h%d_w%d_r%d_s%d)
  (:init 
         (:set y :in :integer[0,%d])
         (:set x :in :integer[0,%d])
         (= (no_walls x y) true))
  (:goal (:and (= x %d) (= y  %d))))\n\n",height, width, removals, seed, height-1, height-1, goalx, goaly); 

  /* ********************************************************************** */
  /* Actions: move north :  (x, y) => (x,   y-1)  */
  /* ********************************************************************** */
  // print_no_walls(file);

  /* Wrapping up */
  fprintf(file, "\n;  The maze structure, again\n");
  fprintf(file, ";  y\\\\x");
  for (x=0; x<width; ++x)
    fprintf(file, "%2d", x);
  fprintf(file, "\n");
  /* Printing the maze with start state (S) and goal state (G) */
  for (y=0; y<height; ++y) {  
    fprintf(file, ";  [%2d] ", y);
    for (x=0; x<width; ++x) {
      if (maze[x][y] == -1) {
	fprintf(file, "1 ");
      }
      else if ((x == startx) && (y == starty)) {
	  fprintf(file, "S ");
	}
      else if ((x == goalx) && (y == goaly)) {
	    fprintf(file, "G ");
      } else {
	fprintf(file, "0 ");
      }
    }
    fprintf(file, "\n");
  }

  fclose(file);
  }

  print_cfile(cfilename, height, width);

  printf("done!\n");
}

