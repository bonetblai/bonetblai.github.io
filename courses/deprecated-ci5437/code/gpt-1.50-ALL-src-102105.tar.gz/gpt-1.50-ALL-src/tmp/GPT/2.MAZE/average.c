#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{


  FILE * fp = stdout;
  int num_of_dunk;
  int num_of_toilets;
  int i,j,k;
  char fname[100];
  char * err[1];
  float val;
  float tot;
  int n;

  if ((fp = fopen("times","r")) == NULL) {
    perror(fname);
    exit(1);
  }

  n = 0;
  tot = 0;

  while (!feof(fp))
    {
      
      fscanf(fp,"%g\n",&val);
      tot = tot + val;
      n++;
    }
  fclose(fp);
  printf("Average: %g\n", tot/n);

}



