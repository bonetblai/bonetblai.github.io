
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{


  FILE * fp = stdout;
  int toilets, packages;
  int i,j,k,p,t;
  char fname[100];
  char * err[1];
  
  /* Parsing Options */
  if (argc != 3) {
    fprintf(stderr,"Usage: %s #packages #toilets\n",argv[0]);
    exit(1);
  }
  toilets  = strtol(argv[2],err, 10);
  packages = strtol(argv[1],err, 10);

  if ((fp = fopen("bmtcs.pddl","w")) == NULL) {
    perror(fname);
    exit(1);
  }


  fprintf(fp, "(define (domain bmtcs) \n");
  fprintf(fp, "  (:model (:dynamics :non-deterministic) (:feedback :partial)) \n");
  fprintf(fp, "  (:types PACKAGE BOMB TOILET) \n");
  fprintf(fp, "  (:functions (bomb PACKAGE BOMB) \n");
  fprintf(fp, "              (in BOMB PACKAGE) \n");
  fprintf(fp, "  ) \n");
  fprintf(fp, "  (:predicates (armed BOMB) \n");
  fprintf(fp, "               (clogged TOILET) \n");
  fprintf(fp, "               (explosive_odor PACKAGE) \n");
  fprintf(fp, "  ) \n");
  fprintf(fp, "  (:objects nil - BOMB) \n");
  fprintf(fp, " \n");
  fprintf(fp, "  (:ramification ram1 \n");
  fprintf(fp, "    :parameters ?p - PACKAGE \n");
  fprintf(fp, "                ?b - BOMB \n");
  fprintf(fp, "    :effect (:when (= (in ?b) ?p) (:set (bomb ?p) ?b)) \n");
  fprintf(fp, "            (:when (:and (:not (= ?b nil)) (:not (= (in ?b) ?p))) (:set (bomb ?p) nil)) \n");
  fprintf(fp, "  ) \n");
  fprintf(fp, " \n");
  fprintf(fp, "  (:ramification ram2 \n");
  fprintf(fp, "     :parameters ?p - PACKAGE \n");
  fprintf(fp, "                 ?b - BOMB \n");
  fprintf(fp, "     :effect (:when (= (in ?b) ?p) \n"); 
  fprintf(fp, "                    (:set (explosive_odor ?p) true)) \n");
  fprintf(fp, "             (:when (:and (:not (= ?b nil)) (:not (= (in ?b) ?p))) \n");
  fprintf(fp, "                    (:set (explosive_odor ?p) false)) \n");
  fprintf(fp, "  ) \n");
  fprintf(fp, " \n");
  fprintf(fp, "  (:action dunk \n");
  fprintf(fp, "    :parameters ?p - PACKAGE ?t - TOILET \n");
  fprintf(fp, "    :precondition (:not (clogged ?t)) \n");
  fprintf(fp, "    :effect (:set (armed (bomb ?p)) false) \n");
  fprintf(fp, "            (:set (clogged ?t) true) \n");
  fprintf(fp, "  ) \n");
  fprintf(fp, " \n");
  fprintf(fp, "  (:action flush \n");
  fprintf(fp, "    :parameters ?t - TOILET \n");
  fprintf(fp, "    :effect (:set (clogged ?t) false) \n");
  fprintf(fp, "  ) \n");
  fprintf(fp, " \n");
  fprintf(fp, "  (:action sniff \n");
  fprintf(fp, "     :parameters ?p - PACKAGE \n");
  fprintf(fp, "     :observation (explosive_odor ?p) \n");
  fprintf(fp, "  ) \n");
  fprintf(fp, ") \n");




  for (p = 1; p <= packages; p++)
    for (t = 1; t <= toilets; t++)
      {
        fprintf(fp, "(define (problem p%d_%d)\n",p,t);
        fprintf(fp, "(:domain bmtcs)\n");
        fprintf(fp, "(:objects b - BOMB\n");
        for (i = 1; i <= p; i++)
          fprintf(fp, "p%d ",i);
        fprintf(fp, "   - PACKAGE\n");
        for (i = 1; i <= t; i++)
          fprintf(fp, "t%d ",i);
        fprintf(fp, "   - TOILET)\n");
        fprintf(fp, "  (:init (:set (in b) :in {"); 
        for (i = 1; i <= p; i++)
          fprintf(fp, "p%d ",i);
        fprintf(fp, " })\n");
        fprintf(fp, "         (:set (armed b) true)\n");
        fprintf(fp, "         (:set (armed nil) false)\n");
        fprintf(fp, "         (:set (clogged t1) false))\n");
        fprintf(fp, "  (:goal (:not (armed b))))\n\n\n");
      }
        
  fclose(fp);
}

